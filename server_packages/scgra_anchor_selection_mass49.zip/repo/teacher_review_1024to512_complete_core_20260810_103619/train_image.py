import argparse
import copy
import csv
import math
import os
import random
import sys
import tempfile
import numpy as np
import torch
import torch.backends.cudnn as cudnn
from datetime import datetime
from PIL import Image
from torch.utils.data import DataLoader

from networks.vision_transformer import (
    TOPOLOGY_ATTENTION_VERSION,
    STRUCTURE_PROFILE_FULL,
    STRUCTURE_PROFILE_STAGE23_BOUNDARY_0626,
    SwinUnet as ViT_seg,
    get_topology_coefficients,
    load_topology_checkpoint_state,
    print_topology_coefficients,
)
from datasets.dataset_road_skeleton import RoadSkeletonDataset
from losses.road_losses import SurfaceStructureLoss
from config import get_config

parser = argparse.ArgumentParser()
parser.add_argument('--root_path', type=str, default='./data1', help='root dir for data')
parser.add_argument('--dataset', type=str, default='ImageData', help='dataset name')
parser.add_argument('--list_dir', type=str, default='./lists/lists_Synapse', help='list dir')
parser.add_argument('--num_classes', type=int, default=2, help='output channel of network')
parser.add_argument('--output_dir', type=str, default='./model_out', help='output dir')
parser.add_argument('--run_name', type=str, default='', help='optional run folder name under output_dir')
parser.add_argument('--resume_output_dir', type=str, default='', help='reuse this existing run directory and append logs when resuming')
parser.add_argument('--max_epochs', type=int, default=100, help='maximum epoch number to train')
parser.add_argument('--n_gpu', type=int, default=1, help='total gpu')
parser.add_argument('--deterministic', type=int, default=1, help='whether use deterministic training')
parser.add_argument('--base_lr', type=float, default=5e-4, help='segmentation network learning rate')
parser.add_argument('--min_lr', type=float, default=1e-5, help='minimum learning rate for cosine decay')
parser.add_argument('--warmup_epochs', type=int, default=3, help='warmup epochs before cosine decay')
parser.add_argument('--batch_size', type=int, default=4, help='batch_size per gpu')
parser.add_argument('--img_size', type=int, default=512, help='model input tile size')
parser.add_argument('--source_patch_size', type=int, default=1024, help='full source image size')
parser.add_argument('--overlap_stride', type=int, default=512, help='fixed training/validation tile stride; 512 gives non-overlap 4-patch tiling on 1024 source tiles')
parser.add_argument('--min_crop_road_pixels', type=int, default=0, help='retained for run metadata; fixed tiles are never filtered')
parser.add_argument('--augment', action=argparse.BooleanOptionalAction, default=True, help='synchronized geometry and image-only appearance augmentation')
parser.add_argument('--use_ema', action=argparse.BooleanOptionalAction, default=True, help='validate and save an EMA copy of the model')
parser.add_argument('--direct_resize_train', action='store_true', help='train/validate by resizing each full source patch to img_size instead of tiling')
parser.add_argument('--ema_decay', type=float, default=0.999)
parser.add_argument('--seed', type=int, default=1234, help='random seed')
parser.add_argument('--cfg', type=str, default='./configs/swin_tiny_patch4_window7_224_lite.yaml', 
                    help='path to config file')
parser.add_argument('--n_class', default=2, type=int)
parser.add_argument('--num_workers', default=4, type=int)
parser.add_argument('--print_freq', default=10, type=int, help='print loss every N batches')
parser.add_argument('--threshold', default=0.2, type=float, help='binary threshold for validation')
parser.add_argument('--skeleton_threshold', default=0.5, type=float, help='final skeleton threshold for validation')
parser.add_argument('--final_topology_eta_init', default=0.005, type=float, help='initial final topology repair coefficient')
parser.add_argument('--final_gap_rho_init', default=0.005, type=float, help='initial localized gap-repair coefficient')
parser.add_argument(
    '--stage_topology_stages',
    type=str,
    default='none',
    choices=['none', 'stage3', 'stage23'],
    help='which decoder stages get topology attention',
)
parser.add_argument('--stage_topology_alpha_max', type=float, default=1.0)
parser.add_argument('--stage_topology_alpha_init', type=float, default=0.1)
parser.add_argument(
    '--stage_topology_bias_mode',
    type=str,
    default='pairwise_skeleton',
    choices=['pairwise_skeleton', 'gap_query'],
    help='stage topology bias construction mode',
)
parser.add_argument('--stage_topology_ratio', type=float, default=0.08)
parser.add_argument('--stage_topology_topo_clip', type=float, default=4.0)
parser.add_argument('--stage_topology_warmup_epochs', type=int, default=5)
parser.add_argument(
    '--stage_topology_teacher_forcing_end',
    type=int,
    default=15,
    help='epoch at which teacher forcing ratio drops to 0',
)
parser.add_argument('--stage3_skeleton_weight', type=float, default=0.005)
parser.add_argument('--stage3_roadness_weight', type=float, default=0.003)
parser.add_argument('--stage2_skeleton_weight', type=float, default=0.0)
parser.add_argument('--stage2_skeleton_gradient_ratio', type=float, default=0.5)
parser.add_argument('--stage3_skeleton_gradient_ratio', type=float, default=0.5)
parser.add_argument('--final_skeleton_gradient_ratio', type=float, default=0.0)
parser.add_argument('--stage_direction_factor', type=float, default=0.2)
parser.add_argument('--stage_sc_s2c_weight', type=float, default=1.0)
parser.add_argument('--stage_sc_c2s_weight', type=float, default=0.2)
parser.add_argument('--road_attention_weight', type=float, default=0.003)
parser.add_argument('--max_train_batches', type=int, default=0, help='limit training to the first N batches per epoch; 0 means no limit')
parser.add_argument('--no_pretrain', action='store_true', help='do not load pretrained weights')
parser.add_argument('--pretrain_ckpt', type=str, default='', help='optional ImageNet Swin checkpoint path')
parser.add_argument('--pretrained_lr', type=float, default=5e-5, help='LR for tensors actually loaded from ImageNet')
parser.add_argument('--pretrained_min_lr', type=float, default=5e-6)
parser.add_argument('--new_lr', type=float, default=2e-4, help='LR for all randomly initialized tensors')
parser.add_argument('--new_min_lr', type=float, default=1e-5)
parser.add_argument('--disable_centerline_loss', action='store_true', help='disable the centerline response term for debugging NaN instability')
parser.add_argument(
    '--bottleneck_type',
    type=str,
    default='global_local',
    choices=['global_local', 'legacy_global_local', 'g2l2'],
    help='choose bottleneck implementation',
)
parser.add_argument(
    '--structure_profile',
    type=str,
    default=STRUCTURE_PROFILE_FULL,
    choices=[STRUCTURE_PROFILE_FULL, STRUCTURE_PROFILE_STAGE23_BOUNDARY_0626],
    help='0626 profile: stage2/3 structure only, final skeleton/connectivity off',
)
parser.add_argument(
    '--disable_msfe_skip',
    action='store_true',
    help='ablate MSFE blocks on decoder skip stages inx=2,3; DCA-FPN remains enabled',
)
DEFAULT_0626_CHECKPOINT = (
    './model_out/train_stage23_structure_final_boundary_nw0_20260626/best.pth'
)
# Options expected by the original config updater
parser.add_argument('--opts', nargs=argparse.REMAINDER, default=None, help='modify config options using the command-line')
parser.add_argument('--zip', action='store_true', help='use zipped dataset')
parser.add_argument('--cache_mode', type=str, default='', help='cache mode for dataset')
parser.add_argument('--resume', type=str, default='', help='resume from checkpoint')
parser.add_argument('--accumulation_steps', type=int, default=0, help='gradient accumulation steps')
parser.add_argument('--use_checkpoint', action='store_true', help='use gradient checkpointing')
parser.add_argument('--amp_opt_level', type=str, default='', help='AMP opt level')
parser.add_argument('--tag', type=str, default='', help='experiment tag')
parser.add_argument('--eval', action='store_true', help='evaluation only')
parser.add_argument('--throughput', action='store_true', help='test throughput only')

args = parser.parse_args()


def _cli_has(flag):
    return any(
        arg == flag or arg.startswith(flag + "=")
        for arg in sys.argv[1:]
    )


def apply_structure_profile_defaults(args):
    if args.structure_profile != STRUCTURE_PROFILE_STAGE23_BOUNDARY_0626:
        return

    args.stage_topology_stages = "none"
    if not _cli_has("--stage2_skeleton_weight"):
        args.stage2_skeleton_weight = 0.004
    if not _cli_has("--stage3_skeleton_weight"):
        args.stage3_skeleton_weight = 0.006
    if not _cli_has("--stage2_skeleton_gradient_ratio"):
        args.stage2_skeleton_gradient_ratio = 1.0
    if not _cli_has("--stage3_skeleton_gradient_ratio"):
        args.stage3_skeleton_gradient_ratio = 1.0
    args.stage3_roadness_weight = 0.0
    args.final_topology_eta_init = 0.0
    args.final_gap_rho_init = 0.0
    if args.warmup_epochs == 3:
        args.warmup_epochs = 10
    if args.max_epochs == 100:
        args.max_epochs = 60


apply_structure_profile_defaults(args)

def get_final_loss_weights(args):
    if args.structure_profile == STRUCTURE_PROFILE_STAGE23_BOUNDARY_0626:
        return {
            "skeleton_weight": 0.10,
            "connectivity_weight": 0.0,
            "boundary_weight": 0.01,
        }
    return {
        "skeleton_weight": 0.02,
        "connectivity_weight": 0.03,
        "boundary_weight": 0.03,
    }


def build_criterion(args, loss_weights, device):
    return SurfaceStructureLoss(
        surface_dice_weight=0.5,
        skeleton_dice_weight=1.0,
        skeleton_weight=loss_weights["skeleton_weight"],
        connectivity_weight=loss_weights["connectivity_weight"],
        connectivity_erode_kernel_size=1,
        boundary_weight=loss_weights["boundary_weight"],
        boundary_radius=1,
        stage_structure_weights=(
            0.0,
            0.0,
            args.stage2_skeleton_weight,
            args.stage3_skeleton_weight,
        ),
        road_attention_weight=args.road_attention_weight,
        stage_connectivity_factor=0.5,
        stage_direction_factor=args.stage_direction_factor,
        stage_skeleton_connectivity_s2c_weight=args.stage_sc_s2c_weight,
        stage_skeleton_connectivity_c2s_weight=args.stage_sc_c2s_weight,
        use_legacy_stage_connectivity_loss=(
            args.structure_profile == STRUCTURE_PROFILE_STAGE23_BOUNDARY_0626
        ),
    ).to(device)


def format_training_config_lines(args, loss_weights):
    lines = [
        f"  结构配置: {args.structure_profile}",
    ]
    if args.structure_profile == STRUCTURE_PROFILE_STAGE23_BOUNDARY_0626:
        lines.extend([
            "  Structure head: con0 -> decoder attention bias; ske1 -> gate feature, con1 prediction/loss only",
            "  Final skeleton head: enabled; final connectivity disabled",
            "  Stage2 structure loss weight: {:.3f}".format(args.stage2_skeleton_weight),
            "  Stage3 structure loss weight: {:.3f}".format(args.stage3_skeleton_weight),
            "  Stage2/Stage3 skeleton gradient ratio: {:.3f}/{:.3f}".format(
                args.stage2_skeleton_gradient_ratio,
                args.stage3_skeleton_gradient_ratio,
            ),
            "  Stage loss: 0.5*first guide prediction + 1.0*second refinement prediction; "
            "skeleton BCE(dilated) + 0.3 Dice(hard) + {:.3f} direction-field cosine; "
            "connectivity BCE disabled".format(args.stage_direction_factor),
            "  Stage skeleton-connectivity consistency: disabled",
            "  Encoder road attention: A1/A2 priors active for residual PatchMerging and Stage3 road attention bias",
            "  Encoder stage1 road prior: residual PatchMerging path",
            "  Global context calibration: bottleneck GAP -> stage3 structure gate only",
            "  Global context gate strength: 0.03",
            "  Decoder direction-aware connectivity attention bias: active",
            "  Decoder gate: original gate from structure feature + skeleton probability + connectivity strength",
        ])
    else:
        lines.extend([
            "  Decoder structure gates: restored 0621 stages 0/1/2/3",
            "  Final structure-only topology refiner: "
            f"eta_init={args.final_topology_eta_init}, eta_max=0.05, tau=4",
            "  Localized gap repair: "
            f"rho_init={args.final_gap_rho_init}, rho_max=0.05, detached M_gap",
            "  Stage topology attention: "
            f"{args.stage_topology_stages}, mode={args.stage_topology_bias_mode}, "
            f"ratio={args.stage_topology_ratio}, topo_clip={args.stage_topology_topo_clip}, "
            f"alpha_init={args.stage_topology_alpha_init}, "
            f"alpha_max={args.stage_topology_alpha_max}, "
            f"warmup={args.stage_topology_warmup_epochs}",
            "  Stage topology teacher forcing: "
            f"epoch 0 -> {args.stage_topology_teacher_forcing_end}",
        ])
    lines.extend([
        "  Stage structure weights: "
        f"stage2={args.stage2_skeleton_weight}, "
        f"stage3={args.stage3_skeleton_weight}, "
        f"stage2_grad_ratio={args.stage2_skeleton_gradient_ratio}, "
        f"stage3_grad_ratio={args.stage3_skeleton_gradient_ratio}, "
        f"final_skeleton_grad_ratio={args.final_skeleton_gradient_ratio}, "
        f"direction_factor={args.stage_direction_factor}, "
        "sc_s2c=0.0(loss disabled), "
        "sc_c2s=0.0(loss disabled), "
        f"road_attention={args.road_attention_weight}",
        (
            f"  Direct resize: {args.source_patch_size} -> {args.img_size}"
            if args.direct_resize_train
            else f"  Fixed overlap tiles: {args.source_patch_size} -> {args.img_size}, stride={args.overlap_stride}"
        ),
        f"  Minimum crop road pixels: {args.min_crop_road_pixels} (no tile filtering)",
        f"  Train augmentation: {'enabled' if args.augment else 'disabled'}",
        f"  EMA: {'enabled' if args.use_ema else 'disabled'}, decay={args.ema_decay}",
        (
            "  Validation: direct resized logits -> sigmoid -> one threshold"
            if args.direct_resize_train
            else "  Validation: stitch logits -> sigmoid -> one threshold -> global TP/FP/FN"
        ),
        "  Boundary-aware refinement: enabled",
        "  Boundary loss weight: {:.2f}".format(loss_weights["boundary_weight"]),
        "  Boundary target: dilate(mask, r=1) - erode(mask, k=3)",
        "  Final skeleton loss weight: {:.2f}".format(loss_weights["skeleton_weight"]),
        "  Final connectivity loss weight: {:.2f}".format(loss_weights["connectivity_weight"]),
        "  Edge loss: disabled",
        "  Edge skip enhance: disabled",
        f"  Decoder skip MSFE: {'disabled' if args.disable_msfe_skip else 'enabled'}",
    ])
    return lines


def make_unique_dir(base_dir, run_name):
    run_dir = os.path.join(base_dir, run_name)
    if not os.path.exists(run_dir):
        return run_dir

    index = 2
    while True:
        candidate = f"{run_dir}_{index}"
        if not os.path.exists(candidate):
            return candidate
        index += 1


def save_checkpoint_safely(checkpoint, target_path):
    """Save directly on Windows to avoid orphaned temporary checkpoint files."""
    target_dir = os.path.dirname(target_path)
    os.makedirs(target_dir, exist_ok=True)
    torch.save(checkpoint, target_path, _use_new_zipfile_serialization=False)


def model_state_is_finite(model):
    for param in model.state_dict().values():
        if torch.is_tensor(param) and not torch.isfinite(param).all():
            return False
    return True


class ModelEMA:
    def __init__(self, model, decay=0.999):
        self.ema = copy.deepcopy(model).eval()
        self.decay = float(decay)
        for parameter in self.ema.parameters():
            parameter.requires_grad_(False)

    @torch.no_grad()
    def update(self, model):
        model_state = model.state_dict()
        for name, ema_value in self.ema.state_dict().items():
            source_value = model_state[name].detach()
            if torch.is_floating_point(ema_value):
                ema_value.mul_(self.decay).add_(source_value.to(ema_value.dtype), alpha=1.0 - self.decay)
            else:
                ema_value.copy_(source_value)


def get_cosine_warmup_lr(step_index, max_steps, base_lr, min_lr, warmup_steps):
    if max_steps <= 0:
        return base_lr

    warmup_steps = max(0, int(warmup_steps))
    if warmup_steps > 0 and step_index < warmup_steps:
        return base_lr * float(step_index + 1) / float(warmup_steps)

    decay_steps = max(1, max_steps - warmup_steps)
    if decay_steps == 1:
        return min_lr

    progress = min(float(step_index - warmup_steps) / float(decay_steps - 1), 1.0)
    cosine = 0.5 * (1.0 + math.cos(math.pi * progress))
    return min_lr + (base_lr - min_lr) * cosine


def get_stage_topology_alpha_scale(epoch, warmup_epochs=5):
    if warmup_epochs <= 0:
        return 1.0
    if epoch < warmup_epochs:
        return 0.0
    return min(1.0, (epoch - warmup_epochs + 1) / warmup_epochs)


def get_teacher_forcing_ratio(epoch, tf_start=0, tf_end=15):
    if tf_end <= tf_start:
        return 0.0 if epoch >= tf_end else 1.0
    if epoch < tf_start:
        return 1.0
    if epoch >= tf_end:
        return 0.0
    return 1.0 - (epoch - tf_start) / (tf_end - tf_start)


def pad_to_window_multiple(x, window_size=7):
    """
    Pad input tensor to be divisible by window_size.
    Returns: (padded_tensor, original_shape)
    """
    B, C, H, W = x.shape
    pad_h = (window_size - H % window_size) % window_size
    pad_w = (window_size - W % window_size) % window_size
    if pad_h > 0 or pad_w > 0:
        x = torch.nn.functional.pad(x, (0, pad_w, 0, pad_h), mode='constant', value=0)
    return x, (H, W)


def crop_to_shape(x, target_shape):
    """Crop tensor back to target shape."""
    if x is None:
        return None
    H, W = target_shape
    return x[:, :, :H, :W]

# 模块级别定义，以便被 DataLoader worker 进程使用
class ResizeToTensor:
    def __init__(self, output_size):
        self.output_size = output_size

    def __call__(self, sample):
        image, label = sample['image'], sample['label']
        # image: [3, H, W], label: [H, W] (已二值化为 0 或 1)
        
        # 转换为 [H, W, 3] 便于 PIL 处理
        image = image.transpose(1, 2, 0)  # [3, H, W] -> [H, W, 3]
        
        # 转换为 uint8 进行 PIL 操作（反去归一化和标准化）
        # 由于已经做过标准化，这里简单还原逻辑：先乘 std，再加 mean，最后乘 255
        mean = np.array([0.485, 0.456, 0.406], dtype=np.float32)
        std = np.array([0.229, 0.224, 0.225], dtype=np.float32)
        image = (image * std + mean) * 255  # 反归一化
        image = np.clip(image, 0, 255).astype(np.uint8)
        
        image = Image.fromarray(image, mode='RGB').resize(self.output_size, Image.BILINEAR)
        
        # 标签已经二值化为 0.0 或 1.0，需要转换为 0-255 再进行 resize
        label_255 = (label * 255).astype(np.uint8)  # 转换回 0-255 用于 resize
        label = Image.fromarray(label_255).resize(self.output_size, Image.NEAREST)
        
        # 转回 float32 并重新归一化
        image = np.array(image, dtype=np.float32) / 255.0
        
        # ImageNet 标准化
        mean = np.array([0.485, 0.456, 0.406], dtype=np.float32)
        std = np.array([0.229, 0.224, 0.225], dtype=np.float32)
        image = (image - mean) / std
        image = image.transpose(2, 0, 1)  # [H, W, 3] -> [3, H, W]
        
        label = np.array(label, dtype=np.float32)
        label = (label > 127).astype(np.float32)  # 再次二值化 0-255 -> 0-1
        
        sample = {'image': torch.from_numpy(image), 'label': torch.from_numpy(label).long()}
        return sample

def load_split(split_name, train_mode=True, root_path='.', img_size=512, num_workers=4):
    from datasets.dataset_synapse import ImageDataset, RandomGenerator

    image_dir = os.path.join(root_path, split_name, 'image')
    label_dir = os.path.join(root_path, split_name, 'label')
    print(f"加载{split_name}数据...")
    print(f"  Image目录: {image_dir}")
    print(f"  Label目录: {label_dir}")
    transform = RandomGenerator(output_size=[img_size, img_size]) if train_mode else ResizeToTensor((img_size, img_size))
    dataset = ImageDataset(
        image_dir=image_dir,
        label_dir=label_dir,
        transform=transform
    )
    print(f"{split_name}集大小: {len(dataset)}")
    return dataset

def dice_loss(pred, target, threshold=0.5):
    """
    计算 Dice Loss
    pred: [B, 2, H, W] - 模型输出（logits）
    target: [B, H, W] - 目标标签
    threshold: 二值化阈值
    """
    # 如果是 [B, 2, H, W]，取第 1 类的概率
    if pred.dim() == 4 and pred.size(1) == 2:
        pred_prob = torch.softmax(pred, dim=1)[:, 1]  # [B, H, W]
    else:
        pred_prob = pred
    
    pred_binary = (pred_prob >= threshold).float()
    
    intersection = (pred_binary * target).sum()
    union = pred_binary.sum() + target.sum()
    
    dice_score = 2 * intersection / (union + 1e-8)
    return 1 - dice_score

def evaluate(model, loader, criterion, threshold=0.2):
    model.eval()
    total_loss = 0.0
    tp = fp = fn = 0
    debug_printed = False  # 仅打印第一个batch的调试信息
    with torch.no_grad():
        for batch in loader:
            images = batch['image'].to(device)
            labels = batch['label'].long().to(device)

            outputs = model(images)
            surface_logits = outputs

            # CE Loss
            ce_loss = criterion(surface_logits, labels)

            # Dice Loss
            dice_l = dice_loss(surface_logits, labels.float(), threshold)
            
            # 合并损失 (Dice权重从1.0降到0.5)
            loss = ce_loss + 0.5 * dice_l
            total_loss += loss.item()

            prob = torch.softmax(outputs, dim=1)[:, 1]
            pred = (prob >= threshold).long()
            
            # 调试：打印第一个batch的信息
            if not debug_printed:
                print(f"\n[验证调试] 第一个Batch:")
                print(f"  Label形状: {labels.shape}, 唯一值: {torch.unique(labels)}")
                print(f"  Pred形状: {pred.shape}, 唯一值: {torch.unique(pred)}")
                print(f"  Label类1的数量: {(labels == 1).sum().item()}")
                print(f"  Pred类1的数量: {(pred == 1).sum().item()}")
                print(f"  Prob min/max/mean: {prob.min():.4f}/{prob.max():.4f}/{prob.mean():.4f}")
                debug_printed = True
            
            tp += int(((pred == 1) & (labels == 1)).sum().item())
            fp += int(((pred == 1) & (labels == 0)).sum().item())
            fn += int(((pred == 0) & (labels == 1)).sum().item())

    avg_loss = total_loss / max(len(loader), 1)
    precision = tp / (tp + fp + 1e-8)
    recall = tp / (tp + fn + 1e-8)
    f1 = 2 * precision * recall / (precision + recall + 1e-8)
    iou = tp / (tp + fp + fn + 1e-8)
    return avg_loss, iou, f1, precision, recall

def evaluate_skeleton(
    model,
    loader,
    criterion,
    threshold=0.2,
    skeleton_threshold=0.5,
    stage_topology_alpha_scale=1.0,
):
    model.eval()
    total_loss = 0.0
    surface_tp = surface_fp = surface_fn = 0
    skeleton_tp = skeleton_fp = skeleton_fn = 0

    with torch.no_grad():
        for batch in loader:
            images = batch['image'].to(device)
            masks = batch['mask'].to(device)
            skeletons = batch['skeleton'].to(device)
            skeletons_dilate = batch['skeleton_dilate'].to(device)

            images_padded, orig_shape = pad_to_window_multiple(images, window_size=1)
            masks_padded, _ = pad_to_window_multiple(masks, window_size=1)
            skeletons_padded, _ = pad_to_window_multiple(skeletons, window_size=1)
            skeletons_dilate_padded, _ = pad_to_window_multiple(skeletons_dilate, window_size=1)
            
            outputs = model(
                images_padded,
                topology_alpha_scale=stage_topology_alpha_scale,
                teacher_forcing_ratio=0.0,
            )

            if isinstance(outputs, tuple):
                (
                    surface_logits,
                    boundary_logits,
                    skeleton_logits,
                    connectivity_logits,
                    stage_outputs,
                ) = outputs[:5]
            else:
                raise RuntimeError("Structure-guided training requires auxiliary model outputs.")
            surface_logits = crop_to_shape(surface_logits, orig_shape)
            boundary_logits = crop_to_shape(boundary_logits, orig_shape)
            skeleton_logits = crop_to_shape(skeleton_logits, orig_shape)
            connectivity_logits = crop_to_shape(connectivity_logits, orig_shape)
            
            masks_padded = crop_to_shape(masks_padded, orig_shape)
            skeletons_padded = crop_to_shape(skeletons_padded, orig_shape)
            skeletons_dilate_padded = crop_to_shape(skeletons_dilate_padded, orig_shape)

            loss, _ = criterion(
                surface_logits,
                surface_gt=masks_padded,
                skeleton_gt=skeletons_padded,
                skeleton_dilate_gt=skeletons_dilate_padded,
                stage_outputs=stage_outputs,
                boundary_logits=boundary_logits,
                skeleton_logits=skeleton_logits,
                connectivity_logits=connectivity_logits,
            )
            total_loss += loss.item()

            surface_pred = (torch.sigmoid(surface_logits) >= threshold).float().squeeze(1)
            masks_bin = (masks_padded > 0.5).float().squeeze(1)

            surface_tp += int((surface_pred * masks_bin).sum().item())
            surface_fp += int((surface_pred * (1.0 - masks_bin)).sum().item())
            surface_fn += int(((1.0 - surface_pred) * masks_bin).sum().item())

            if skeleton_logits is not None:
                skeleton_pred = (
                    torch.sigmoid(skeleton_logits) >= skeleton_threshold
                ).float().squeeze(1)
                skeletons_bin = (skeletons_padded > 0.5).float().squeeze(1)
                skeleton_tp += int((skeleton_pred * skeletons_bin).sum().item())
                skeleton_fp += int((skeleton_pred * (1.0 - skeletons_bin)).sum().item())
                skeleton_fn += int(((1.0 - skeleton_pred) * skeletons_bin).sum().item())

    avg_loss = total_loss / max(len(loader), 1)

    surface_precision = surface_tp / (surface_tp + surface_fp + 1e-8)
    surface_recall = surface_tp / (surface_tp + surface_fn + 1e-8)
    surface_f1 = 2 * surface_precision * surface_recall / (surface_precision + surface_recall + 1e-8)
    surface_iou = surface_tp / (surface_tp + surface_fp + surface_fn + 1e-8)
    skeleton_precision = skeleton_tp / (skeleton_tp + skeleton_fp + 1e-8)
    skeleton_recall = skeleton_tp / (skeleton_tp + skeleton_fn + 1e-8)
    skeleton_f1 = 2 * skeleton_precision * skeleton_recall / (skeleton_precision + skeleton_recall + 1e-8)
    skeleton_iou = skeleton_tp / (skeleton_tp + skeleton_fp + skeleton_fn + 1e-8)

    return {
        'loss': avg_loss,
        'surface_iou': surface_iou,
        'surface_f1': surface_f1,
        'surface_precision': surface_precision,
        'surface_recall': surface_recall,
        'skeleton_iou': skeleton_iou,
        'skeleton_f1': skeleton_f1,
        'skeleton_precision': skeleton_precision,
        'skeleton_recall': skeleton_recall,
    }


def evaluate_overlap_full_images(
    model,
    loader,
    threshold=0.2,
    skeleton_threshold=0.5,
    tile_size=512,
    stride=512,
    stage_topology_alpha_scale=1.0,
):
    model.eval()
    surface_tp = surface_fp = surface_fn = 0
    skeleton_tp = skeleton_fp = skeleton_fn = 0
    image_count = 0
    positions = RoadSkeletonDataset.sliding_positions
    weight_1d = torch.linspace(-1.0, 1.0, steps=tile_size, device=device).abs()
    weight_1d = (1.0 - weight_1d).clamp_min(0.1)
    tile_weight = (weight_1d[:, None] * weight_1d[None, :]).view(1, 1, tile_size, tile_size)

    with torch.no_grad():
        for batch in loader:
            full_images = batch['image'].to(device)
            full_masks = batch['mask'].to(device)
            full_skeletons = batch['skeleton'].to(device)
            for image_index in range(full_images.shape[0]):
                image = full_images[image_index:image_index + 1]
                mask = full_masks[image_index:image_index + 1]
                skeleton = full_skeletons[image_index:image_index + 1]
                height, width = image.shape[-2:]
                logit_canvas = torch.zeros((1, 1, height, width), device=device)
                skeleton_logit_canvas = torch.zeros_like(logit_canvas)
                weight_canvas = torch.zeros_like(logit_canvas)

                for top in positions(height, tile_size, stride):
                    for left in positions(width, tile_size, stride):
                        tile = image[:, :, top:top + tile_size, left:left + tile_size]
                        outputs = model(
                            tile,
                            topology_alpha_scale=stage_topology_alpha_scale,
                            teacher_forcing_ratio=0.0,
                        )
                        surface_logits = outputs[0]
                        skeleton_logits = outputs[2]
                        tile_height, tile_width = surface_logits.shape[-2:]
                        weight = tile_weight[:, :, :tile_height, :tile_width]
                        logit_canvas[:, :, top:top + tile_height, left:left + tile_width] += surface_logits * weight
                        if skeleton_logits is not None:
                            skeleton_logit_canvas[:, :, top:top + tile_height, left:left + tile_width] += skeleton_logits * weight
                        weight_canvas[:, :, top:top + tile_height, left:left + tile_width] += weight

                if weight_canvas.min().item() <= 0:
                    raise RuntimeError("Overlap validation left uncovered pixels in the full-image canvas.")
                full_logits = logit_canvas / weight_canvas
                surface_pred = (torch.sigmoid(full_logits) >= threshold).float()
                mask_bin = (mask > 0.5).float()
                surface_tp += int((surface_pred * mask_bin).sum().item())
                surface_fp += int((surface_pred * (1.0 - mask_bin)).sum().item())
                surface_fn += int(((1.0 - surface_pred) * mask_bin).sum().item())

                if skeleton_logits is not None:
                    full_skeleton_logits = skeleton_logit_canvas / weight_canvas
                    skeleton_pred = (torch.sigmoid(full_skeleton_logits) >= skeleton_threshold).float()
                    skeleton_bin = (skeleton > 0.5).float()
                    skeleton_tp += int((skeleton_pred * skeleton_bin).sum().item())
                    skeleton_fp += int((skeleton_pred * (1.0 - skeleton_bin)).sum().item())
                    skeleton_fn += int(((1.0 - skeleton_pred) * skeleton_bin).sum().item())
                image_count += 1

    surface_precision = surface_tp / (surface_tp + surface_fp + 1e-8)
    surface_recall = surface_tp / (surface_tp + surface_fn + 1e-8)
    skeleton_precision = skeleton_tp / (skeleton_tp + skeleton_fp + 1e-8)
    skeleton_recall = skeleton_tp / (skeleton_tp + skeleton_fn + 1e-8)
    return {
        'loss': 0.0,
        'surface_iou': surface_tp / (surface_tp + surface_fp + surface_fn + 1e-8),
        'surface_f1': 2 * surface_precision * surface_recall / (surface_precision + surface_recall + 1e-8),
        'surface_precision': surface_precision,
        'surface_recall': surface_recall,
        'skeleton_iou': skeleton_tp / (skeleton_tp + skeleton_fp + skeleton_fn + 1e-8),
        'skeleton_f1': 2 * skeleton_precision * skeleton_recall / (skeleton_precision + skeleton_recall + 1e-8),
        'skeleton_precision': skeleton_precision,
        'skeleton_recall': skeleton_recall,
        'image_count': image_count,
    }

if __name__ == "__main__":
    # 自动检测可用设备
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"[INFO] Using device: {device}")
    
    if not args.deterministic:
        cudnn.benchmark = True
        cudnn.deterministic = False
    else:
        cudnn.benchmark = False
        cudnn.deterministic = True

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(args.seed)

    # 设置训练参数
    base_output_dir = args.output_dir
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_name = args.run_name.strip() if args.run_name.strip() else f"train_skeleton_{timestamp}"
    if args.resume_output_dir.strip():
        args.output_dir = args.resume_output_dir.strip()
    else:
        args.output_dir = make_unique_dir(base_output_dir, run_name)
    os.makedirs(args.output_dir, exist_ok=True)
    checkpoints_dir = os.path.join(args.output_dir, 'checkpoints')
    os.makedirs(checkpoints_dir, exist_ok=True)
    loss_log_path = os.path.join(args.output_dir, 'epoch_losses.csv')
    batch_loss_log_path = os.path.join(args.output_dir, 'batch_losses.csv')
    training_log_path = os.path.join(args.output_dir, 'training_log.txt')  # 统一日志文件
    
    # 加载配置
    config = get_config(args)
    if args.pretrain_ckpt:
        config.defrost()
        config.MODEL.PRETRAIN_CKPT = args.pretrain_ckpt
        config.freeze()
    
    # 对齐 img_size 到 window_size=8 的倍数（模型初始化时需要）
    # Swin blocks pad their own feature maps for window=7 attention.
    window_size = int(config.MODEL.SWIN.WINDOW_SIZE)
    aligned_img_size = args.img_size
    if aligned_img_size != args.img_size:
        print(f"[INFO] 对齐 img_size: {args.img_size} -> {aligned_img_size} (window_size={window_size})")
        config.defrost()
        config.DATA.IMG_SIZE = aligned_img_size
        config.freeze()
        args.img_size = aligned_img_size
    
    # 创建网络
    args.num_classes = 1
    loss_weights = get_final_loss_weights(args)
    model = ViT_seg(config=config, img_size=args.img_size,
                    num_classes=args.num_classes,
                    return_skeleton=True, bottleneck_type=args.bottleneck_type,
                    final_topology_eta_init=args.final_topology_eta_init,
                    final_gap_rho_init=args.final_gap_rho_init,
                    stage_topology_stages=args.stage_topology_stages,
                    stage_topology_alpha_max=args.stage_topology_alpha_max,
                    stage_topology_alpha_init=args.stage_topology_alpha_init,
                    stage_topology_bias_mode=args.stage_topology_bias_mode,
                    stage_topology_ratio=args.stage_topology_ratio,
                    stage_topology_topo_clip=args.stage_topology_topo_clip,
                    structure_profile=args.structure_profile,
                    use_msfe_skip=not args.disable_msfe_skip,
                    stage2_skeleton_gradient_ratio=args.stage2_skeleton_gradient_ratio,
                    stage3_skeleton_gradient_ratio=args.stage3_skeleton_gradient_ratio,
                    final_skeleton_gradient_ratio=args.final_skeleton_gradient_ratio).to(device)

    loaded_pretrained_names = set()
    if not args.resume and not args.no_pretrain:
        pretrain_path = config.MODEL.PRETRAIN_CKPT
        if not os.path.isfile(pretrain_path):
            raise FileNotFoundError(
                f"Swin pretrained checkpoint not found: {pretrain_path}. "
                "Set --pretrain_ckpt or use --no_pretrain."
            )
        loaded_pretrained_names = model.load_from(config)

    def build_layerwise_optimizer():
        loaded_params, new_params = [], []
        for name, parameter in model.named_parameters():
            if not parameter.requires_grad:
                continue
            (loaded_params if name in loaded_pretrained_names else new_params).append(parameter)
        groups = []
        if loaded_params:
            groups.append({'params': loaded_params, 'lr': args.pretrained_lr, 'initial_lr': args.pretrained_lr, 'group_name': 'imagenet_loaded'})
        if new_params:
            groups.append({'params': new_params, 'lr': args.new_lr, 'initial_lr': args.new_lr, 'group_name': 'random_or_custom'})
        print(f"[INFO] LR groups: ImageNet-loaded={len(loaded_params)} tensors at {args.pretrained_lr:g}; new/custom={len(new_params)} tensors at {args.new_lr:g}", flush=True)
        return torch.optim.AdamW(groups, weight_decay=0.0001)

    # 加载数据
    train_dataset = RoadSkeletonDataset(
        root_dir=args.root_path,
        split='train',
        image_size=args.img_size,
        source_patch_size=args.source_patch_size,
        tile_size=None if args.direct_resize_train else args.img_size,
        tile_stride=None if args.direct_resize_train else args.overlap_stride,
        augment=args.augment,
    )
    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=args.num_workers,
        pin_memory=True
    )
    optimizer_steps_per_epoch = max(1, args.max_train_batches if args.max_train_batches > 0 else len(train_loader))
    warmup_steps = args.warmup_epochs * optimizer_steps_per_epoch
    total_optimizer_steps = max(1, args.max_epochs * optimizer_steps_per_epoch)

    val_dataset = RoadSkeletonDataset(
        root_dir=args.root_path,
        split='val',
        image_size=args.img_size if args.direct_resize_train else None,
        source_patch_size=args.source_patch_size,
        return_full_image=not args.direct_resize_train,
    )
    val_loader = DataLoader(
        val_dataset,
        batch_size=1,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=True
    )

    # 优化器 / 损失（graph-only 模式在加载 checkpoint 后再建 optimizer）
    criterion = build_criterion(args, loss_weights, device)
    optimizer = None

    # 检查是否恢复训练
    start_epoch = 0
    if args.resume:
        if os.path.isfile(args.resume):
            print(f"加载checkpoint: {args.resume}")
            checkpoint = torch.load(args.resume, map_location=device)
            checkpoint_state = checkpoint["model_state_dict"]
            model_state = model.state_dict()
            filtered_checkpoint_state = {}
            skipped_gate_keys = []
            for key, value in checkpoint_state.items():
                if (
                    key in model_state
                    and value.shape != model_state[key].shape
                    and key.endswith("structure_gate.0.weight")
                ):
                    skipped_gate_keys.append(key)
                    continue
                filtered_checkpoint_state[key] = value
            if skipped_gate_keys:
                print(
                    "[WARN] Reinitialized direction-gate input weights: "
                    + ", ".join(skipped_gate_keys),
                    flush=True,
                )
                checkpoint_state = filtered_checkpoint_state
            strict_load = args.bottleneck_type == 'global_local'
            try:
                model.load_state_dict(checkpoint_state, strict=strict_load)
            except RuntimeError as exc:
                    allowed_missing_prefixes = (
                        "swin_unet.stage2_topology_source.",
                        "swin_unet.stage_topology_scales.",
                        "swin_unet.decoder_structure_blocks.3.stage_roadness_head.",
                        "swin_unet.guided_head.graph_propagation.",
                        "swin_unet.decoder_structure_blocks.0.direction_head.",
                        "swin_unet.decoder_structure_blocks.1.direction_head.",
                        "swin_unet.decoder_structure_blocks.2.direction_head.",
                        "swin_unet.decoder_structure_blocks.3.direction_head.",
                        "swin_unet.decoder_structure_blocks.0.structure_gate.0.weight",
                        "swin_unet.decoder_structure_blocks.1.structure_gate.0.weight",
                        "swin_unet.decoder_structure_blocks.2.structure_gate.0.weight",
                        "swin_unet.decoder_structure_blocks.3.structure_gate.0.weight",
                        "swin_unet.decoder_structure_blocks.0.gate_branch.",
                        "swin_unet.decoder_structure_blocks.1.gate_branch.",
                        "swin_unet.decoder_structure_blocks.2.gate_branch.",
                        "swin_unet.decoder_structure_blocks.3.gate_branch.",
                        "swin_unet.stage2_topology_source.direction_head.",
                        "swin_unet.stage2_topology_source.structure_gate.0.weight",
                        "swin_unet.stage2_topology_source.gate_branch.",
                        "swin_unet.guided_head.detached_skeleton_refine.",
                        "swin_unet.guided_head.detached_skeleton_head.",
                    )
                    allowed_unexpected_prefixes = (
                        "asterisk.",
                    )
                    result = model.load_state_dict(
                        checkpoint_state,
                        strict=False,
                    )
                    invalid_missing = [
                        key
                        for key in result.missing_keys
                        if not key.startswith(allowed_missing_prefixes)
                    ]
                    invalid_unexpected = [
                        key
                        for key in result.unexpected_keys
                        if not key.startswith(allowed_unexpected_prefixes)
                    ]
                    if invalid_missing or invalid_unexpected:
                        raise RuntimeError(
                            "Checkpoint mismatch on resume: "
                            f"missing={invalid_missing}, unexpected={invalid_unexpected}"
                        ) from exc
                    if result.unexpected_keys:
                        print(
                            "[WARN] Ignored legacy checkpoint keys not used by current model: "
                            + ", ".join(result.unexpected_keys),
                            flush=True,
                        )
                    print(
                        "[WARN] Loaded checkpoint with strict=False; "
                        "some modules use fresh initialization.",
                        flush=True,
                    )
            start_epoch = checkpoint.get('epoch', 0)
            try:
                optimizer = build_layerwise_optimizer()
                optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
            except (ValueError, RuntimeError) as exc:
                print(
                    "[WARN] Optimizer state not restored; "
                    "continuing with a fresh optimizer for current parameters.",
                    flush=True,
                )
                print(f"[WARN] Optimizer resume detail: {exc}", flush=True)
            print(f"从epoch {start_epoch} 继续训练...")
        else:
            print(f"Warning: checkpoint未找到 {args.resume}")

    if optimizer is None:
        optimizer = build_layerwise_optimizer()

    ema = ModelEMA(model, decay=args.ema_decay) if args.use_ema else None
    if ema is not None and args.resume and 'checkpoint' in locals():
        ema_state = checkpoint.get('ema_state_dict')
        if ema_state is not None:
            try:
                ema.ema.load_state_dict(ema_state)
            except RuntimeError as exc:
                ema_result = ema.ema.load_state_dict(ema_state, strict=False)
                invalid_ema_missing = list(ema_result.missing_keys)
                invalid_ema_unexpected = [
                    key
                    for key in ema_result.unexpected_keys
                    if not key.startswith("asterisk.")
                ]
                if invalid_ema_missing or invalid_ema_unexpected:
                    raise RuntimeError(
                        "EMA checkpoint mismatch on resume: "
                        f"missing={invalid_ema_missing}, unexpected={invalid_ema_unexpected}"
                    ) from exc
                if ema_result.unexpected_keys:
                    print(
                        "[WARN] Ignored legacy EMA checkpoint keys not used by current model: "
                        + ", ".join(ema_result.unexpected_keys),
                        flush=True,
                    )

    # 训练循环
    print("\n开始训练...")
    print(f"配置:")
    print(f"  最大轮数: {args.max_epochs}")
    print(f"  批大小: {args.batch_size}")
    print(f"  学习率: {args.base_lr}")
    print(f"  最小学习率: {args.min_lr}")
    print(f"  Warmup轮数: {args.warmup_epochs}")
    for line in format_training_config_lines(args, loss_weights):
        print(line)
    print(f"  输出目录: {args.output_dir}")
    print(f"  Checkpoints目录: {checkpoints_dir}")
    print(f"  验证阈值: {args.threshold}")
    if args.max_train_batches > 0:
        print(f"  每轮最多训练batch数: {args.max_train_batches}")
    if args.resume:
        print(f"  从checkpoint恢复: {args.resume}")
        print(f"  起始epoch: {start_epoch}")

    print("Using topology attention constrained version", flush=True)
    print_topology_coefficients(model)

    best_val_f1 = checkpoint.get('val_f1', -1.0) if args.resume and 'checkpoint' in locals() else -1.0
    append_existing_logs = bool(
        args.resume_output_dir.strip()
        and args.resume
        and os.path.exists(loss_log_path)
        and os.path.exists(batch_loss_log_path)
    )
    
    # 写入训练日志头
    with open(training_log_path, 'a' if append_existing_logs else 'w', encoding='utf-8') as log_f:
        log_f.write("="*100 + "\n")
        log_f.write("Swin-UNet 训练日志\n")
        log_f.write("="*100 + "\n")
        log_f.write(f"训练配置:\n")
        log_f.write(f"  最大轮数: {args.max_epochs}\n")
        log_f.write(f"  批大小: {args.batch_size}\n")
        log_f.write(f"  学习率: {args.base_lr}\n")
        log_f.write(f"  最小学习率: {args.min_lr}\n")
        log_f.write(f"  Warmup轮数: {args.warmup_epochs}\n")
        for line in format_training_config_lines(args, loss_weights):
            log_f.write(line + "\n")
        log_f.write(f"  验证阈值: {args.threshold}\n")
        log_f.write(f"  数据目录: {args.root_path}\n")
        if args.max_train_batches > 0:
            log_f.write(f"  每轮最多训练batch数: {args.max_train_batches}\n")
        log_f.write("="*100 + "\n\n")
    
    with open(loss_log_path, 'a' if append_existing_logs else 'w', newline='', encoding='utf-8') as loss_log_file, \
         open(batch_loss_log_path, 'a' if append_existing_logs else 'w', newline='', encoding='utf-8') as batch_loss_log_file:
        loss_writer = csv.writer(loss_log_file)
        batch_loss_writer = csv.writer(batch_loss_log_file)
        if not append_existing_logs:
            loss_writer.writerow([
                'epoch', 'lr', 'train_avg_loss', 'val_loss',
                'surface_iou', 'surface_f1', 'surface_precision', 'surface_recall',
                'skeleton_iou', 'skeleton_f1', 'skeleton_precision', 'skeleton_recall'
            ])
            batch_loss_writer.writerow(['epoch', 'batch', 'loss'])

        for epoch in range(start_epoch, args.max_epochs):
            model.train()
            total_loss = 0
            train_batches = 0
            skipped_batches = 0
            optimizer_step_index = epoch * optimizer_steps_per_epoch
            stage_topology_alpha_scale = get_stage_topology_alpha_scale(
                epoch,
                args.stage_topology_warmup_epochs,
            )
            teacher_forcing_ratio = get_teacher_forcing_ratio(
                epoch,
                tf_start=0,
                tf_end=args.stage_topology_teacher_forcing_end,
            )

            for i, batch in enumerate(train_loader):
                if args.max_train_batches > 0 and train_batches >= args.max_train_batches:
                    break

                images = batch['image'].to(device)
                masks = batch['mask'].to(device)
                skeletons = batch['skeleton'].to(device)
                skeletons_dilate = batch['skeleton_dilate'].to(device)
                connectivity_gt = batch['connectivity_gt'].to(device)
                direction_gt = batch['direction_gt'].to(device)
                boundary_gt = batch['boundary_gt'].to(device)
                valid_mask = batch['valid_mask'].to(device)

                images_padded, orig_shape = pad_to_window_multiple(images, window_size=1)
                masks_padded, _ = pad_to_window_multiple(masks, window_size=1)
                skeletons_padded, _ = pad_to_window_multiple(skeletons, window_size=1)
                skeletons_dilate_padded, _ = pad_to_window_multiple(skeletons_dilate, window_size=1)

                outputs = model(
                    images_padded,
                    gt_skeleton=skeletons_padded,
                    topology_alpha_scale=stage_topology_alpha_scale,
                    teacher_forcing_ratio=teacher_forcing_ratio,
                )

                if isinstance(outputs, tuple):
                    (
                        surface_logits,
                        boundary_logits,
                        skeleton_logits,
                        connectivity_logits,
                        stage_outputs,
                    ) = outputs[:5]
                else:
                    raise RuntimeError("Structure-guided training requires auxiliary model outputs.")
                surface_logits = crop_to_shape(surface_logits, orig_shape)
                boundary_logits = crop_to_shape(boundary_logits, orig_shape)
                skeleton_logits = crop_to_shape(skeleton_logits, orig_shape)
                connectivity_logits = crop_to_shape(connectivity_logits, orig_shape)
                
                masks_padded = crop_to_shape(masks_padded, orig_shape)
                skeletons_padded = crop_to_shape(skeletons_padded, orig_shape)
                skeletons_dilate_padded = crop_to_shape(skeletons_dilate_padded, orig_shape)
                
                loss, loss_dict = criterion(
                    surface_logits,
                    surface_gt=masks_padded,
                    skeleton_gt=skeletons_padded,
                    skeleton_dilate_gt=skeletons_dilate_padded,
                    stage_outputs=stage_outputs,
                    boundary_logits=boundary_logits,
                    skeleton_logits=skeleton_logits,
                    connectivity_logits=connectivity_logits,
                    connectivity_gt=connectivity_gt,
                    direction_gt=direction_gt,
                    boundary_gt=boundary_gt,
                    valid_mask=valid_mask,
                )

                if not torch.isfinite(loss):
                    skipped_batches += 1
                    print(
                        f"[WARN] Non-finite loss skipped at epoch {epoch+1}, batch {i+1}: {loss.item()}",
                        flush=True,
                    )
                    optimizer.zero_grad(set_to_none=True)
                    continue

                optimizer.zero_grad()
                loss.backward()

                current_lr = get_cosine_warmup_lr(
                    optimizer_step_index,
                    total_optimizer_steps,
                    args.new_lr,
                    args.new_min_lr,
                    warmup_steps,
                )
                for param_group in optimizer.param_groups:
                    if param_group.get('group_name') == 'imagenet_loaded':
                        param_group['lr'] = get_cosine_warmup_lr(
                            optimizer_step_index,
                            total_optimizer_steps,
                            args.pretrained_lr,
                            args.pretrained_min_lr,
                            warmup_steps,
                        )
                    else:
                        param_group['lr'] = current_lr

                grad_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                if not torch.isfinite(grad_norm):
                    skipped_batches += 1
                    print(
                        f"[WARN] Non-finite gradients skipped at epoch {epoch+1}, batch {i+1}: {grad_norm}",
                        flush=True,
                    )
                    optimizer.zero_grad(set_to_none=True)
                    continue

                optimizer.step()
                optimizer_step_index += 1
                if ema is not None:
                    ema.update(model)

                total_loss += loss.item()
                train_batches += 1
                batch_loss_writer.writerow([epoch + 1, i + 1, f'{loss.item():.6f}'])
                batch_loss_log_file.flush()

                if (i + 1) % args.print_freq == 0 or i == 0:
                    print(
                        f"Epoch [{epoch+1}/{args.max_epochs}], Batch [{i+1}/{len(train_loader)}], "
                        f"Loss: {loss.item():.4f}, Surface: {loss_dict['surface_loss'].item():.4f}, "
                        f"Skeleton: {loss_dict['skeleton_loss'].item():.4f}, "
                        f"Conn: {loss_dict['connectivity_loss'].item():.4f}, "
                        f"StageStruct: {loss_dict['stage_structure_loss'].item():.4f}, "
                        f"RoadAttn: {loss_dict['road_attention_loss'].item():.4f}, "
                        f"TopoAlphaScale: {stage_topology_alpha_scale:.2f}, "
                        f"TF: {teacher_forcing_ratio:.2f}, "
                        f"Boundary: {loss_dict['boundary_loss'].item():.4f}, "
                        f"LR: {current_lr:.6g}",
                        flush=True
                    )

            train_avg_loss = total_loss / max(train_batches, 1)
            eval_model = ema.ema if ema is not None else model
            if args.direct_resize_train:
                val_metrics = evaluate_skeleton(
                    eval_model,
                    val_loader,
                    criterion,
                    threshold=args.threshold,
                    skeleton_threshold=args.skeleton_threshold,
                    stage_topology_alpha_scale=stage_topology_alpha_scale,
                )
            else:
                val_metrics = evaluate_overlap_full_images(
                    eval_model,
                    val_loader,
                    threshold=args.threshold,
                    skeleton_threshold=args.skeleton_threshold,
                    tile_size=args.img_size,
                    stride=args.overlap_stride,
                    stage_topology_alpha_scale=stage_topology_alpha_scale,
                )
            val_loss = val_metrics['loss']
            val_iou = val_metrics['surface_iou']
            val_f1 = val_metrics['surface_f1']
            val_precision = val_metrics['surface_precision']
            val_recall = val_metrics['surface_recall']
            skeleton_iou = val_metrics['skeleton_iou']
            skeleton_f1 = val_metrics['skeleton_f1']
            skeleton_precision = val_metrics['skeleton_precision']
            skeleton_recall = val_metrics['skeleton_recall']
            
            # 打印到控制台
            epoch_msg = (
                f"Epoch {epoch+1}/{args.max_epochs}, LR: {current_lr:.6g}, Train Loss: {train_avg_loss:.4f}, Val Loss: {val_loss:.4f}, "
                f"Surface IoU: {val_iou:.4f}, Surface F1: {val_f1:.4f}, "
                f"Precision: {val_precision:.4f}, Recall: {val_recall:.4f}, "
                f"Skeleton IoU: {skeleton_iou:.4f}, Skeleton F1: {skeleton_f1:.4f}"
            )
            print(epoch_msg, flush=True)
            topology_msg = print_topology_coefficients(
                model,
                prefix=f"[TOPOLOGY][Epoch {epoch + 1}]",
            )
            if skipped_batches > 0:
                print(f"[WARN] Skipped non-finite batches this epoch: {skipped_batches}", flush=True)
            
            # 写入 CSV
            loss_writer.writerow([
                epoch + 1, f'{current_lr:.8f}', f'{train_avg_loss:.6f}', f'{val_loss:.6f}',
                f'{val_iou:.6f}', f'{val_f1:.6f}', f'{val_precision:.6f}', f'{val_recall:.6f}',
                f'{skeleton_iou:.6f}', f'{skeleton_f1:.6f}', f'{skeleton_precision:.6f}', f'{skeleton_recall:.6f}'
            ])
            loss_log_file.flush()
            
            # 写入 txt 日志
            with open(training_log_path, 'a', encoding='utf-8') as log_f:
                log_f.write(epoch_msg + "\n")
                log_f.write(f"  Train Avg Loss: {train_avg_loss:.6f}\n")
                log_f.write(f"  Val Loss: {val_loss:.6f}\n")
                log_f.write(f"  Val IoU: {val_iou:.6f}\n")
                log_f.write(f"  Val F1: {val_f1:.6f}\n")
                log_f.write(f"  Val Precision: {val_precision:.6f}\n")
                log_f.write(f"  Val Recall: {val_recall:.6f}\n")
                log_f.write(f"  Skeleton IoU: {skeleton_iou:.6f}\n")
                log_f.write(f"  Skeleton F1: {skeleton_f1:.6f}\n")
                log_f.write(f"  Skeleton Precision: {skeleton_precision:.6f}\n")
                log_f.write(f"  Skeleton Recall: {skeleton_recall:.6f}\n")
                log_f.write(
                    f"  Stage topology alpha scale: "
                    f"{stage_topology_alpha_scale:.6f}\n"
                )
                log_f.write(
                    f"  Stage topology teacher forcing ratio: "
                    f"{teacher_forcing_ratio:.6f}\n"
                )
                log_f.write(f"  Skipped non-finite batches: {skipped_batches}\n")
                log_f.write(topology_msg + "\n")
                log_f.write("-"*100 + "\n")

            if not np.isfinite(train_avg_loss) or not np.isfinite(val_loss) or not model_state_is_finite(model):
                print(
                    f"[WARN] Non-finite epoch state at epoch {epoch+1}; checkpoint not saved.",
                    flush=True,
                )
                continue

            checkpoint_model = ema.ema if ema is not None else model
            checkpoint = {
                'epoch': epoch + 1,
                'model_state_dict': checkpoint_model.state_dict(),
                'training_model_state_dict': model.state_dict(),
                'ema_state_dict': ema.ema.state_dict() if ema is not None else None,
                'optimizer_state_dict': optimizer.state_dict(),
                'train_avg_loss': train_avg_loss,
                'val_loss': val_loss,
                'val_iou': val_iou,
                'val_f1': val_f1,
                'val_precision': val_precision,
                'val_recall': val_recall,
                'skeleton_iou': skeleton_iou,
                'skeleton_f1': skeleton_f1,
                'skeleton_precision': skeleton_precision,
                'skeleton_recall': skeleton_recall,
                'topology_attention_version': TOPOLOGY_ATTENTION_VERSION,
                'structure_profile': args.structure_profile,
                'topology_coefficients': get_topology_coefficients(model),
                'stage_topology_alpha_scale': stage_topology_alpha_scale,
                'stage_topology_teacher_forcing_ratio': teacher_forcing_ratio,
                'args': vars(args),
            }
            # 保存 last.pth（总是覆盖）
            save_checkpoint_safely(checkpoint, os.path.join(args.output_dir, 'last.pth'))

            if val_f1 > best_val_f1:
                best_val_f1 = val_f1
                best_path = os.path.join(args.output_dir, 'best.pth')
                save_checkpoint_safely(checkpoint, best_path)
                print(f"[BEST] 当前最优模型已保存: best.pth (F1={val_f1:.4f})", flush=True)

    # 训练完成，写总结日志
    with open(training_log_path, 'a', encoding='utf-8') as log_f:
        log_f.write("\n" + "="*100 + "\n")
        log_f.write("训练完成总结\n")
        log_f.write("="*100 + "\n")
        log_f.write(f"总 Epochs: {args.max_epochs}\n")
        log_f.write(f"最佳 F1 分数: {best_val_f1:.6f}\n")
        log_f.write(f"最佳模型: best.pth\n")
        log_f.write(f"最后模型: last.pth\n")
        log_f.write("="*100 + "\n")

    best_path = os.path.join(args.output_dir, 'best.pth')
    if os.path.isfile(best_path):
        best_checkpoint = torch.load(best_path, map_location='cuda')
        model.load_state_dict(best_checkpoint['model_state_dict'], strict=(args.bottleneck_type == 'global_local'))
        if args.direct_resize_train:
            best_val_metrics = evaluate_skeleton(
                model,
                val_loader,
                criterion,
                threshold=args.threshold,
                skeleton_threshold=args.skeleton_threshold,
                stage_topology_alpha_scale=1.0,
            )
        else:
            best_val_metrics = evaluate_overlap_full_images(
                model,
                val_loader,
                threshold=args.threshold,
                skeleton_threshold=args.skeleton_threshold,
                tile_size=args.img_size,
                stride=args.overlap_stride,
                stage_topology_alpha_scale=1.0,
            )

        best_eval_msg = (
            f"Best Checkpoint Eval, Val Loss: {best_val_metrics['loss']:.4f}, "
            f"Surface IoU: {best_val_metrics['surface_iou']:.4f}, Surface F1: {best_val_metrics['surface_f1']:.4f}"
        )
        print("\n" + best_eval_msg, flush=True)
        with open(training_log_path, 'a', encoding='utf-8') as log_f:
            log_f.write("\n" + best_eval_msg + "\n")
    
    print("\n训练完成!")
    print(f"   best.pth: {best_path}")
    print(f"   last.pth: {os.path.join(args.output_dir, 'last.pth')}")
    print(f"Training log: {training_log_path}")
