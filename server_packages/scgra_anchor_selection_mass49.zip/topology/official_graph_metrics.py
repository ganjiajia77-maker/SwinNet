"""Adapters for pinned Sat2Graph TOPO and CosmiQ APLS source functions.

Only raster skeleton to graph conversion is ours. Matching, control point
insertion, path scoring and local topology walking use upstream functions.
"""

import ast
import hashlib
from contextlib import redirect_stdout
from functools import lru_cache
import math
import random
import os
from pathlib import Path
import tempfile
import time
from types import ModuleType

import networkx as nx
import numpy as np
import scipy
import shapely
from shapely.geometry import LineString, Point
import utm

from vendor.sat2graph import graph as sat_graph
from vendor.sat2graph import topo as sat_topo


VENDOR = Path(__file__).parent / "vendor" / "cosmiq"
TLTS_VENDOR = Path(__file__).parent / "vendor" / "metrics_delin"


class CompatibleMultiGraph(nx.MultiGraph):
    """Expose the NetworkX 1.x node alias used by CosmiQ's KD tree helper."""

    @property
    def node(self):
        return self.nodes

    def to_undirected_class(self):
        return CompatibleMultiGraph


def _load_functions(path, names, namespace):
    tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    selected = [node for node in tree.body
                if isinstance(node, (ast.FunctionDef, ast.ClassDef)) and node.name in names]
    missing = set(names) - {node.name for node in selected}
    if missing:
        raise RuntimeError(f"Pinned CosmiQ source lacks functions: {sorted(missing)}")
    exec(compile(ast.Module(body=selected, type_ignores=[]), str(path), "exec"), namespace)


def _safe_query_kd_nearest(kdtree, kd_idx_dic, point, n_neighbors=10,
                           distance_upper_bound=1000, keep_point=True):
    """Drop SciPy's missing-neighbor sentinel before resolving node IDs.

    SciPy returns index tree.n and infinite distance for each unavailable
    neighbor, including when fewer than k nodes fall inside the distance bound.
    With no nearby nodes the upstream edge search falls back to all edges.
    """
    distances, indexes = kdtree.query(point, k=n_neighbors,
                                     distance_upper_bound=distance_upper_bound)
    valid = [(int(idx), float(distance)) for idx, distance in
             zip(np.atleast_1d(indexes), np.atleast_1d(distances))
             if np.isfinite(distance) and int(idx) in kd_idx_dic]
    return ([kd_idx_dic[idx] for idx, _ in valid],
            [idx for idx, _ in valid], [distance for _, distance in valid])


@lru_cache(maxsize=1)
def _cosmiq():
    import copy
    import random

    utils = ModuleType("apls_utils")
    utils.__dict__.update(np=np, scipy=scipy, time=time)
    _load_functions(VENDOR / "apls_utils.upstream.py.txt",
                    ("nodes_near_point", "G_to_kdtree", "_query_kd_nearest", "_query_kd_ball"),
                    utils.__dict__)
    # Preserve the pinned upstream source; adapt its lookup to SciPy's
    # out-of-range sentinel for neighbors outside the search radius.
    utils._query_kd_nearest = _safe_query_kd_nearest
    module = ModuleType("apls_official_core")
    module.__dict__.update(nx=nx, np=np, scipy=scipy, shapely=shapely,
                           Point=Point, LineString=LineString, utm=utm,
                           copy=copy, random=random, math=math, time=time, os=os,
                           apls_utils=utils)
    _load_functions(VENDOR / "apls.upstream.py.txt",
                    ("add_travel_time", "create_edge_linestrings", "cut_linestring",
                     "get_closest_edge_from_G", "insert_point_into_G", "insert_control_points",
                     "create_graph_midpoints", "make_graphs", "single_path_metric",
                     "path_sim_metric", "compute_apls_metric"), module.__dict__)
    original_edge_search = module.get_closest_edge_from_G
    module.original_get_closest_edge_from_G = original_edge_search

    def indexed_edge_search(graph, point, nearby_nodes_set=set(), verbose=False):
        return _indexed_closest_edge(graph, point, nearby_nodes_set,
                                     original_edge_search, verbose=verbose)

    module.get_closest_edge_from_G = indexed_edge_search
    return module


@lru_cache(maxsize=1)
def _tlts():
    """Load the paper authors' TLTS function and its required helpers."""
    import time as clock

    utils = ModuleType("metrics_delin_tlts_utils")
    utils.__dict__.update(np=np, nx=nx, random=random, time=clock)
    _load_functions(TLTS_VENDOR / "utils.upstream.py.txt",
                    ("is_empty", "interpolate_new_nodes", "oversampling_graph",
                     "length_path", "find_closest", "uniform_node_sampling"), utils.__dict__)
    # The released code targets NetworkX 1.x; its rare fallback passes a
    # NodeView to np.random.choice. Adapt only that API call for NetworkX 3.x.
    sampler = utils.uniform_node_sampling
    source = (TLTS_VENDOR / "utils.upstream.py.txt").read_text(encoding="utf-8")
    source = source.replace("np.random.choice(G.nodes())", "np.random.choice(list(G.nodes()))")
    tree = ast.parse(source)
    node = next(n for n in tree.body if isinstance(n, ast.FunctionDef)
                and n.name == "uniform_node_sampling")
    exec(compile(ast.Module(body=[node], type_ignores=[]), sampler.__code__.co_filename,
                 "exec"), utils.__dict__)
    module = ModuleType("metrics_delin_tlts_official")
    module.__dict__.update(np=np, nx=nx, random=random, utils=utils)
    _load_functions(TLTS_VENDOR / "toolong_tooshort_metric.upstream.py.txt",
                    ("toolong_tooshort",), module.__dict__)
    return module


class _NullWriter:
    def write(self, value):
        return len(value)

    def flush(self):
        pass


def _graph_node_ranks(graph):
    """Track NetworkX node order as the upstream insertion grows a graph."""
    ranks = getattr(graph, "_apls_node_ranks", None)
    if ranks is None:
        ranks = {node: i for i, node in enumerate(graph)}
    elif len(ranks) + 1 == len(graph):
        new_node = next(reversed(graph._node))
        if new_node in ranks:
            ranks = {node: i for i, node in enumerate(graph)}
        else:
            ranks[new_node] = len(ranks)
    elif len(ranks) != len(graph):
        ranks = {node: i for i, node in enumerate(graph)}
    graph._apls_node_ranks = ranks
    return ranks


def _indexed_closest_edge(graph, point, nearby_nodes_set, original, verbose=False):
    """Visit incident edges only, retaining upstream first-edge tie breaking."""
    if not nearby_nodes_set:
        return original(graph, point, nearby_nodes_set=nearby_nodes_set,
                        verbose=verbose)
    candidates = list(graph.edges(nearby_nodes_set, keys=True, data=True))
    if not candidates:
        return original(graph, point, nearby_nodes_set=nearby_nodes_set,
                        verbose=verbose)
    ranks = _graph_node_ranks(graph)
    distances = [point.distance(data["geometry"]) for _, _, _, data in candidates]
    minimum = min(distances)
    winners = [i for i, distance in enumerate(distances) if distance == minimum]

    def original_order(i):
        u, v, key, _ = candidates[i]
        first, second = (u, v) if ranks[u] <= ranks[v] else (v, u)
        return (ranks[first], list(graph._adj[first]).index(second),
                list(graph._adj[first][second]).index(key))

    chosen = winners[0] if len(winners) == 1 else min(winners, key=original_order)
    u, v, key, data = candidates[chosen]
    if ranks[u] > ranks[v]:
        u, v = v, u
    return [u, v, key], minimum, data["geometry"]


def _neighbors(csr):
    return [list(map(int, csr.indices[csr.indptr[i]:csr.indptr[i + 1]]))
            for i in range(csr.shape[0])]


def compact_graph(points, csr, id_offset=0):
    """Contract degree-two chains without changing their pixel polyline or length."""
    graph = CompatibleMultiGraph()
    neighbors = _neighbors(csr)
    n = len(points)
    anchors = {i for i, adjacent in enumerate(neighbors) if len(adjacent) != 2}
    visited = set()

    def pair(a, b):
        return (min(a, b), max(a, b))

    def add_node(i):
        y, x = map(int, points[i])
        graph.add_node(int(i + id_offset), x=float(x), y=float(y))

    def add_chain(chain):
        if len(chain) < 2:
            return
        coords = [(float(points[i, 1]), float(points[i, 0])) for i in chain]
        for i in (chain[0], chain[-1]):
            add_node(i)
        geometry = LineString(coords)
        graph.add_edge(int(chain[0] + id_offset), int(chain[-1] + id_offset),
                       geometry=geometry, length=float(geometry.length),
                       inferred_speed_mps=1.0)

    for anchor in sorted(anchors):
        add_node(anchor)
        for neighbor in neighbors[anchor]:
            if pair(anchor, neighbor) in visited:
                continue
            chain = [anchor, neighbor]
            visited.add(pair(anchor, neighbor))
            prev, current = anchor, neighbor
            while current not in anchors:
                nxt = next(v for v in neighbors[current] if v != prev)
                if pair(current, nxt) in visited:
                    raise ValueError("Pixel graph traversal repeated an edge")
                visited.add(pair(current, nxt))
                chain.append(nxt)
                prev, current = current, nxt
            if chain[0] == chain[-1]:
                # NetworkX loops lose the two alternative routes around a ring.
                cuts = sorted(set((0, len(chain) // 3, 2 * len(chain) // 3, len(chain) - 1)))
                for a, b in zip(cuts, cuts[1:]):
                    add_chain(chain[a:b + 1])
            else:
                add_chain(chain)

    # All-degree-two components are closed loops without a natural anchor.
    for start in range(n):
        if start in anchors:
            continue
        for neighbor in neighbors[start]:
            if pair(start, neighbor) in visited:
                continue
            chain = [start, neighbor]
            visited.add(pair(start, neighbor))
            prev, current = start, neighbor
            while current != start:
                nxt = next(v for v in neighbors[current] if v != prev)
                if pair(current, nxt) in visited:
                    raise ValueError("Pixel ring traversal repeated an edge")
                visited.add(pair(current, nxt))
                chain.append(nxt)
                prev, current = current, nxt
            cuts = sorted(set((0, len(chain) // 3, 2 * len(chain) // 3, len(chain) - 1)))
            for a, b in zip(cuts, cuts[1:]):
                add_chain(chain[a:b + 1])

    if sum(len(v) for v in neighbors) // 2 != len(visited):
        raise ValueError("Pixel graph contraction lost an edge")
    return graph


def _sat_coordinates(y, x):
    # Sat2Graph main.py's synthetic coordinates: one image pixel is one metre.
    return 41.0 - float(y) / 111111.0, -71.0 + float(x) / (111111.0 * math.cos(math.radians(41)))


def _sat_road_graph(points, csr):
    graph = sat_graph.RoadGraph()
    for i in range(len(points)):
        lat1, lon1 = _sat_coordinates(*points[i])
        for j in csr.indices[csr.indptr[i]:csr.indptr[i + 1]]:
            lat2, lon2 = _sat_coordinates(*points[j])
            graph.addEdge(int(i), lat1, lon1, int(j), lat2, lon2,
                          nodeScore1=100, nodeScore2=100, edgeScore=100)
    graph.ReverseDirectionLink()
    return graph


def prepare_official_graph(points, csr, id_offset=0):
    return {"points": points, "csr": csr,
            "compact": compact_graph(points, csr, id_offset)}


def _tlts_graph(points, csr):
    """Represent the exact eight-neighbour raster skeleton for official TLTS."""
    graph = nx.Graph()
    graph.add_nodes_from((int(i), {"pos": (float(x), float(y))})
                         for i, (y, x) in enumerate(points))
    for i in range(len(points)):
        graph.add_edges_from((i, int(j)) for j in csr.indices[csr.indptr[i]:csr.indptr[i + 1]]
                             if j > i)
    graph.remove_nodes_from(list(nx.isolates(graph)))
    return graph


def _official_tlts(gt, pred, protocol):
    reference = _tlts_graph(gt["points"], gt["csr"])
    proposed = _tlts_graph(pred["points"], pred["csr"])
    seed_bytes = hashlib.sha256(
        np.asarray(gt["points"], dtype=np.int32).tobytes()
        + int(protocol["tlts_seed"]).to_bytes(8, "little")
    ).digest()
    seed = int.from_bytes(seed_bytes[:4], "little")
    # The upstream function seeds NumPy globally. Preserve both RNG states so
    # repeat runs and model order do not affect its randomized path sampling.
    numpy_state, python_state = np.random.get_state(), random.getstate()
    try:
        random.seed(seed)
        with redirect_stdout(_NullWriter()):
            values = _tlts().toolong_tooshort(
                reference, proposed,
                max_node_dist=protocol["tlts_max_node_dist_px"],
                perc_length=protocol["tlts_length_tolerance"],
                n_paths=protocol["tlts_n_paths"], seed=seed)
    finally:
        np.random.set_state(numpy_state)
        random.setstate(python_state)
    if len(values) != 4 or not np.isfinite(values).all() or not np.isclose(sum(values), 1.0):
        raise RuntimeError(f"Official TLTS returned invalid path categories: {values}")
    return tuple(map(float, values))


def _sat_topo_score(gt, pred, protocol):
    if len(gt["points"]) == 0 and len(pred["points"]) == 0:
        return 1.0, 1.0, 0
    if len(gt["points"]) == 0 or len(pred["points"]) == 0:
        return 0.0, 0.0, 0
    ground = _sat_road_graph(gt["points"], gt["csr"])
    proposal = _sat_road_graph(pred["points"], pred["csr"])
    all_points = np.vstack((gt["points"], pred["points"]))
    min_lat, _ = _sat_coordinates(int(all_points[:, 0].max()), 0)
    _, max_lon = _sat_coordinates(0, int(all_points[:, 1].max()))
    region = [min_lat - 300 / 111111.0, -71.0 - 500 / 111111.0,
              41.0 + 300 / 111111.0, max_lon + 500 / 111111.0]
    ground.region = proposal.region = region
    with redirect_stdout(_NullWriter()):
        seeds = sat_topo.TOPOGenerateStartingPoints(
            ground, density=protocol["topo_seed_density_deg"], region=region,
            image="NULL", check=False, direction=False)
        if not seeds:
            return 0.0, 0.0, 0
        pairs = sat_topo.TOPOGeneratePairs(
            proposal, ground, seeds, threshold=0.00010, region=region)
        if not pairs:
            return 0.0, 0.0, len(seeds)
        radius = 0.00150 if 41.0 - min_lat < 0.01000 else 0.00300
        with tempfile.TemporaryDirectory() as temp:
            result = sat_topo.TOPOWithPairs(
                proposal, ground, pairs, seeds, r=radius,
                step=protocol["topo_step_deg"],
                threshold=0.00010, outputfile=str(Path(temp) / "topo.txt"),
                one2oneMatching=True, metaData=None)
    precision, matched_recall = sat_topo.topoAvg(result)
    return float(precision), float(matched_recall * len(result) / len(seeds)), len(seeds)


def _apls_native_graph(graph):
    """Apply the same edge cleanup and travel-time preparation as make_graphs."""
    apls = _cosmiq()
    with redirect_stdout(_NullWriter()):
        cleaned = apls.create_edge_linestrings(graph.copy().to_undirected())
        return apls.add_travel_time(cleaned.copy())


def _apls_controls(graph, points, protocol):
    nodes = list(graph.nodes())
    maximum = protocol.get("apls_max_control_nodes", 0)
    if maximum and len(nodes) > maximum:
        seed_bytes = hashlib.sha256(
            np.asarray(points, dtype=np.int32).tobytes()
            + int(protocol["apls_control_sampling_seed"]).to_bytes(8, "little")
        ).digest()
        rng = random.Random(int.from_bytes(seed_bytes[:8], "little"))
        nodes = [nodes[i] for i in sorted(rng.sample(range(len(nodes)), maximum))]
    return [[node, graph.nodes[node]["x"], graph.nodes[node]["y"]]
            for node in nodes]


def prepare_apls_reference(gt, protocol=None):
    """Compute original-node GT paths once and reuse them for every prediction."""
    protocol = protocol or {"apls_max_control_nodes": 0,
                            "apls_control_sampling_seed": 1234}
    key = (protocol["apls_max_control_nodes"],
           protocol["apls_control_sampling_seed"])
    cache = gt.setdefault("apls_references", {})
    if key not in cache:
        graph = _apls_native_graph(gt["compact"])
        controls = _apls_controls(graph, gt["points"], protocol)
        cache[key] = {
            "controls": controls,
            "paths": _apls_control_paths(graph, controls),
        }
    return cache[key]


def _apls_control_paths(graph, controls):
    """Only retain paths that the pinned scorer reads between control nodes."""
    control_ids = {point[0] for point in controls}
    return {
        node: {target: distance for target, distance in
               nx.single_source_dijkstra_path_length(graph, node, weight="length").items()
               if target in control_ids}
        for node in control_ids if node in graph
    }


def _official_apls(gt, pred, protocol):
    apls = _cosmiq()
    counts = {"gt": 0, "pred": 0}
    timing = {}
    reference = prepare_apls_reference(gt, protocol)
    with redirect_stdout(_NullWriter()):
        started = time.perf_counter()
        pred_graph = _apls_native_graph(pred["compact"])
        controls_pred = _apls_controls(pred_graph, pred["points"], protocol)
        paths_pred = _apls_control_paths(pred_graph, controls_pred)
        timing["pred_native"] = time.perf_counter() - started

        started = time.perf_counter()
        pred_prime, _, _ = apls.insert_control_points(
            pred_graph.copy(), reference["controls"],
            max_distance_meters=protocol["apls_snap_radius"],
            allow_renaming=True, verbose=False)
        gt_prime, _, _ = apls.insert_control_points(
            gt["compact"].copy(), controls_pred,
            max_distance_meters=protocol["apls_snap_radius"],
            allow_renaming=True, verbose=False)
        pred_prime = apls.add_travel_time(pred_prime.copy())
        gt_prime = apls.add_travel_time(gt_prime.copy())
        timing["control_insert"] = time.perf_counter() - started

        started = time.perf_counter()
        paths_pred_prime = _apls_control_paths(pred_prime, reference["controls"])
        paths_gt_prime = _apls_control_paths(gt_prime, controls_pred)
        timing["prime_paths"] = time.perf_counter() - started

        started = time.perf_counter()
        captures = []
        official_path = apls.path_sim_metric

        def capture(*args, **kwargs):
            result = official_path(*args, **kwargs)
            captures.append(result)
            return result

        apls.path_sim_metric = capture
        try:
            total, forward, reverse = apls.compute_apls_metric(
                reference["paths"], paths_pred, paths_gt_prime, paths_pred_prime,
                reference["controls"], controls_pred,
                min_path_length=protocol["apls_min_path_px"])
        finally:
            apls.path_sim_metric = official_path
        timing["score"] = time.perf_counter() - started
    if captures:
        for direction, captured in zip(("gt", "pred"), captures):
            counts[direction] = len(captured[2])
    counts["gt_controls"] = len(reference["controls"])
    counts["pred_controls"] = len(controls_pred)
    return float(total), float(forward), float(reverse), counts, timing


def graph_scores(gt, pred, protocol, timing_label=None):
    started = time.perf_counter()
    precision, recall, seeds = _sat_topo_score(gt, pred, protocol)
    topo_seconds = time.perf_counter() - started
    if timing_label:
        print(f"[TIMING] {timing_label} TOPO={topo_seconds:.1f}s seeds={seeds}", flush=True)
    started = time.perf_counter()
    apls_total, apls_forward, apls_reverse, pairs, apls_timing = _official_apls(
        gt, pred, protocol)
    apls_seconds = time.perf_counter() - started
    if timing_label:
        print(f"[TIMING] {timing_label} APLS={apls_seconds:.1f}s "
              f"controls_gt={pairs['gt_controls']} controls_pred={pairs['pred_controls']} "
              f"pred_native={apls_timing['pred_native']:.1f}s "
              f"insert={apls_timing['control_insert']:.1f}s "
              f"prime_paths={apls_timing['prime_paths']:.1f}s "
              f"score={apls_timing['score']:.1f}s", flush=True)
    started = time.perf_counter()
    tlts_correct, tlts_too_long, tlts_too_short, tlts_infeasible = _official_tlts(
        gt, pred, protocol)
    tlts_seconds = time.perf_counter() - started
    if timing_label:
        print(f"[TIMING] {timing_label} TLTS={tlts_seconds:.1f}s", flush=True)
    topo_f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    return {
        "topo_precision": precision, "topo_recall": recall, "topo_f1": topo_f1,
        "topo_gt_seeds": seeds,
        "apls_gt_to_pred": apls_forward, "apls_pred_to_gt": apls_reverse,
        "apls_bidirectional": apls_total,
        "apls_gt_pairs": pairs["gt"], "apls_pred_pairs": pairs["pred"],
        "apls_gt_controls": pairs["gt_controls"],
        "apls_pred_controls": pairs["pred_controls"],
        "tlts_correct": tlts_correct, "tlts_too_long": tlts_too_long,
        "tlts_too_short": tlts_too_short, "tlts_infeasible": tlts_infeasible,
        "timing_topo_seconds": topo_seconds,
        "timing_apls_seconds": apls_seconds,
        "timing_apls_pred_native_seconds": apls_timing["pred_native"],
        "timing_apls_control_insert_seconds": apls_timing["control_insert"],
        "timing_apls_prime_paths_seconds": apls_timing["prime_paths"],
        "timing_apls_score_seconds": apls_timing["score"],
        "timing_tlts_seconds": tlts_seconds,
    }
