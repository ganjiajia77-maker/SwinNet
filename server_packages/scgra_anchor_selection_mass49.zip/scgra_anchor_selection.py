"""Measure anchor road hits and change only the anchor selector at inference."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
from unittest.mock import patch

import numpy as np


CANDIDATE_K = (32, 64, 128, 192, 256)
ANCHOR_K = (4, 8, 16, 24, 32)
MODES = ('full', 'probability_only', 'random_candidates')
CHECKPOINT_SHA = '75145caf960def5eddc56ea622ab1fe79459d63f9a484bf75f7a7b68ce815c17'
ARCHIVED_FULL_MASK_SHA = 'a3b4cd5b5a1d8b1ca3938f1de920c1fcb7f591fe34a61f2cede4fc48b944e7e2'
PROTOCOL = dict(image_size=1500, short_area_threshold=20, topo_seed_density_deg=.002,
                topo_step_deg=.0002, apls_max_control_nodes=150, apls_snap_radius=5.,
                apls_control_sampling_seed=1234, apls_min_path_px=10., tlts_n_paths=200, tlts_seed=1234)


def ranked_points(selection, kind):
    valid = selection[kind + '_valid'][0].numpy()
    return selection[kind + '_coords'][0].numpy()[valid].copy()


def hit_rows(case, gt, windows):
    rows = []
    for stage, budgets in (('candidates', CANDIDATE_K), ('anchors', ANCHOR_K)):
        for method in MODES[:2]:
            for budget in budgets:
                selections = [w[stage][method][:budget] + w['offset'] for w in windows]
                points = np.concatenate(selections, axis=0)
                unique = np.unique(points, axis=0)
                hits = int(gt[unique[:, 0], unique[:, 1]].sum())
                rows.append(dict(case_id=case, stage=stage, method=method, k=budget,
                                 road_hits=hits, unique_points=len(unique), point_events=len(points),
                                 windows=len(windows), road_hit_rate=hits/len(unique) if len(unique) else None))
    return rows


def matched_k(selection, n):
    coords, valid, scores, candidates = selection
    if int(valid.sum()) < n:
        raise RuntimeError('Control cannot match the valid Full anchor count')
    coords[:, n:] = 0
    valid[:, n:] = False
    scores[:, n:] = 0
    return coords, valid, scores, candidates


def infer(model, image, case, seed):
    import torch
    from torch.nn import functional as F
    from diagnostics.scgra_export import seeded_rng
    from mass_protocol import sliding_positions, stitch_logits

    module = model.swin_unet.global_topology
    feature_forward = module.forward_feature_anchors
    extract = module._extract_fps_anchors
    positions = sliding_positions(1500, 512, 256)
    offsets = [(y, x) for y in positions for x in positions]
    traces = []
    replacement = {mode: [] for mode in MODES[1:]}

    def capture(feature, z_struct, surface_prob, connectivity_feature=None):
        if feature.shape[0] != 1 or feature.shape[-2:] != (512, 512):
            raise ValueError('Expected original decoder-control SCGRA 512 × 512 anchor grid')
        y, x = offsets[len(traces)]
        prior = surface_prob.detach().to(feature.dtype)
        if prior.shape[-2:] != (512, 512):
            prior = F.interpolate(prior, size=(512, 512), mode='bilinear', align_corners=False)

        def select(score):
            original = extract(score)
            full = module.last_anchor_selection
            n = int(original[1].sum())
            probability = matched_k(extract(prior.clamp(0, 1)), n)
            prob = module.last_anchor_selection
            traces.append(dict(offset=(y, x),
                candidates={'full': ranked_points(full, 'candidate'),
                            'probability_only': ranked_points(prob, 'candidate')},
                anchors={'full': ranked_points(full, 'selected'),
                         'probability_only': ranked_points(prob, 'selected')[:n]}))
            ids = seeded_rng(seed, case, y, x, 0).choice(score.numel(), 256, replace=False)
            random_score = torch.zeros_like(score)
            random_score.view(-1)[torch.as_tensor(ids, device=score.device)] = torch.linspace(
                1., .001, len(ids), device=score.device, dtype=score.dtype)
            random = matched_k(extract(random_score), n)
            module.last_anchor_selection = full
            replacement['probability_only'].append(probability)
            replacement['random_candidates'].append(random)
            return original

        with patch.object(module, '_extract_fps_anchors', select):
            return feature_forward(feature, z_struct, surface_prob, connectivity_feature)

    def run():
        logits, _ = stitch_logits(lambda window: model(window)[0], image)
        return logits.sigmoid()[0, 0].cpu().numpy()

    with torch.inference_mode():
        with patch.object(module, 'capture_anchor_selection', True, create=True), \
             patch.object(module, 'last_anchor_selection', None, create=True), \
             patch.object(module, 'forward_feature_anchors', capture):
            predictions = {'full': run()}
        if len(traces) != len(offsets) or len(traces) != 25:
            raise RuntimeError('Expected one selector call per window and 25 windows per image')
        for mode, tensors in replacement.items():
            choices = iter(tensors)
            with patch.object(module, '_extract_fps_anchors', lambda _score: next(choices)):
                predictions[mode] = run()
            if next(choices, None) is not None:
                raise RuntimeError('A control forward skipped an anchor-selection window')
    return predictions, traces


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('repo', 'checkpoint', 'root_path', 'output_dir'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--selection', type=Path)
    parser.add_argument('--device', default='cuda:0')
    parser.add_argument('--seed', type=int, default=1234)
    parser.add_argument('--max_images', type=int, choices=range(50), default=0, metavar='0..49')
    args = parser.parse_args()
    repo, output = args.repo.resolve(), args.output_dir.resolve()
    sys.path.insert(0, str(repo))
    import cv2
    import torch
    from diagnostics import scgra_decoder_mass as mass
    from scripts.benchmark_scgra_relation_bias import pixel_row, aggregate_pixels
    from scripts.export_scgra_decoder_mass import dump, load, save_png, source_hashes, write_csv

    cv2.setNumThreads(1)
    torch.set_num_threads(2)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    device = torch.device(args.device)
    if device.type == 'cuda' and not torch.cuda.is_available():
        parser.error('CUDA is unavailable')
    checkpoint = args.checkpoint.resolve(strict=True)
    sha = mass.file_digest(checkpoint)
    if sha != CHECKPOINT_SHA:
        parser.error('Expected the original decoder-control checkpoint used for the test49 anchor analysis')
    selection, _, threshold = mass.select_validation_record(checkpoint, sha, args.selection)
    if abs(threshold - .45) > 1e-7:
        parser.error('Use the archived original validation selection with threshold 0.45')
    data_root = args.root_path.resolve(strict=True)
    data = mass.dataset(data_root, 'test')
    cases = [Path(n).stem for n in data.image_files][:args.max_images or None]
    config = dict(split='test', checkpoint_sha256=sha, cases=cases, seed=args.seed, tile_size=512, stride=256,
                  threshold=threshold, selection_sha256=mass.file_digest(selection), modes=list(MODES),
                  random='256 uniform unique candidates with seeded rank, followed by the original FPS',
                  candidate_k=list(CANDIDATE_K), anchor_k=list(ANCHOR_K), exact_gt_hit=True,
                  aggregation='within-image deduplicated pixel coordinates; paired image as unit',
                  source_sha256={**source_hashes(), 'anchor_selection':mass.file_digest(__file__)})
    output.mkdir(parents=True, exist_ok=True)
    meta = output/'metadata.json'
    if meta.is_file() and load(meta) != config:
        parser.error('Existing output uses different inputs or code. Choose a new output directory.')
    if not meta.is_file():
        if any(output.iterdir()):
            parser.error('Use an empty output directory')
        dump(meta, config)
    (output/'partial').mkdir(exist_ok=True)
    for mode in MODES:
        (output/'masks'/mode).mkdir(parents=True, exist_ok=True)

    model, _, epoch = mass.load_model(checkpoint, device)
    before = mass.tensor_digests(model)
    pixels, hits = [], []
    for index, case in enumerate(cases):
        record_path = output/'partial'/f'{case}.json'
        inputs = [mass.file_digest(Path(base)/n) for base, n in
                  ((data.image_dir, data.image_files[index]), (data.mask_dir, data.label_files[index]))]
        record = load(record_path) if record_path.is_file() else None
        if record is not None and record['inputs'] != inputs:
            raise ValueError(f'Image or ground truth changed: {case}')
        if record is None or not all((output/p).is_file() and mass.file_digest(output/p) == sig
                                     for p, sig in record['masks'].items()):
            _, image, gt = mass.read_sample(data, index)
            preds, traces = infer(model, image[None].to(device), case, args.seed)
            full = preds['full']
            record = dict(inputs=inputs, hits=hit_rows(case, gt, traces), pixels=[], masks={})
            for mode, prob in preds.items():
                relative = f'masks/{mode}/{case}.png'
                save_png(output/relative, (prob >= threshold).astype(np.uint8)*255)
                record['masks'][relative] = mass.file_digest(output/relative)
                record['pixels'].append(pixel_row(case, mode, threshold, prob, full, gt, full >= threshold))
            dump(record_path, record)
        hits.extend(record['hits'])
        pixels.extend(record['pixels'])
        print(f'[SCGRA selection] {index+1}/{len(cases)} {case}', flush=True)

    if before != mass.tensor_digests(model) or mass.file_digest(checkpoint) != sha:
        raise RuntimeError('Model state or checkpoint changed')
    write_csv(output/'anchor_hits_per_image.csv', hits)
    write_csv(output/'segmentation_per_image.csv', pixels)
    write_csv(output/'segmentation_summary.csv', aggregate_pixels(pixels, []))
    complete = dict(images=len(cases), checkpoint_epoch=epoch, threshold=threshold)
    if len(cases) == 49:
        fingerprint = hashlib.sha256()
        for case in sorted(cases):
            image = cv2.imread(str(output/'masks'/'full'/f'{case}.png'), cv2.IMREAD_GRAYSCALE)
            fingerprint.update(case.encode() + b'\0' + np.packbits(image > 0).tobytes())
        complete['full_binary_mask_sha256'] = fingerprint.hexdigest()
        complete['full_masks_match_archived_f3'] = fingerprint.hexdigest() == ARCHIVED_FULL_MASK_SHA
        models = [dict(name=mode,
                       provenance=dict(checkpoint_sha256=sha, checkpoint_epoch=epoch, intervention=mode,
                                       random_seed=args.seed),
                       validation_selection=dict(selected_on='val', criterion='global_iou', threshold=threshold,
                                                 evidence=str(selection)),
                       predictions=dict(val=[], test=[dict(path=str(output/'masks'/mode), threshold=threshold)]))
                  for mode in MODES]
        dump(output/'comparison.json', dict(data_root=str(data_root), protocol=PROTOCOL, models=models))
    dump(output/'export_complete.json', complete)
    print('[DONE]', output, flush=True)


if __name__ == '__main__':
    main()
