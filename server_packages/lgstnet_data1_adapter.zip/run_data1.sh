#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
DATA=${DATA:-/home/gjj/Swin-Unet-main/data1}
RESULTS=${RESULTS:-/home/gjj/LGSTNet-results}
METRICS=${METRICS:-/home/gjj/unified-road-baselines-a85dd4f/evaluation/road_comparison}
WEIGHT=${WEIGHT:-$PWD/weights/resnet18-f37072fd.pth}
GPU=${GPU:-0}
mkdir -p "$RESULTS"
case "${1:-}" in
train)
  test -f "$WEIGHT" || { echo "Missing ResNet18 weights: $WEIGHT"; exit 1; }
  RUN=${RUN:-lgstnet_data1_random512_fp32_ema0999_80e_$(date +%Y%m%d_%H%M%S)}
  test ! -e "$RESULTS/$RUN" || { echo "Run already exists: $RUN"; exit 1; }
  printf '%s\n' "$RUN" > "$RESULTS/latest_lgstnet_run.txt"
  CUDA_VISIBLE_DEVICES="$GPU" python -u train_data1.py --root_path "$DATA" --output_dir "$RESULTS" --run_name "$RUN" --pretrain_ckpt "$WEIGHT" --max_epochs 80 --batch_size 2 --num_workers 4 --val_interval 5 --lr 0.0001 --seed 1234 --use_ema --ema_decay 0.999 2>&1 | tee "$RESULTS/$RUN.log"
  ;;
sweep)
  RUN=${RUN:-$(cat "$RESULTS/latest_lgstnet_run.txt")}; REPORT="$RESULTS/$RUN/unified"
  CKPT="$RESULTS/$RUN/best.pth"; test -f "$CKPT"
  CUDA_VISIBLE_DEVICES="$GPU" python -u threshold_sweep_data1.py --root_path "$DATA" --model_path "$CKPT" --output_dir "$REPORT/val_inference" --save_masks
  python unified_manifest.py --root_path "$DATA" --checkpoint "$CKPT" --report "$REPORT"
  python -u "$METRICS/compare_predictions.py" --manifest "$REPORT/comparison.json" --split val --select_threshold_only --output_dir "$REPORT/val" --progress_every 50
  ;;
test)
  RUN=${RUN:-$(cat "$RESULTS/latest_lgstnet_run.txt")}; REPORT="$RESULTS/$RUN/unified"; CKPT="$RESULTS/$RUN/best.pth"
  THRESHOLD=$(python -c 'import json,sys;print(json.load(open(sys.argv[1]))["models"]["lgstnet_data1"]["threshold"])' "$REPORT/val/val_selection.json")
  CUDA_VISIBLE_DEVICES="$GPU" python -u test_data1.py --root_path "$DATA" --model_path "$CKPT" --output_dir "$REPORT/test_inference" --threshold "$THRESHOLD"
  python unified_manifest.py --root_path "$DATA" --checkpoint "$CKPT" --report "$REPORT" --threshold "$THRESHOLD" --test_masks "$REPORT/test_inference/masks"
  ;;
topology)
  RUN=${RUN:-$(cat "$RESULTS/latest_lgstnet_run.txt")}; REPORT="$RESULTS/$RUN/unified"
  python -u "$METRICS/compare_predictions.py" --manifest "$REPORT/comparison.json" --split test --selection "$REPORT/val/val_selection.json" --output_dir "$REPORT/test_topology" --workers 4 --progress_every 1
  python "$METRICS/show_topology_summary.py" "$REPORT/test_topology/test_comparison.csv"
  ;;
*) echo "Usage: bash run_data1.sh {train|sweep|test|topology}"; exit 2;;
esac
