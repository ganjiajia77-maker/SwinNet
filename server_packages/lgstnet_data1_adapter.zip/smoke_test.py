import argparse
import torch
from networks.LGSTNet import LGSTNet
from loss import dice_bce_loss

parser = argparse.ArgumentParser()
parser.add_argument('--pretrain_ckpt', required=True)
parser.add_argument('--batch_size', type=int, default=2)
args = parser.parse_args()
if not torch.cuda.is_available():
    raise RuntimeError('CUDA is unavailable')
model = LGSTNet(pretrained_resnet=args.pretrain_ckpt).cuda().train()
images = torch.randn(args.batch_size, 3, 512, 512, device='cuda')
target = (torch.rand(args.batch_size, 1, 512, 512, device='cuda') > 0.8).float()
prediction = model(images)
assert prediction.shape == target.shape, (prediction.shape, target.shape)
loss = dice_bce_loss()(target, prediction)
assert torch.isfinite(loss)
loss.backward()
assert any(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters())
print('PASS shape=', tuple(prediction.shape), 'loss=', float(loss),
      'peak_GiB=', round(torch.cuda.max_memory_allocated() / 1024**3, 3), flush=True)
