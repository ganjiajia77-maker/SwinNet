import argparse
import copy
import torch
from networks.LGSTNet import LGSTNet
from data1_common import initialize_gates
from loss import dice_bce_loss
from train_data1 import update_ema

parser = argparse.ArgumentParser()
parser.add_argument('--pretrain_ckpt', required=True)
parser.add_argument('--batch_size', type=int, default=2)
args = parser.parse_args()
if not torch.cuda.is_available():
    raise RuntimeError('CUDA is unavailable')
model = LGSTNet(pretrained_resnet=args.pretrain_ckpt).cuda()
gates = initialize_gates(model, 'cuda:0')
optimizer = torch.optim.AdamW(model.parameters(), lr=1e-4)
ema = copy.deepcopy(model).eval()
assert all(id(p) in {id(q) for group in optimizer.param_groups for q in group['params']} for p in gates.values())
before = {n: p.detach().clone() for n, p in gates.items()}
model.train()
images = torch.randn(args.batch_size, 3, 512, 512, device='cuda')
target = (torch.rand(args.batch_size, 1, 512, 512, device='cuda') > 0.8).float()
prediction = model(images)
assert prediction.shape == target.shape, (prediction.shape, target.shape)
loss = dice_bce_loss()(target, prediction)
assert torch.isfinite(loss)
loss.backward()
assert any(p.grad is not None and torch.isfinite(p.grad).all() and p.grad.abs().max() > 0 for p in gates.values())
optimizer.step()
assert any(not torch.equal(before[n], p) for n, p in gates.items())
update_ema(ema, model, 0.999)
assert set(ema.state_dict()) == set(model.state_dict())
saved = {n: p.detach().clone() for n, p in gates.items()}
model.eval()
with torch.no_grad():
    output = model(images[:1])
assert output.shape == (1, 1, 512, 512)
assert all(torch.equal(saved[n], p) and p is dict(model.named_parameters())[n] for n, p in gates.items())
print('PASS gates={} optimizer=ok gradient=ok updated=ok ema=ok batch_change=ok shape={} loss={:.6f} peak_GiB={:.3f}'.format(
    len(gates), tuple(output.shape), float(loss), torch.cuda.max_memory_allocated()/1024**3), flush=True)
