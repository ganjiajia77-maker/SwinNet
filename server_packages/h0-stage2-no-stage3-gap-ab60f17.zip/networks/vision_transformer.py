# coding=utf-8
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import copy
import logging
import math

from os.path import join as pjoin

import torch
import torch.nn as nn
import numpy as np

from torch.nn import CrossEntropyLoss, Dropout, Softmax, Linear, Conv2d, LayerNorm
from torch.nn.modules.utils import _pair
from scipy import ndimage
from .swin_transformer_unet_skip_expand_decoder_sys import SwinTransformerSys

logger = logging.getLogger(__name__)

TOPOLOGY_ATTENTION_VERSION = "stage-topology-roadness-gap-v1"
STRUCTURE_PROFILE_FULL = "full"
STRUCTURE_PROFILE_STAGE23_BOUNDARY_0626 = "stage23_boundary_0626"
STRUCTURE_PROFILE_STAGE23_BOUNDARY_FINAL_SKE = "stage23_boundary_0626_final_ske"


def _core_swin_unet(model):
    module = model.module if hasattr(model, "module") else model
    return module.swin_unet


def get_topology_coefficients(model):
    module = model.module if hasattr(model, "module") else model
    swin_unet = module.swin_unet
    guided_head = swin_unet.guided_head
    coefficients = {
        "structure_profile": getattr(swin_unet, "structure_profile", "full"),
        "final_structure_enabled": bool(guided_head.enable_final_structure),
        "highres_structure_stream": {
            "enabled": bool(getattr(swin_unet, "enable_highres_structure_stream", False)),
            "source": "prepatch",
            "channels": int(getattr(swin_unet, "highres_structure_channels", 0)),
            "fuse_stages": getattr(swin_unet, "highres_structure_fuse_stages", "stage23"),
            "fusion_mode": getattr(swin_unet, "highres_structure_fusion_mode", "stage23"),
        },
        "global_topology_enabled": bool(getattr(swin_unet, "enable_global_topology", False)),
    }

    for stage in (2, 3):
        structure_block = swin_unet.decoder_structure_blocks[str(stage)]
        coefficients[f"decoder_stage{stage}"] = {
            "gamma1": float(structure_block.gamma1.detach().cpu()),
            "structure_enabled": bool(swin_unet._decoder_structure_enabled(stage)),
        }

    if guided_head.enable_final_structure:
        topology_attention = guided_head.final_topology_attention
        coefficients["final_topology"] = {
            "active": True,
            "raw_eta": float(topology_attention.raw_eta.detach().cpu()),
            "eta_eff": float(topology_attention.effective_eta().detach().cpu()),
            "raw_rho_gap": float(guided_head.raw_rho_gap.detach().cpu()),
            "rho_gap_eff": float(guided_head.effective_rho_gap().detach().cpu()),
        }
    else:
        coefficients["final_topology"] = {
            "active": False,
            "raw_eta": 0.0,
            "eta_eff": 0.0,
            "raw_rho_gap": 0.0,
            "rho_gap_eff": 0.0,
        }

    return coefficients


def apply_structure_profile_runtime(model):
    """Sync frozen topology flags after checkpoint load for 0626-style profiles."""
    module = model.module if hasattr(model, "module") else model
    swin_unet = module.swin_unet
    guided_head = swin_unet.guided_head
    if guided_head.enable_final_structure:
        return

    topology_attention = guided_head.final_topology_attention
    with torch.no_grad():
        if topology_attention is not None:
            topology_attention.fixed_eta.zero_()
            topology_attention.raw_eta.zero_()
        guided_head.fixed_rho_gap.zero_()
        guided_head.raw_rho_gap.zero_()
    if topology_attention is not None:
        topology_attention.raw_eta.requires_grad_(False)
    guided_head.raw_rho_gap.requires_grad_(False)


def format_topology_coefficients(model):
    coefficients = get_topology_coefficients(model)
    fields = [
        f"version={TOPOLOGY_ATTENTION_VERSION}",
        f"profile={coefficients['structure_profile']}",
        f"final_structure={'on' if coefficients['final_structure_enabled'] else 'off'}",
    ]
    highres_values = coefficients["highres_structure_stream"]
    fields.append(
        "highres_structure={} source={} channels={} fuse_stages={} fusion_mode={}".format(
            "on" if highres_values["enabled"] else "off",
            highres_values["source"],
            highres_values["channels"],
            highres_values["fuse_stages"],
            highres_values["fusion_mode"],
        )
    )
    fields.append(
        "global_topology={}".format(
            "on" if coefficients["global_topology_enabled"] else "off"
        )
    )
    for stage in ("decoder_stage2", "decoder_stage3"):
        values = coefficients[stage]
        enabled = "active" if values.get("structure_enabled") else "bypass"
        fields.append(
            "{}[{}] gamma1={:.6f}".format(
                stage,
                enabled,
                values["gamma1"],
            )
        )
    final_values = coefficients["final_topology"]
    if final_values.get("active"):
        fields.append(
            "final_topology raw_eta={:.6f} eta_eff={:.8f} "
            "raw_rho_gap={:.6f} rho_gap_eff={:.8f}".format(
                final_values["raw_eta"],
                final_values["eta_eff"],
                final_values["raw_rho_gap"],
                final_values["rho_gap_eff"],
            )
        )
    else:
        fields.append("final_topology=disabled")
    return " | ".join(fields)


def print_topology_coefficients(model, prefix="[TOPOLOGY]"):
    message = f"{prefix} {format_topology_coefficients(model)}"
    print(message, flush=True)
    return message


def load_topology_checkpoint_state(
    model,
    state_dict,
    checkpoint_version,
    strict=True,
):
    model_state = model.state_dict()
    highres_structure_missing_prefixes = (
        "swin_unet.highres_structure_encoder.",
        "swin_unet.prepatch_structure_encoder.",
        "swin_unet.highres_skeleton_adapter.",
        "swin_unet.highres_structure_skeleton_head.",
        "swin_unet.highres_structure_fusion.",
        "swin_unet.decoder_structure_blocks.2.highres_skeleton_fusion.",
        "swin_unet.decoder_structure_blocks.3.highres_skeleton_fusion.",
        "swin_unet.structure_surface_correction_head.",
        "swin_unet.guided_head.post_refine_structure_interaction.",
        "swin_unet.coarse_road_mask_head.",
        "swin_unet.bottleneck_coarse_road_mask_head.",
        "swin_unet.decoder_structure_blocks.2.external_structure_fusion.",
        "swin_unet.decoder_structure_blocks.2.external_structure_scale",
        "swin_unet.h3_surface_proj.",
        "swin_unet.surface_h3_fusion.",
    )

    def print_expected_highres_missing(missing_keys):
        expected = [
            key
            for key in missing_keys
            if key.startswith(highres_structure_missing_prefixes)
        ]
        if expected:
            print(
                "[TOPOLOGY] Expected new structure-stream missing keys: "
                + ", ".join(expected[:12])
                + (" ..." if len(expected) > 12 else ""),
                flush=True,
            )

    obsolete_unexpected_suffixes = (
        "decoder_connectivity_value_scale",
        "raw_gamma2",
        "road_bias_scale_a1",
        "road_bias_scale",
        "decoder_skeleton_bias_scale",
    )
    obsolete_unexpected_prefixes = (
        "swin_unet.encoder_stage1_road_attention_head.",
        "swin_unet.guided_head.surface_selective_fusion.",
        "swin_unet.stage2_topology_source.",
    )
    removed_direction_embedding_prefixes = (
        "swin_unet.decoder_structure_blocks.0.directional_embedding.",
        "swin_unet.decoder_structure_blocks.1.directional_embedding.",
        "swin_unet.decoder_structure_blocks.2.directional_embedding.",
        "swin_unet.decoder_structure_blocks.3.directional_embedding.",
        "swin_unet.stage2_topology_source.directional_embedding.",
    )
    removed_surface_uncertainty_prefixes = (
        "swin_unet.decoder_structure_blocks.0.surface_uncertainty_head.",
        "swin_unet.decoder_structure_blocks.1.surface_uncertainty_head.",
        "swin_unet.decoder_structure_blocks.2.surface_uncertainty_head.",
        "swin_unet.decoder_structure_blocks.3.surface_uncertainty_head.",
        "swin_unet.stage2_topology_source.surface_uncertainty_head.",
    )
    removed_connectivity_direction_prefixes = (
        "swin_unet.decoder_structure_blocks.0.connectivity_head.axis_basis",
        "swin_unet.decoder_structure_blocks.1.connectivity_head.axis_basis",
        "swin_unet.decoder_structure_blocks.2.connectivity_head.axis_basis",
        "swin_unet.decoder_structure_blocks.3.connectivity_head.axis_basis",
        "swin_unet.stage2_topology_source.connectivity_head.axis_basis",
    )
    removed_direction_gate_prefixes = (
        "swin_unet.decoder_structure_blocks.0.reliability_correction.",
        "swin_unet.decoder_structure_blocks.1.reliability_correction.",
        "swin_unet.decoder_structure_blocks.2.reliability_correction.",
        "swin_unet.decoder_structure_blocks.3.reliability_correction.",
        "swin_unet.decoder_structure_blocks.0.reliability_beta",
        "swin_unet.decoder_structure_blocks.1.reliability_beta",
        "swin_unet.decoder_structure_blocks.2.reliability_beta",
        "swin_unet.decoder_structure_blocks.3.reliability_beta",
        "swin_unet.stage2_topology_source.reliability_correction.",
        "swin_unet.stage2_topology_source.reliability_beta",
        "swin_unet.global_topology.direction_topology_bias_scale",
    )
    removed_model_prefixes = (
        "swin_unet.decoder_structure_blocks.0.",
        "swin_unet.decoder_structure_blocks.1.",
        "swin_unet.stage_topology_scales.",
        "swin_unet.msce_blocks.",
    )
    filtered_state_dict = {}
    skipped_obsolete_keys = []
    skipped_shape_keys = []
    for key, value in state_dict.items():
        if (
            key not in model_state
            and (
                key.endswith(obsolete_unexpected_suffixes)
                or key.startswith(obsolete_unexpected_prefixes)
                or key.startswith(removed_direction_embedding_prefixes)
                or key.startswith(removed_surface_uncertainty_prefixes)
                or key.startswith(removed_connectivity_direction_prefixes)
                or key.startswith(removed_direction_gate_prefixes)
                or key.startswith(removed_model_prefixes)
                or key.startswith(highres_structure_missing_prefixes)
            )
        ):
            skipped_obsolete_keys.append(key)
            continue
        if (
            key in model_state
            and hasattr(value, "shape")
            and value.shape != model_state[key].shape
            and key.endswith("decoder_structure_blocks.2.feature_residual.0.weight")
            and value.ndim == 4
            and model_state[key].ndim == 4
            and model_state[key].shape[0] == value.shape[0]
            and model_state[key].shape[1] == 2 * value.shape[1]
            and model_state[key].shape[2:] == value.shape[2:]
        ):
            expanded_weight = torch.zeros_like(model_state[key])
            expanded_weight[:, :value.shape[1]].copy_(value)
            filtered_state_dict[key] = expanded_weight
            skipped_shape_keys.append(key + " (expanded for H2 residual input)")
            continue
        if (
            key in model_state
            and hasattr(value, "shape")
            and value.shape != model_state[key].shape
            and key.endswith("connectivity_head.prior_embed.0.weight")
            and value.ndim == model_state[key].ndim == 4
            and value.shape[0] == model_state[key].shape[0]
            and value.shape[1] >= 2
            and model_state[key].shape[1] == 2
            and value.shape[2:] == model_state[key].shape[2:]
        ):
            adapted_weight = model_state[key].detach().clone()
            adapted_weight.copy_(value[:, :2].to(device=adapted_weight.device, dtype=adapted_weight.dtype))
            filtered_state_dict[key] = adapted_weight
            skipped_shape_keys.append(key + " (dropped direction prior channel)")
            continue
        if (
            key in model_state
            and hasattr(value, "shape")
            and value.shape != model_state[key].shape
            and (
                key.endswith("structure_gate.0.weight")
                or key.startswith(highres_structure_missing_prefixes)
            )
        ):
            skipped_shape_keys.append(key)
            continue
        if key in model_state and hasattr(value, "shape") and value.shape != model_state[key].shape:
            skipped_shape_keys.append(key)
            continue
        filtered_state_dict[key] = value
    if skipped_obsolete_keys:
        print(
            "[TOPOLOGY] Ignored obsolete checkpoint keys not used by this model: "
            + ", ".join(skipped_obsolete_keys),
            flush=True,
        )
    if skipped_shape_keys:
        print(
            "[TOPOLOGY] Reinitialized shape-incompatible compatibility keys: "
            + ", ".join(skipped_shape_keys),
            flush=True,
        )
    if skipped_obsolete_keys or skipped_shape_keys:
        state_dict = filtered_state_dict

    missing_final_topology = not any(
        "final_topology_attention." in key for key in state_dict
    )
    is_legacy_structure_checkpoint = (
        any("decoder_structure_blocks." in key for key in state_dict)
        and not any("raw_rho_gap" in key for key in state_dict)
    )
    is_0626_checkpoint = any(
        "global_context_head." in key for key in state_dict
    )
    if is_legacy_structure_checkpoint:
        result = model.load_state_dict(state_dict, strict=False)
        allowed_missing_prefixes = (
            "swin_unet.guided_head.final_topology_attention.",
            "swin_unet.guided_head.raw_rho_gap",
            "swin_unet.guided_head.fixed_rho_gap",
            "swin_unet.global_topology.",
            "swin_unet.stage2_topology_source.",
            "swin_unet.encoder_road_attention_head.",
            "swin_unet.encoder_stage1_road_attention_head.",
            "swin_unet.encoder_stage2_road_attention_head.",
            "swin_unet.encoder_road_attention_alpha",
            "swin_unet.layers.2.blocks.0.road_bias_scale_a1",
            "swin_unet.layers.2.blocks.0.road_bias_scale_a2",
            "swin_unet.layers.2.blocks.0.road_bias_scale",
            "swin_unet.layers.2.blocks.1.road_bias_scale_a1",
            "swin_unet.layers.2.blocks.1.road_bias_scale_a2",
            "swin_unet.layers.2.blocks.1.road_bias_scale",
            "swin_unet.layers_up.2.blocks.0.decoder_skeleton_bias_scale",
            "swin_unet.layers_up.2.blocks.0.decoder_connectivity_bias_scale",
            "swin_unet.layers_up.2.blocks.1.decoder_skeleton_bias_scale",
            "swin_unet.layers_up.2.blocks.1.decoder_connectivity_bias_scale",
            "swin_unet.layers_up.3.blocks.0.decoder_skeleton_bias_scale",
            "swin_unet.layers_up.3.blocks.0.decoder_connectivity_bias_scale",
            "swin_unet.layers_up.3.blocks.1.decoder_skeleton_bias_scale",
            "swin_unet.layers_up.3.blocks.1.decoder_connectivity_bias_scale",
            "swin_unet.bottleneck_context_fusion.scale_projections.",
            "swin_unet.bottleneck_context_fusion.scale_attention.",
            "swin_unet.decoder_structure_blocks.2.direction_head.",
            "swin_unet.decoder_structure_blocks.3.direction_head.",
            "swin_unet.decoder_structure_blocks.2.connectivity_context.",
            "swin_unet.decoder_structure_blocks.3.connectivity_context.",
            "swin_unet.decoder_structure_blocks.2.direction_gate.",
            "swin_unet.decoder_structure_blocks.3.direction_gate.",
            "swin_unet.decoder_structure_blocks.2.direction_gate_beta",
            "swin_unet.decoder_structure_blocks.3.direction_gate_beta",
            "swin_unet.decoder_structure_blocks.2.structure_gate.0.weight",
            "swin_unet.decoder_structure_blocks.3.structure_gate.0.weight",
            "swin_unet.stage2_topology_source.direction_head.",
            "swin_unet.stage2_topology_source.connectivity_context.",
            "swin_unet.stage2_topology_source.direction_gate.",
            "swin_unet.stage2_topology_source.direction_gate_beta",
            "swin_unet.stage2_topology_source.structure_gate.0.weight",
        ) + highres_structure_missing_prefixes
        if is_0626_checkpoint:
            allowed_missing_prefixes = allowed_missing_prefixes + (
                "swin_unet.guided_head.alpha",
                "swin_unet.guided_head.structure_branch.",
                "swin_unet.guided_head.skeleton_head.",
                "swin_unet.guided_head.connectivity_context.",
                "swin_unet.guided_head.connectivity_head.",
                "swin_unet.guided_head.structure_fusion.",
                "swin_unet.guided_head.structure_residual.",
            )
        invalid_missing = [
            key
            for key in result.missing_keys
            if not key.startswith(allowed_missing_prefixes)
        ]
        if invalid_missing or result.unexpected_keys:
            raise RuntimeError(
                "Legacy structure checkpoint mismatch: "
                f"missing={invalid_missing}, unexpected={result.unexpected_keys}"
            )
        print_expected_highres_missing(result.missing_keys)
        module = model.module if hasattr(model, "module") else model
        guided_head = module.swin_unet.guided_head
        with torch.no_grad():
            guided_head.fixed_rho_gap.zero_()
            guided_head.raw_rho_gap.zero_()
        guided_head.raw_rho_gap.requires_grad_(False)
        if missing_final_topology:
            topology_attention = guided_head.final_topology_attention
            with torch.no_grad():
                topology_attention.fixed_eta.zero_()
                topology_attention.raw_eta.zero_()
            topology_attention.raw_eta.requires_grad_(False)
        print(
            "[TOPOLOGY] Loaded legacy structure checkpoint; missing final "
            "topology parameters use runtime initialization and rho_gap is "
            "disabled for output compatibility.",
            flush=True,
        )
        if is_0626_checkpoint:
            print(
                "[TOPOLOGY] Detected 0626 checkpoint with global_context_head; "
                "unused final-structure guided_head modules keep init values.",
                flush=True,
            )
        apply_structure_profile_runtime(model)
        return result
    road_attention_missing_prefixes = (
        "swin_unet.encoder_road_attention_head.",
        "swin_unet.encoder_stage1_road_attention_head.",
        "swin_unet.encoder_stage2_road_attention_head.",
        "swin_unet.encoder_road_attention_alpha",
        "swin_unet.layers.2.blocks.0.road_bias_scale_a1",
        "swin_unet.layers.2.blocks.0.road_bias_scale_a2",
        "swin_unet.layers.2.blocks.0.road_bias_scale",
        "swin_unet.layers.2.blocks.1.road_bias_scale_a1",
        "swin_unet.layers.2.blocks.1.road_bias_scale_a2",
        "swin_unet.layers.2.blocks.1.road_bias_scale",
        "swin_unet.layers_up.2.blocks.0.decoder_skeleton_bias_scale",
        "swin_unet.layers_up.2.blocks.0.decoder_connectivity_bias_scale",
        "swin_unet.layers_up.2.blocks.1.decoder_skeleton_bias_scale",
        "swin_unet.layers_up.2.blocks.1.decoder_connectivity_bias_scale",
        "swin_unet.layers_up.3.blocks.0.decoder_skeleton_bias_scale",
        "swin_unet.layers_up.3.blocks.0.decoder_connectivity_bias_scale",
        "swin_unet.layers_up.3.blocks.1.decoder_skeleton_bias_scale",
        "swin_unet.layers_up.3.blocks.1.decoder_connectivity_bias_scale",
        "swin_unet.decoder_structure_blocks.2.direction_head.",
        "swin_unet.decoder_structure_blocks.3.direction_head.",
        "swin_unet.decoder_structure_blocks.2.connectivity_context.",
        "swin_unet.decoder_structure_blocks.3.connectivity_context.",
        "swin_unet.decoder_structure_blocks.2.direction_gate.",
        "swin_unet.decoder_structure_blocks.3.direction_gate.",
        "swin_unet.decoder_structure_blocks.2.direction_gate_beta",
        "swin_unet.decoder_structure_blocks.3.direction_gate_beta",
        "swin_unet.decoder_structure_blocks.2.structure_gate.0.weight",
        "swin_unet.decoder_structure_blocks.3.structure_gate.0.weight",
        "swin_unet.decoder_structure_blocks.2.gate_branch.",
        "swin_unet.decoder_structure_blocks.3.gate_branch.",
        "swin_unet.global_topology.",
        "swin_unet.stage2_topology_source.direction_head.",
        "swin_unet.stage2_topology_source.connectivity_context.",
        "swin_unet.stage2_topology_source.direction_gate.",
        "swin_unet.stage2_topology_source.direction_gate_beta",
        "swin_unet.stage2_topology_source.structure_gate.0.weight",
        "swin_unet.stage2_topology_source.gate_branch.",
        "swin_unet.guided_head.detached_skeleton_refine.",
        "swin_unet.guided_head.detached_skeleton_head.",
        "swin_unet.guided_head.connectivity_context.",
    ) + highres_structure_missing_prefixes
    msaf_missing_prefixes = (
        "swin_unet.bottleneck_context_fusion.scale_projections.",
        "swin_unet.bottleneck_context_fusion.scale_attention.",
    )
    allowed_new_missing_prefixes = (
        road_attention_missing_prefixes + msaf_missing_prefixes
    )
    allowed_removed_unexpected_prefixes = (
        "swin_unet.guided_head.skeleton_proj.",
        "swin_unet.guided_head.structure_branch.",
        "swin_unet.guided_head.skeleton_head.",
        "swin_unet.guided_head.detached_skeleton_refine.",
        "swin_unet.guided_head.detached_skeleton_head.",
        "swin_unet.guided_head.connectivity_context.",
        "swin_unet.guided_head.connectivity_head.",
        "swin_unet.guided_head.structure_to_surface.",
        "swin_unet.guided_head.structure_to_surface_gamma",
        "swin_unet.guided_head.final_topology_attention.",
        "swin_unet.guided_head.structure_fusion.",
        "swin_unet.guided_head.structure_residual.",
    ) + removed_direction_embedding_prefixes + removed_surface_uncertainty_prefixes + removed_model_prefixes
    if strict:
        result = model.load_state_dict(state_dict, strict=False)
        invalid_missing = [
            key
            for key in result.missing_keys
            if not key.startswith(allowed_new_missing_prefixes)
        ]
        invalid_unexpected = [
            key
            for key in result.unexpected_keys
            if not key.startswith(allowed_removed_unexpected_prefixes)
        ]
        if invalid_missing or invalid_unexpected:
            raise RuntimeError(
                "Checkpoint mismatch after allowing new encoder additions: "
                f"missing={invalid_missing}, unexpected={invalid_unexpected}"
            )
        print_expected_highres_missing(result.missing_keys)
        print(
            "[TOPOLOGY] Loaded checkpoint without new encoder additions; "
            "new parameters use runtime initialization.",
            flush=True,
        )
    else:
        result = model.load_state_dict(state_dict, strict=strict)
    apply_structure_profile_runtime(model)
    return result


def load_state_dict_ignore_mismatch(model, state_dict, prefix=""):
    model_dict = model.state_dict()
    filtered_dict = {}
    skipped_keys = []

    for key, value in state_dict.items():
        if key in model_dict and model_dict[key].shape == value.shape:
            filtered_dict[key] = value
        else:
            skipped_keys.append(key)

    model_dict.update(filtered_dict)
    msg = model.load_state_dict(model_dict, strict=False)
    print(f"{prefix}loaded keys: {len(filtered_dict)}")
    print(f"{prefix}skipped keys: {len(skipped_keys)}")
    for key in skipped_keys[:20]:
        print(f"{prefix}skipped: {key}")
    return msg


class SwinUnet(nn.Module):
    def __init__(self, config, img_size=224, num_classes=21843, zero_head=False, vis=False,
                 return_skeleton=False, bottleneck_type="global_local",
                 final_topology_eta_init=0.005, final_gap_rho_init=0.005,
                 structure_profile=STRUCTURE_PROFILE_FULL,
                 stage2_skeleton_gradient_ratio=0.5,
                 stage3_skeleton_gradient_ratio=0.5,
                 stage3_gate_topology_gradient_ratio=0.0,
                 final_skeleton_gradient_ratio=0.0,
                 enable_highres_structure_stream=False,
                 highres_structure_channels=64,
                 highres_structure_fuse_stages="stage23",
                 highres_structure_fusion_mode="stage23",
                 enable_post_refine_structure_interaction=False,
                 enable_h3_surface_fusion=False,
                 enable_global_topology=False,
                 global_topology_max_nodes=32,
                 global_topology_heads=4,
                 global_topology_alpha_max=0.05,
                 stage_skeleton_mode="prior_residual",
                 stage_skeleton_bias_init="zero",
                 stage_skeleton_positive_prior=0.05,
                 remove_stage2_pre_topology_source=False):
        super(SwinUnet, self).__init__()
        self.num_classes = num_classes
        self.zero_head = zero_head
        self.config = config
        self.return_skeleton = return_skeleton
        self.bottleneck_type = bottleneck_type

        self.swin_unet = SwinTransformerSys(img_size=config.DATA.IMG_SIZE,
                                patch_size=config.MODEL.SWIN.PATCH_SIZE,
                                in_chans=config.MODEL.SWIN.IN_CHANS,
                                num_classes=self.num_classes,
                                embed_dim=config.MODEL.SWIN.EMBED_DIM,
                                depths=config.MODEL.SWIN.DEPTHS,
                                num_heads=config.MODEL.SWIN.NUM_HEADS,
                                window_size=config.MODEL.SWIN.WINDOW_SIZE,
                                mlp_ratio=config.MODEL.SWIN.MLP_RATIO,
                                qkv_bias=config.MODEL.SWIN.QKV_BIAS,
                                qk_scale=config.MODEL.SWIN.QK_SCALE,
                                drop_rate=config.MODEL.DROP_RATE,
                                drop_path_rate=config.MODEL.DROP_PATH_RATE,
                                ape=config.MODEL.SWIN.APE,
                                patch_norm=config.MODEL.SWIN.PATCH_NORM,
                                use_checkpoint=config.TRAIN.USE_CHECKPOINT,
                                return_skeleton=self.return_skeleton,
                                bottleneck_type=self.bottleneck_type,
                                final_topology_eta_init=final_topology_eta_init,
                                final_gap_rho_init=final_gap_rho_init,
                                structure_profile=structure_profile,
                                stage2_skeleton_gradient_ratio=stage2_skeleton_gradient_ratio,
                                stage3_skeleton_gradient_ratio=stage3_skeleton_gradient_ratio,
                                stage3_gate_topology_gradient_ratio=stage3_gate_topology_gradient_ratio,
                                final_skeleton_gradient_ratio=final_skeleton_gradient_ratio,
                                enable_highres_structure_stream=enable_highres_structure_stream,
                                highres_structure_channels=highres_structure_channels,
                                highres_structure_fuse_stages=highres_structure_fuse_stages,
                                highres_structure_fusion_mode=highres_structure_fusion_mode,
                                enable_post_refine_structure_interaction=(
                                    enable_post_refine_structure_interaction
                                ),
                                enable_h3_surface_fusion=enable_h3_surface_fusion,
                                enable_global_topology=enable_global_topology,
                                global_topology_max_nodes=global_topology_max_nodes,
                                 global_topology_heads=global_topology_heads,
                                 global_topology_alpha_max=global_topology_alpha_max,
                                 stage_skeleton_mode=stage_skeleton_mode,
                                  stage_skeleton_bias_init=stage_skeleton_bias_init,
                                 stage_skeleton_positive_prior=stage_skeleton_positive_prior,
                                 remove_stage2_pre_topology_source=remove_stage2_pre_topology_source)
    def forward(
        self,
        x,
    ):
        if x.size()[1] == 1:
            x = x.repeat(1,3,1,1)
        outputs = self.swin_unet(x)

        if isinstance(outputs, tuple):
            logits = outputs[0]
            aux_outputs = outputs[1:]
        else:
            logits = outputs
            aux_outputs = ()

        if self.return_skeleton:
            return (logits, *aux_outputs)
        return logits

    def load_from(self, config):
        pretrained_path = config.MODEL.PRETRAIN_CKPT
        if pretrained_path is None:
            print("[INFO] No ImageNet checkpoint configured.")
            return set()

        print("[INFO] Loading encoder-only ImageNet checkpoint: {}".format(pretrained_path))
        checkpoint = torch.load(
            pretrained_path,
            map_location="cpu",
            weights_only=False,
        )
        pretrained_dict = checkpoint.get("model", checkpoint)
        model_dict = self.swin_unet.state_dict()
        compatible = {}
        for key, value in pretrained_dict.items():
            if key.startswith("head.") or "relative_position_index" in key or "attn_mask" in key:
                continue
            target_key = key
            if ".downsample.reduction.weight" in key:
                target_key = key.replace(".downsample.reduction.weight", ".downsample.linear_reduction.weight")
            if target_key in model_dict and model_dict[target_key].shape == value.shape:
                compatible[target_key] = value

        result = self.swin_unet.load_state_dict(compatible, strict=False)
        loaded = set(compatible)
        print(
            "[INFO] Loaded {} compatible ImageNet tensors; {} skipped/missing. "
            "Decoder mirror weights are intentionally not loaded.".format(
                len(loaded), len(result.missing_keys)
            ),
            flush=True,
        )
        return {"swin_unet." + key for key in loaded}
 
