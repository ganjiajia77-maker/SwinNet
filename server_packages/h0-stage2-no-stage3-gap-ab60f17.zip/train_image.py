import argparse
import copy
import csv
import math
import os
import json
import random
import sys
import tempfile
import time
import cv2
import numpy as np
import torch
import torch.backends.cudnn as cudnn
import torch.nn.functional as F
from datetime import datetime
from PIL import Image
from torch.utils.data import DataLoader, Subset

from networks.vision_transformer import (
    TOPOLOGY_ATTENTION_VERSION,
    STRUCTURE_PROFILE_FULL,
    STRUCTURE_PROFILE_STAGE23_BOUNDARY_0626,
    STRUCTURE_PROFILE_STAGE23_BOUNDARY_FINAL_SKE,
    SwinUnet as ViT_seg,
    get_topology_coefficients,
    load_topology_checkpoint_state,
    print_topology_coefficients,
)
from datasets.dataset_road_skeleton import RoadSkeletonDataset
from losses.road_losses import SurfaceStructureLoss
from losses.cldice_loss import soft_skeletonize
from config import get_config


def seed_worker(worker_id):
    worker_seed = torch.initial_seed() % 2**32
    random.seed(worker_seed)
    np.random.seed(worker_seed)


parser = argparse.ArgumentParser()
parser.add_argument('--root_path', type=str, default='./data1', help='root dir for data')
parser.add_argument('--dataset', type=str, default='ImageData', help='dataset name')
parser.add_argument('--list_dir', type=str, default='./lists/lists_Synapse', help='list dir')
parser.add_argument('--num_classes', type=int, default=2, help='output channel of network')
parser.add_argument('--output_dir', type=str, default='./model_out', help='output dir')
parser.add_argument('--run_name', type=str, default='', help='optional run folder name under output_dir')
parser.add_argument('--max_epochs', type=int, default=100, help='maximum epoch number to train')
parser.add_argument('--n_gpu', type=int, default=1, help='total gpu')
parser.add_argument('--deterministic', type=int, default=1, help='whether use deterministic training')
parser.add_argument('--base_lr', type=float, default=5e-4, help='segmentation network learning rate')
parser.add_argument('--min_lr', type=float, default=1e-5, help='minimum learning rate for cosine decay')
parser.add_argument('--warmup_epochs', type=int, default=3, help='warmup epochs before cosine decay')
parser.add_argument('--batch_size', type=int, default=4, help='batch_size per gpu')
parser.add_argument('--img_size', type=int, default=512, help='model input tile size')
parser.add_argument('--source_patch_size', type=int, default=1024, help='full source image size')
parser.add_argument('--overlap_stride', type=int, default=256, help='fixed training/validation tile stride')
parser.add_argument('--direct_resize_train', action='store_true', help='resize the full source patch directly to img_size for training')
parser.add_argument('--random_crop_train', action='store_true', help='randomly sample native train crops instead of fixed tiles')
parser.add_argument('--random_crops_per_image', type=int, default=1, help='random train crops sampled per source image each epoch')
parser.add_argument('--val_crop_list', type=str, default='', help='fixed validation crop list: one line per crop, image: x=..., y=...')
parser.add_argument('--min_crop_road_pixels', type=int, default=0, help='retained for run metadata; fixed tiles are never filtered')
parser.add_argument('--augment', action=argparse.BooleanOptionalAction, default=True, help='synchronized geometry and image-only appearance augmentation')
parser.add_argument('--use_ema', action=argparse.BooleanOptionalAction, default=True, help='validate and save an EMA copy of the model')
parser.add_argument('--ema_decay', type=float, default=0.999)
parser.add_argument('--seed', type=int, default=1234, help='random seed')
parser.add_argument('--cfg', type=str, default='./configs/swin_tiny_patch4_window7_224_lite.yaml', 
                    help='path to config file')
parser.add_argument('--n_class', default=2, type=int)
parser.add_argument('--num_workers', default=4, type=int)
parser.add_argument('--loader_prefetch_factor', default=2, type=int, help='DataLoader prefetch factor when num_workers > 0')
parser.add_argument('--disable_persistent_workers', action='store_true', default=True, help='workers restart every epoch; persistent workers disabled in this experiment')
parser.add_argument('--tiny_overfit_samples', default=0, type=int, help='use the first N training samples for tiny-set overfit debugging')
parser.add_argument('--print_freq', default=10, type=int, help='print loss every N batches')
parser.add_argument('--threshold', default=0.2, type=float, help='binary threshold for validation')
parser.add_argument('--skeleton_threshold', default=0.5, type=float, help='final skeleton threshold for validation')
parser.add_argument('--val_interval', type=int, default=1, help='run validation every N epochs; always validates on final epoch')
parser.add_argument('--finetune_epochs', type=int, default=0, help='when resuming, stop after this many extra epochs while keeping the original LR schedule length')
parser.add_argument('--trend_val_every_steps', type=int, default=0, help='run fixed-subset topology validation every N training batches; 0 disables it')
parser.add_argument('--trend_val_max_batches', type=int, default=0, help='number of validation batches used by trend validation; 0 uses the full val loader')
parser.add_argument('--trend_val_short_area_threshold', type=int, default=20, help='short-component area threshold for trend fragmentation metrics')
parser.add_argument('--trend_val_csv', type=str, default='', help='CSV path for step-wise trend validation metrics')
parser.add_argument(
    '--surface_loss',
    type=str,
    default='bce_dice',
    choices=['bce_dice'],
    help='surface segmentation objective: Focal BCE + 0.5*Dice; set --surface_focal_gamma 0 for BCE',
)
parser.add_argument('--final_topology_eta_init', default=0.005, type=float, help='initial final topology repair coefficient')
parser.add_argument('--final_gap_rho_init', default=0.005, type=float, help='initial localized gap-repair coefficient')
parser.add_argument('--stage3_skeleton_weight', type=float, default=0.005)
parser.add_argument('--stage2_skeleton_weight', type=float, default=0.0)
parser.add_argument('--enable_highres_structure_stream', action='store_true')
parser.add_argument('--highres_structure_channels', type=int, default=64)
parser.add_argument(
    '--highres_structure_fuse_stages',
    type=str,
    default='stage23',
    choices=['stage2', 'stage3', 'stage23'],
)
parser.add_argument(
    '--highres_structure_fusion_mode',
    type=str,
    default='stage23',
    choices=[
        'stage23',
        'final_correction',
        'stage23_final_correction',
        'post_refine_interaction',
        'none',
    ],
    help=(
        'stage23: decoder fusion; final_correction: final residual logit correction; '
        'stage23_final_correction: both; post_refine_interaction: inject detached '
        'structure after surface_refine; none: skeleton-only high-res stream'
    ),
)
parser.add_argument('--highres_structure_skeleton_weight', type=float, default=0.0)
parser.add_argument('--stage_skeleton_mode', type=str, default='prior_residual', choices=['direct', 'prior_residual'])
parser.add_argument('--enable_h3_surface_fusion', action='store_true')
parser.add_argument('--remove_stage2_pre_topology_source', action='store_true')
parser.add_argument(
    '--enable_global_topology',
    action='store_true',
    help='enable sparse global topology residual with anchors=z_struct*surface and fused topology tokens',
)
parser.add_argument('--global_topology_max_nodes', type=int, default=32)
parser.add_argument('--global_topology_heads', type=int, default=4)
parser.add_argument('--global_topology_alpha_max', type=float, default=0.05)
parser.add_argument(
    '--enable_post_refine_structure_interaction',
    action='store_true',
    help='enable detached z_struct -> post surface_refine interaction module',
)
parser.add_argument(
    '--freeze_post_refine_interaction_only',
    action='store_true',
    help='freeze the loaded model and train only guided_head.post_refine_structure_interaction',
)
parser.add_argument('--stage2_skeleton_gradient_ratio', type=float, default=0.5)
parser.add_argument('--stage3_skeleton_gradient_ratio', type=float, default=0.5)
parser.add_argument(
    '--stage3_gate_topology_gradient_ratio',
    type=float,
    default=0.0,
    help='gradient ratio for Stage 3 gate skeleton/connectivity inputs; 0 keeps the old detached gate path',
)
parser.add_argument('--final_skeleton_gradient_ratio', type=float, default=0.0)
parser.add_argument('--skeleton_pos_weight', type=float, default=None,
                    help='positive-class weight for skeleton BCE losses')
parser.add_argument('--stage_direction_factor', type=float, default=0.0)
parser.add_argument('--stage_connectivity_factor', type=float, default=2.0)
parser.add_argument('--stage2_direction_factor', type=float, default=None)
parser.add_argument('--stage3_direction_factor', type=float, default=None)
parser.add_argument('--stage2_connectivity_factor', type=float, default=None)
parser.add_argument('--stage3_connectivity_factor', type=float, default=None)
parser.add_argument('--stage_skeleton_loss_factor', type=float, default=1.0)
parser.add_argument(
    '--stage_skeleton_only_loss_factor',
    type=float,
    default=1.0,
    help='multiply only the Stage 2/3 skeleton loss, leaving connectivity/direction unchanged',
)
parser.add_argument('--stage_skeleton_bias_init', type=str, default='zero', choices=['zero', 'prior'])
parser.add_argument('--stage_skeleton_positive_prior', type=float, default=0.05)
parser.add_argument('--final_skeleton_weight', type=float, default=None, help='override final skeleton auxiliary loss weight')
parser.add_argument('--final_connectivity_weight', type=float, default=None, help='override final connectivity auxiliary loss weight')
parser.add_argument('--boundary_weight', type=float, default=None, help='deprecated; boundary auxiliary loss is disabled')
parser.add_argument('--road_attention_weight', type=float, default=0.003)
parser.add_argument('--max_train_batches', type=int, default=0, help='limit training to the first N batches per epoch; 0 means no limit')
parser.add_argument('--no_pretrain', action='store_true', help='do not load pretrained weights')
parser.add_argument('--pretrain_ckpt', type=str, default='', help='optional ImageNet Swin checkpoint path')
parser.add_argument('--warm_start_ckpt', type=str, default='', help='fresh run warm-start checkpoint; loads only matching tensors and does not restore epoch/optimizer')
parser.add_argument('--pretrained_lr', type=float, default=5e-5, help='LR for tensors actually loaded from ImageNet')
parser.add_argument('--pretrained_min_lr', type=float, default=5e-6)
parser.add_argument('--new_lr', type=float, default=2e-4, help='LR for all randomly initialized tensors')
parser.add_argument('--new_min_lr', type=float, default=1e-5)
parser.add_argument('--disable_centerline_loss', action='store_true', help='disable the centerline response term for debugging NaN instability')
parser.add_argument(
    '--bottleneck_type',
    type=str,
    default='global_local',
    choices=['global_local', 'legacy_global_local', 'g2l2'],
    help='choose bottleneck implementation',
)
parser.add_argument(
    '--structure_profile',
    type=str,
    default=STRUCTURE_PROFILE_FULL,
    choices=[
        STRUCTURE_PROFILE_FULL,
        STRUCTURE_PROFILE_STAGE23_BOUNDARY_0626,
        STRUCTURE_PROFILE_STAGE23_BOUNDARY_FINAL_SKE,
    ],
    help='structure profile: full, stage2/3 only, or stage2/3 plus final skeleton aux',
)
parser.add_argument(
    '--masked_connectivity_center_experiment',
    action='store_true',
    help='use skeleton-center connectivity BCE plus small reciprocal symmetry regularization',
)
parser.add_argument(
    '--connectivity_pos_weight',
    type=float,
    default=5.0,
    help='positive class weight for connectivity BCE/focal BCE',
)
parser.add_argument(
    '--directional_pos_weight_cardinal',
    type=float,
    default=1.0,
    help='positive connectivity loss multiplier for N/E/S/W directions',
)
parser.add_argument(
    '--directional_pos_weight_diagonal',
    type=float,
    default=2.5,
    help='positive connectivity loss multiplier for NE/SE/SW/NW directions',
)
parser.add_argument(
    '--connectivity_focal_gamma',
    type=float,
    default=1.5,
    help='gamma for focal weighting on connectivity BCE; 0 disables focal weighting',
)
parser.add_argument(
    '--surface_focal_gamma',
    type=float,
    default=1.0,
    help='gamma for focal weighting on surface BCE; 0 disables focal weighting',
)
parser.add_argument(
    '--edge_contrastive_margin',
    type=float,
    default=0.0,
    help='margin for connectivity edge discrimination loss max(0, margin - C_pos + C_neg); 0 disables',
)
# Options expected by the original config updater
parser.add_argument('--opts', nargs=argparse.REMAINDER, default=None, help='modify config options using the command-line')
parser.add_argument('--zip', action='store_true', help='use zipped dataset')
parser.add_argument('--cache_mode', type=str, default='', help='cache mode for dataset')
parser.add_argument('--resume', type=str, default='', help='resume from checkpoint')
parser.add_argument('--accumulation_steps', type=int, default=0, help='gradient accumulation steps')
parser.add_argument('--use_checkpoint', action='store_true', help='use gradient checkpointing')
parser.add_argument('--amp_opt_level', type=str, default='', help='AMP opt level')
parser.add_argument(
    '--amp_dtype',
    type=str,
    choices=['bfloat16', 'none'],
    default='bfloat16',
    help='automatic mixed precision dtype; defaults to BF16 on CUDA',
)
parser.add_argument('--tag', type=str, default='', help='experiment tag')
parser.add_argument('--eval', action='store_true', help='evaluation only')
parser.add_argument('--throughput', action='store_true', help='test throughput only')
parser.add_argument('--encoder_h_postmerge_phase', action='store_true')
parser.add_argument('--global_topology_stage2', action='store_true',
                    help='move the final H-driven global topology to the decoder Stage2 output')
parser.add_argument('--disable_stage3_gap_calibration', action='store_true',
                    help='remove only the bottleneck GAP bias on the decoder Stage3 structure gate')
parser.add_argument('--h0_config_checkpoint', type=str, default='', help='original H0 checkpoint; read configuration only')
parser.add_argument('--h_phase_initial_strength', type=float, default=.05)
parser.add_argument('--h_phase_smoke_only', action='store_true')
parser.add_argument('--h_phase_audit_interval', type=int, default=50)
parser.add_argument('--h_phase_smoke_manifest', type=str, default='')

args = parser.parse_args()
from h0_phase_training import inherit_h0_config
h_phase_reference_report = inherit_h0_config(args, parser)


def _cli_has(flag):
    inherited = h_phase_reference_report['inherited_keys'] if h_phase_reference_report else []
    return flag.lstrip('-').replace('-', '_') in inherited or any(
        arg == flag or arg.startswith(flag + "=")
        for arg in sys.argv[1:]
    )


def apply_structure_profile_defaults(args):
    if args.structure_profile not in {
        STRUCTURE_PROFILE_STAGE23_BOUNDARY_0626,
        STRUCTURE_PROFILE_STAGE23_BOUNDARY_FINAL_SKE,
    }:
        return

    if not _cli_has("--stage2_skeleton_weight"):
        args.stage2_skeleton_weight = 0.020
    if not _cli_has("--stage3_skeleton_weight"):
        args.stage3_skeleton_weight = 0.030
    args.final_topology_eta_init = 0.0
    args.final_gap_rho_init = 0.0
    if args.warmup_epochs == 3:
        args.warmup_epochs = 10
    if args.max_epochs == 100 and not _cli_has("--max_epochs"):
        args.max_epochs = 60


apply_structure_profile_defaults(args)

if args.freeze_post_refine_interaction_only:
    if not args.enable_highres_structure_stream:
        parser.error("--freeze_post_refine_interaction_only requires --enable_highres_structure_stream")
    args.enable_post_refine_structure_interaction = True
if args.enable_global_topology and not args.enable_highres_structure_stream:
    parser.error("--enable_global_topology requires --enable_highres_structure_stream")


def get_final_loss_weights(args):
    if args.structure_profile == STRUCTURE_PROFILE_STAGE23_BOUNDARY_0626:
        weights = {
            "skeleton_weight": 0.0,
            "connectivity_weight": 0.0,
            "boundary_weight": 0.0,
        }
    elif args.structure_profile == STRUCTURE_PROFILE_STAGE23_BOUNDARY_FINAL_SKE:
        weights = {
            "skeleton_weight": 0.0,
            "connectivity_weight": 0.0,
            "boundary_weight": 0.0,
        }
    else:
        weights = {
            "skeleton_weight": 0.02,
            "connectivity_weight": 0.03,
            "boundary_weight": 0.0,
        }
    if args.final_skeleton_weight is not None:
        weights["skeleton_weight"] = float(args.final_skeleton_weight)
    if args.final_connectivity_weight is not None:
        if args.structure_profile in {
            STRUCTURE_PROFILE_STAGE23_BOUNDARY_0626,
            STRUCTURE_PROFILE_STAGE23_BOUNDARY_FINAL_SKE,
        }:
            print(
                "[WARN] --final_connectivity_weight is ignored for stage23 profiles; "
                "final connectivity is removed.",
                flush=True,
            )
        else:
            weights["connectivity_weight"] = float(args.final_connectivity_weight)
    if args.boundary_weight is not None and float(args.boundary_weight) != 0.0:
        print("[WARN] --boundary_weight is ignored because boundary auxiliary loss is disabled.")
    return weights

def get_graph_outputs_from_model(model):
    module = model.module if hasattr(model, "module") else model
    head = module.swin_unet.guided_head
    return (
        head.last_surface_pre_logits,
        head.last_delta_logit,
        head.last_graph_delta,
    )


def build_criterion(args, loss_weights, device):
    stage2_weight = args.stage2_skeleton_weight
    stage3_weight = args.stage3_skeleton_weight
    boundary_weight = 0.0

    return SurfaceStructureLoss(
        surface_dice_weight=0.5,
        skeleton_dice_weight=1.0,
        skeleton_weight=loss_weights["skeleton_weight"],
        connectivity_weight=loss_weights["connectivity_weight"],
        connectivity_erode_kernel_size=1,
        boundary_weight=boundary_weight,
        boundary_radius=1,
        stage_structure_weights=(
            0.0,
            0.0,
            stage2_weight,
            stage3_weight,
        ),
        road_attention_weight=args.road_attention_weight,
        stage_connectivity_factor=args.stage_connectivity_factor,
        stage_direction_factor=args.stage_direction_factor,
        highres_structure_skeleton_weight=(
            args.highres_structure_skeleton_weight
        ),
        use_legacy_stage_connectivity_loss=(
            args.structure_profile in {
                STRUCTURE_PROFILE_STAGE23_BOUNDARY_0626,
                STRUCTURE_PROFILE_STAGE23_BOUNDARY_FINAL_SKE,
            }
        ),
        use_masked_connectivity_center_experiment=args.masked_connectivity_center_experiment,
        connectivity_pos_weight=args.connectivity_pos_weight,
        skeleton_pos_weight=args.skeleton_pos_weight,
        directional_pos_weight_cardinal=args.directional_pos_weight_cardinal,
        directional_pos_weight_diagonal=args.directional_pos_weight_diagonal,
        connectivity_focal_gamma=args.connectivity_focal_gamma,
        surface_focal_gamma=args.surface_focal_gamma,
        edge_contrastive_margin=args.edge_contrastive_margin,
        stage_connectivity_factors=(
            0.0,
            0.0,
            args.stage2_connectivity_factor
            if args.stage2_connectivity_factor is not None
            else args.stage_connectivity_factor,
            args.stage3_connectivity_factor
            if args.stage3_connectivity_factor is not None
            else args.stage_connectivity_factor,
        ),
        stage_direction_factors=(
            0.0,
            0.0,
            args.stage2_direction_factor
            if args.stage2_direction_factor is not None
            else args.stage_direction_factor,
            args.stage3_direction_factor
            if args.stage3_direction_factor is not None
            else args.stage_direction_factor,
        ),
        stage_skeleton_loss_factor=args.stage_skeleton_loss_factor,
        stage_skeleton_only_loss_factor=args.stage_skeleton_only_loss_factor,
    ).to(device)


def format_training_config_lines(args, loss_weights):
    lines = [
        f"  结构配置: {args.structure_profile}",
        f"  Surface loss: focal BCE gamma={args.surface_focal_gamma:.3f} + 0.5*Dice",
        f"  Training AMP: {args.amp_dtype}",
        "  Decoder computation: dense Stage 2/3",
            "  Stage skeleton mode: {}; pre-Stage2 topology source removed: {}".format(
                args.stage_skeleton_mode,
                args.remove_stage2_pre_topology_source,
            ),
            "  H3 -> final surface fusion: {}".format(
                args.enable_h3_surface_fusion
            ),
    ]
    if args.enable_highres_structure_stream:
        lines.append(
            "  Skeleton feature flow: z_struct -> H0 <-> G2 -> H1 <-> G3 -> H2"
        )
    if args.structure_profile in {
        STRUCTURE_PROFILE_STAGE23_BOUNDARY_0626,
        STRUCTURE_PROFILE_STAGE23_BOUNDARY_FINAL_SKE,
    }:
        lines.extend([
            "  Structure head: con0 -> decoder attention bias; ske1 -> gate feature, con1 prediction/loss only",
            (
                "  Final head: surface branch + boundary residual + final skeleton auxiliary only; "
                "final connectivity removed"
                if args.structure_profile == STRUCTURE_PROFILE_STAGE23_BOUNDARY_FINAL_SKE
                else "  Final head: surface branch + boundary residual only; final skeleton/connectivity removed"
            ),
            "  Stage2 structure loss weight: {:.3f}".format(args.stage2_skeleton_weight),
            "  Stage3 structure loss weight: {:.3f}".format(args.stage3_skeleton_weight),
            "  Stage skeleton-only loss factor: {:.3f}".format(
                args.stage_skeleton_only_loss_factor
            ),
            "  Stage skeleton target: Gaussian soft heatmap; skeleton BCE pos_weight={}".format(
                args.skeleton_pos_weight
            ),
            "  Stage2/Stage3 skeleton gradient ratio: {:.3f}/{:.3f}".format(
                args.stage2_skeleton_gradient_ratio,
                args.stage3_skeleton_gradient_ratio,
            ),
            "  Stage3 gate topology gradient ratio: {:.3f}".format(
                args.stage3_gate_topology_gradient_ratio
            ),
            "  Stage loss: 0.5*first guide prediction + 1.0*second refinement prediction; "
            "skeleton BCE(dilated) + 0.3 Dice(hard) + {:.3f} direction-field cosine loss on skeleton; "
            "{:.3f}*connectivity loss".format(
                args.stage_direction_factor,
                args.stage_connectivity_factor
            ),
            "  Stage skeleton-connectivity consistency: disabled",
            "  Encoder road attention: A1/A2 priors active for residual PatchMerging and Stage3 road attention bias",
            "  Encoder stage1 road prior: residual PatchMerging path",
            ("  Global context calibration: disabled" if args.disable_stage3_gap_calibration else
             "  Global context calibration: bottleneck GAP -> stage3 structure gate, strength 0.03"),
            "  Decoder stage3 step0: removed; only post-upsampling refinement is active",
            "  Decoder gate input: [decoder gate feature, Skeleton, Connectivity]",
            "  Decoder gate: structure gate plus local+dilated semantic context; no direction-confidence input",
            "  Connectivity directional positive weight: cardinal={:.3f}, diagonal={:.3f}".format(
                args.directional_pos_weight_cardinal,
                args.directional_pos_weight_diagonal,
            ),
            "  Global topology residual: {}, anchors=z_struct*surface, tokens=[z_struct,decoder_feature,connectivity], relation_bias=relative_xy_distance+connectivity, max_nodes={}, heads={}, alpha_max={:.3f}".format(
                "enabled" if args.enable_global_topology else "disabled",
                args.global_topology_max_nodes,
                args.global_topology_heads,
                args.global_topology_alpha_max,
            ),
        ])
        if args.masked_connectivity_center_experiment:
            lines.extend([
                "  Connectivity experiment: skeleton-center connectivity BCE + small reciprocal symmetry regularizer",
                f"  Connectivity loss balance: pos_weight={args.connectivity_pos_weight:.3f}, focal_gamma={args.connectivity_focal_gamma:.3f}, edge_contrastive_margin={args.edge_contrastive_margin:.3f}",
            ])
    else:
        lines.extend([
            "  Decoder structure gates: restored 0621 stages 0/1/2/3",
            "  Final structure-only topology refiner: "
            f"eta_init={args.final_topology_eta_init}, eta_max=0.05, tau=4",
            "  Localized gap repair: "
            f"rho_init={args.final_gap_rho_init}, rho_max=0.05, detached M_gap",
        ])
    lines.extend([
        "  Stage structure weights: "
        f"stage2={args.stage2_skeleton_weight}, "
        f"stage3={args.stage3_skeleton_weight}, "
        f"stage2_grad_ratio={args.stage2_skeleton_gradient_ratio}, "
        f"stage3_grad_ratio={args.stage3_skeleton_gradient_ratio}, "
        f"stage3_gate_topology_grad_ratio={args.stage3_gate_topology_gradient_ratio}, "
        f"final_skeleton_grad_ratio={args.final_skeleton_gradient_ratio}, "
        f"connectivity_factor={args.stage_connectivity_factor}, "
        f"direction_factor={args.stage_direction_factor}, "
        f"road_attention={args.road_attention_weight}",
        "  High-res structure stream: "
        f"{'enabled' if args.enable_highres_structure_stream else 'disabled'}, "
        f"channels={args.highres_structure_channels}, "
        f"fuse_stages={args.highres_structure_fuse_stages}, "
        f"fusion_mode={args.highres_structure_fusion_mode}, "
        f"skeleton_weight={args.highres_structure_skeleton_weight}",
        "  Surface loss: BCE + 0.5*Dice",
        (
            f"  Direct resize: {args.source_patch_size} -> {args.img_size}"
            if args.direct_resize_train
            else (
                f"  Random native crops: {args.source_patch_size} -> "
                f"{args.img_size}, crops/image={args.random_crops_per_image}"
                if args.random_crop_train
                else f"  Fixed overlap tiles: {args.source_patch_size} -> {args.img_size}, stride={args.overlap_stride}"
            )
        ),
        f"  Minimum crop road pixels: {args.min_crop_road_pixels} (no tile filtering)",
        f"  Random seed: {args.seed}",
        f"  Train augmentation: {'enabled' if args.augment else 'disabled'}",
        f"  EMA: {'enabled' if args.use_ema else 'disabled'}, decay={args.ema_decay}",
        (
            f"  Validation: fixed crop list ({args.val_crop_list}) -> global TP/FP/FN"
            if args.val_crop_list
            else
            "  Validation: direct resized logits -> sigmoid -> one threshold"
            if args.direct_resize_train
            else "  Validation: stitch logits -> sigmoid -> one threshold -> global TP/FP/FN"
        ),
        f"  Validation interval: every {max(1, args.val_interval)} epoch(s), final epoch always",
        "  Boundary auxiliary loss: disabled",
        "  Final skeleton loss weight: {:.2f}".format(loss_weights["skeleton_weight"]),
        "  Final connectivity loss weight: {:.2f}".format(loss_weights["connectivity_weight"]),
        "  Edge loss: disabled",
        "  Edge skip enhance: disabled",
    ])
    return lines


def make_unique_dir(base_dir, run_name):
    run_dir = os.path.join(base_dir, run_name)
    if not os.path.exists(run_dir):
        return run_dir

    index = 2
    while True:
        candidate = f"{run_dir}_{index}"
        if not os.path.exists(candidate):
            return candidate
        index += 1


def save_checkpoint_safely(checkpoint, target_path):
    """Save directly on Windows to avoid orphaned temporary checkpoint files."""
    target_dir = os.path.dirname(target_path)
    os.makedirs(target_dir, exist_ok=True)
    torch.save(checkpoint, target_path, _use_new_zipfile_serialization=False)


def inherit_resume_architecture_args(args):
    if not args.resume or not os.path.isfile(args.resume):
        return
    try:
        checkpoint = torch.load(args.resume, map_location="cpu")
    except Exception as exc:
        print(
            f"[WARN] Could not inspect resume checkpoint args before model build: {exc}",
            flush=True,
        )
        return
    if not isinstance(checkpoint, dict) or not isinstance(checkpoint.get("args"), dict):
        return

    saved_args = checkpoint["args"]
    if bool(saved_args.get('disable_stage3_gap_calibration', False)) != args.disable_stage3_gap_calibration:
        raise ValueError('Resume must use the checkpoint Stage 3 GAP calibration setting')
    for name, cast in (
        ("surface_focal_gamma", float),
        ("amp_dtype", str),
        ("stage3_gate_topology_gradient_ratio", float),
        ("stage_skeleton_mode", str),
        ("stage_skeleton_bias_init", str),
        ("stage_skeleton_positive_prior", float),
    ):
        if name in saved_args and not _cli_has(f"--{name}"):
            setattr(args, name, cast(saved_args[name]))
    if "structure_profile" in saved_args and not _cli_has("--structure_profile"):
        args.structure_profile = saved_args["structure_profile"]
    if "direct_resize_train" in saved_args and not _cli_has("--direct_resize_train"):
        args.direct_resize_train = bool(saved_args["direct_resize_train"])
    if "img_size" in saved_args and not _cli_has("--img_size"):
        args.img_size = int(saved_args["img_size"])
    if "source_patch_size" in saved_args and not _cli_has("--source_patch_size"):
        args.source_patch_size = int(saved_args["source_patch_size"])
    if "overlap_stride" in saved_args and not _cli_has("--overlap_stride"):
        args.overlap_stride = int(saved_args["overlap_stride"])
    if "enable_highres_structure_stream" in saved_args and not _cli_has("--enable_highres_structure_stream"):
        args.enable_highres_structure_stream = bool(saved_args["enable_highres_structure_stream"])
    for name in ("remove_stage2_pre_topology_source",):
        if name in saved_args and not _cli_has("--" + name):
            setattr(args, name, bool(saved_args[name]))
    if "highres_structure_channels" in saved_args and not _cli_has("--highres_structure_channels"):
        args.highres_structure_channels = int(saved_args["highres_structure_channels"])
    if "highres_structure_fuse_stages" in saved_args and not _cli_has("--highres_structure_fuse_stages"):
        args.highres_structure_fuse_stages = str(saved_args["highres_structure_fuse_stages"])
    if "highres_structure_fusion_mode" in saved_args and not _cli_has("--highres_structure_fusion_mode"):
        args.highres_structure_fusion_mode = str(saved_args["highres_structure_fusion_mode"])
    if (
        "enable_post_refine_structure_interaction" in saved_args
        and not _cli_has("--enable_post_refine_structure_interaction")
    ):
        args.enable_post_refine_structure_interaction = bool(
            saved_args["enable_post_refine_structure_interaction"]
        )
    if "highres_structure_skeleton_weight" in saved_args and not _cli_has("--highres_structure_skeleton_weight"):
        args.highres_structure_skeleton_weight = float(saved_args["highres_structure_skeleton_weight"])
    if "enable_global_topology" in saved_args and not _cli_has("--enable_global_topology"):
        args.enable_global_topology = bool(saved_args["enable_global_topology"])
    if "global_topology_max_nodes" in saved_args and not _cli_has("--global_topology_max_nodes"):
        args.global_topology_max_nodes = int(saved_args["global_topology_max_nodes"])
    if "global_topology_heads" in saved_args and not _cli_has("--global_topology_heads"):
        args.global_topology_heads = int(saved_args["global_topology_heads"])
    if "global_topology_alpha_max" in saved_args and not _cli_has("--global_topology_alpha_max"):
        args.global_topology_alpha_max = float(saved_args["global_topology_alpha_max"])
    print(
        "[INFO] Resume architecture args: "
        f"profile={args.structure_profile}, "
        f"direct_resize_train={args.direct_resize_train}, "
        f"img_size={args.img_size}, source_patch_size={args.source_patch_size}, "
        f"highres_structure={args.enable_highres_structure_stream}, "
        f"global_topology={args.enable_global_topology}",
        flush=True,
    )


def model_state_is_finite(model):
    for param in model.state_dict().values():
        if torch.is_tensor(param) and not torch.isfinite(param).all():
            return False
    return True


class ModelEMA:
    def __init__(self, model, decay=0.999):
        self.ema = copy.deepcopy(model).eval()
        self.decay = float(decay)
        for parameter in self.ema.parameters():
            parameter.requires_grad_(False)

    @torch.no_grad()
    def update(self, model):
        model_state = model.state_dict()
        for name, ema_value in self.ema.state_dict().items():
            source_value = model_state[name].detach()
            if torch.is_floating_point(ema_value):
                ema_value.mul_(self.decay).add_(source_value.to(ema_value.dtype), alpha=1.0 - self.decay)
            else:
                ema_value.copy_(source_value)


def get_cosine_warmup_lr(epoch, max_epochs, base_lr, min_lr, warmup_epochs):
    if max_epochs <= 0:
        return base_lr

    warmup_epochs = max(0, warmup_epochs)
    if warmup_epochs > 0 and epoch < warmup_epochs:
        return base_lr * float(epoch + 1) / float(warmup_epochs)

    decay_epochs = max(1, max_epochs - warmup_epochs)
    if decay_epochs == 1:
        return min_lr

    progress = min(float(epoch - warmup_epochs) / float(decay_epochs - 1), 1.0)
    cosine = 0.5 * (1.0 + math.cos(math.pi * progress))
    return min_lr + (base_lr - min_lr) * cosine


def get_stage_distill_scale(epoch):
    epoch_number = epoch + 1
    if epoch_number <= 5:
        return 0.0
    if epoch_number < 10:
        return (epoch_number - 5) / 5.0
    return 1.0


def pad_to_window_multiple(x, window_size=7):
    """
    Pad input tensor to be divisible by window_size.
    Returns: (padded_tensor, original_shape)
    """
    B, C, H, W = x.shape
    pad_h = (window_size - H % window_size) % window_size
    pad_w = (window_size - W % window_size) % window_size
    if pad_h > 0 or pad_w > 0:
        x = torch.nn.functional.pad(x, (0, pad_w, 0, pad_h), mode='constant', value=0)
    return x, (H, W)


def crop_to_shape(x, target_shape):
    """Crop tensor back to target shape."""
    if x is None:
        return None
    H, W = target_shape
    return x[:, :, :H, :W]

# 模块级别定义，以便被 DataLoader worker 进程使用
class ResizeToTensor:
    def __init__(self, output_size):
        self.output_size = output_size

    def __call__(self, sample):
        image, label = sample['image'], sample['label']
        # image: [3, H, W], label: [H, W] (已二值化为 0 或 1)
        
        # 转换为 [H, W, 3] 便于 PIL 处理
        image = image.transpose(1, 2, 0)  # [3, H, W] -> [H, W, 3]
        
        # 转换为 uint8 进行 PIL 操作（反去归一化和标准化）
        # 由于已经做过标准化，这里简单还原逻辑：先乘 std，再加 mean，最后乘 255
        mean = np.array([0.485, 0.456, 0.406], dtype=np.float32)
        std = np.array([0.229, 0.224, 0.225], dtype=np.float32)
        image = (image * std + mean) * 255  # 反归一化
        image = np.clip(image, 0, 255).astype(np.uint8)
        
        image = Image.fromarray(image, mode='RGB').resize(self.output_size, Image.BILINEAR)
        
        # 标签已经二值化为 0.0 或 1.0，需要转换为 0-255 再进行 resize
        label_255 = (label * 255).astype(np.uint8)  # 转换回 0-255 用于 resize
        label = Image.fromarray(label_255).resize(self.output_size, Image.NEAREST)
        
        # 转回 float32 并重新归一化
        image = np.array(image, dtype=np.float32) / 255.0
        
        # ImageNet 标准化
        mean = np.array([0.485, 0.456, 0.406], dtype=np.float32)
        std = np.array([0.229, 0.224, 0.225], dtype=np.float32)
        image = (image - mean) / std
        image = image.transpose(2, 0, 1)  # [H, W, 3] -> [3, H, W]
        
        label = np.array(label, dtype=np.float32)
        label = (label > 127).astype(np.float32)  # 再次二值化 0-255 -> 0-1
        
        sample = {'image': torch.from_numpy(image), 'label': torch.from_numpy(label).long()}
        return sample

def load_split(split_name, train_mode=True, root_path='.', img_size=512, num_workers=4):
    from datasets.dataset_synapse import ImageDataset, RandomGenerator

    image_dir = os.path.join(root_path, split_name, 'image')
    label_dir = os.path.join(root_path, split_name, 'label')
    print(f"加载{split_name}数据...")
    print(f"  Image目录: {image_dir}")
    print(f"  Label目录: {label_dir}")
    transform = RandomGenerator(output_size=[img_size, img_size]) if train_mode else ResizeToTensor((img_size, img_size))
    dataset = ImageDataset(
        image_dir=image_dir,
        label_dir=label_dir,
        transform=transform
    )
    print(f"{split_name}集大小: {len(dataset)}")
    return dataset

def dice_loss(pred, target, threshold=0.5):
    """
    计算 Dice Loss
    pred: [B, 2, H, W] - 模型输出（logits）
    target: [B, H, W] - 目标标签
    threshold: 二值化阈值
    """
    # 如果是 [B, 2, H, W]，取第 1 类的概率
    if pred.dim() == 4 and pred.size(1) == 2:
        pred_prob = torch.softmax(pred, dim=1)[:, 1]  # [B, H, W]
    else:
        pred_prob = pred
    
    pred_binary = (pred_prob >= threshold).float()
    
    intersection = (pred_binary * target).sum()
    union = pred_binary.sum() + target.sum()
    
    dice_score = 2 * intersection / (union + 1e-8)
    return 1 - dice_score

def evaluate(model, loader, criterion, threshold=0.2):
    model.eval()
    total_loss = 0.0
    tp = fp = fn = 0
    debug_printed = False  # 仅打印第一个batch的调试信息
    with torch.no_grad():
        for batch in loader:
            images = batch['image'].to(device)
            labels = batch['label'].long().to(device)

            outputs = model(images)
            surface_logits = outputs

            # CE Loss
            ce_loss = criterion(surface_logits, labels)

            # Dice Loss
            dice_l = dice_loss(surface_logits, labels.float(), threshold)
            
            # 合并损失 (Dice权重从1.0降到0.5)
            loss = ce_loss + 0.5 * dice_l
            total_loss += loss.item()

            prob = torch.softmax(outputs, dim=1)[:, 1]
            pred = (prob >= threshold).long()
            
            # 调试：打印第一个batch的信息
            if not debug_printed:
                print(f"\n[验证调试] 第一个Batch:")
                print(f"  Label形状: {labels.shape}, 唯一值: {torch.unique(labels)}")
                print(f"  Pred形状: {pred.shape}, 唯一值: {torch.unique(pred)}")
                print(f"  Label类1的数量: {(labels == 1).sum().item()}")
                print(f"  Pred类1的数量: {(pred == 1).sum().item()}")
                print(f"  Prob min/max/mean: {prob.min():.4f}/{prob.max():.4f}/{prob.mean():.4f}")
                debug_printed = True
            
            tp += int(((pred == 1) & (labels == 1)).sum().item())
            fp += int(((pred == 1) & (labels == 0)).sum().item())
            fn += int(((pred == 0) & (labels == 1)).sum().item())

    avg_loss = total_loss / max(len(loader), 1)
    precision = tp / (tp + fp + 1e-8)
    recall = tp / (tp + fn + 1e-8)
    f1 = 2 * precision * recall / (precision + recall + 1e-8)
    iou = tp / (tp + fp + fn + 1e-8)
    return avg_loss, iou, f1, precision, recall

def evaluate_skeleton(
    model,
    loader,
    criterion,
    threshold=0.2,
    skeleton_threshold=0.5,
    stage_distill_scale=1.0,
):
    model.eval()
    total_loss = 0.0
    surface_tp = surface_fp = surface_fn = 0
    skeleton_tp = skeleton_fp = skeleton_fn = 0

    with torch.no_grad():
        for batch in loader:
            images = batch['image'].to(device)
            masks = batch['mask'].to(device)
            skeletons = batch['skeleton'].to(device)
            skeletons_dilate = batch['skeleton_dilate'].to(device)

            images_padded, orig_shape = pad_to_window_multiple(images, window_size=1)
            masks_padded, _ = pad_to_window_multiple(masks, window_size=1)
            skeletons_padded, _ = pad_to_window_multiple(skeletons, window_size=1)
            skeletons_dilate_padded, _ = pad_to_window_multiple(skeletons_dilate, window_size=1)
            
            outputs = model(images_padded)

            if isinstance(outputs, tuple):
                (
                    surface_logits,
                    boundary_logits,
                    skeleton_logits,
                    connectivity_logits,
                    stage_outputs,
                ) = outputs[:5]
            else:
                raise RuntimeError("Structure-guided training requires auxiliary model outputs.")
            surface_logits = crop_to_shape(surface_logits, orig_shape)
            boundary_logits = crop_to_shape(boundary_logits, orig_shape)
            skeleton_logits = crop_to_shape(skeleton_logits, orig_shape)
            connectivity_logits = crop_to_shape(connectivity_logits, orig_shape)
            
            masks_padded = crop_to_shape(masks_padded, orig_shape)
            skeletons_padded = crop_to_shape(skeletons_padded, orig_shape)
            skeletons_dilate_padded = crop_to_shape(skeletons_dilate_padded, orig_shape)

            loss, _ = criterion(
                surface_logits,
                surface_gt=masks_padded,
                skeleton_gt=skeletons_padded,
                skeleton_dilate_gt=skeletons_dilate_padded,
                stage_outputs=stage_outputs,
                boundary_logits=boundary_logits,
                skeleton_logits=skeleton_logits,
                connectivity_logits=connectivity_logits,
            )
            total_loss += loss.item()

            surface_pred = (torch.sigmoid(surface_logits) >= threshold).float().squeeze(1)
            masks_bin = (masks_padded > 0.5).float().squeeze(1)

            surface_tp += int((surface_pred * masks_bin).sum().item())
            surface_fp += int((surface_pred * (1.0 - masks_bin)).sum().item())
            surface_fn += int(((1.0 - surface_pred) * masks_bin).sum().item())

            if skeleton_logits is not None:
                skeleton_pred = (
                    torch.sigmoid(skeleton_logits) >= skeleton_threshold
                ).float().squeeze(1)
                skeletons_bin = (skeletons_padded > 0.5).float().squeeze(1)
                skeleton_tp += int((skeleton_pred * skeletons_bin).sum().item())
                skeleton_fp += int((skeleton_pred * (1.0 - skeletons_bin)).sum().item())
                skeleton_fn += int(((1.0 - skeleton_pred) * skeletons_bin).sum().item())

    avg_loss = total_loss / max(len(loader), 1)

    surface_precision = surface_tp / (surface_tp + surface_fp + 1e-8)
    surface_recall = surface_tp / (surface_tp + surface_fn + 1e-8)
    surface_f1 = 2 * surface_precision * surface_recall / (surface_precision + surface_recall + 1e-8)
    surface_iou = surface_tp / (surface_tp + surface_fp + surface_fn + 1e-8)
    skeleton_precision = skeleton_tp / (skeleton_tp + skeleton_fp + 1e-8)
    skeleton_recall = skeleton_tp / (skeleton_tp + skeleton_fn + 1e-8)
    skeleton_f1 = 2 * skeleton_precision * skeleton_recall / (skeleton_precision + skeleton_recall + 1e-8)
    skeleton_iou = skeleton_tp / (skeleton_tp + skeleton_fp + skeleton_fn + 1e-8)

    return {
        'loss': avg_loss,
        'surface_iou': surface_iou,
        'surface_f1': surface_f1,
        'surface_precision': surface_precision,
        'surface_recall': surface_recall,
        'skeleton_iou': skeleton_iou,
        'skeleton_f1': skeleton_f1,
        'skeleton_precision': skeleton_precision,
        'skeleton_recall': skeleton_recall,
    }


def evaluate_overlap_full_images(
    model,
    loader,
    criterion=None,
    threshold=0.2,
    skeleton_threshold=0.5,
    tile_size=512,
    stride=256,
):
    model.eval()
    total_loss = 0.0
    surface_tp = surface_fp = surface_fn = 0
    skeleton_tp = skeleton_fp = skeleton_fn = 0
    image_count = 0
    positions = RoadSkeletonDataset.sliding_positions
    weight_1d = torch.linspace(-1.0, 1.0, steps=tile_size, device=device).abs()
    weight_1d = (1.0 - weight_1d).clamp_min(0.1)
    tile_weight = (weight_1d[:, None] * weight_1d[None, :]).view(1, 1, tile_size, tile_size)

    with torch.no_grad():
        for batch in loader:
            full_images = batch['image'].to(device)
            full_masks = batch['mask'].to(device)
            full_skeletons = batch['skeleton'].to(device)
            full_skeletons_dilate = batch['skeleton_dilate'].to(device)
            for image_index in range(full_images.shape[0]):
                image = full_images[image_index:image_index + 1]
                mask = full_masks[image_index:image_index + 1]
                skeleton = full_skeletons[image_index:image_index + 1]
                skeleton_dilate = full_skeletons_dilate[image_index:image_index + 1]
                height, width = image.shape[-2:]
                logit_canvas = torch.zeros((1, 1, height, width), device=device)
                skeleton_logit_canvas = torch.zeros_like(logit_canvas)
                weight_canvas = torch.zeros_like(logit_canvas)

                for top in positions(height, tile_size, stride):
                    for left in positions(width, tile_size, stride):
                        tile = image[:, :, top:top + tile_size, left:left + tile_size]
                        outputs = model(tile)
                        surface_logits = outputs[0]
                        skeleton_logits = outputs[2]
                        tile_height, tile_width = surface_logits.shape[-2:]
                        weight = tile_weight[:, :, :tile_height, :tile_width]
                        logit_canvas[:, :, top:top + tile_height, left:left + tile_width] += surface_logits * weight
                        if skeleton_logits is not None:
                            skeleton_logit_canvas[:, :, top:top + tile_height, left:left + tile_width] += skeleton_logits * weight
                        weight_canvas[:, :, top:top + tile_height, left:left + tile_width] += weight

                if weight_canvas.min().item() <= 0:
                    raise RuntimeError("Overlap validation left uncovered pixels in the full-image canvas.")
                full_logits = logit_canvas / weight_canvas.clamp_min(1e-8)
                surface_pred = (torch.sigmoid(full_logits) >= threshold).float()
                mask_bin = (mask > 0.5).float()
                surface_tp += int((surface_pred * mask_bin).sum().item())
                surface_fp += int((surface_pred * (1.0 - mask_bin)).sum().item())
                surface_fn += int(((1.0 - surface_pred) * mask_bin).sum().item())

                if skeleton_logits is not None:
                    full_skeleton_logits = skeleton_logit_canvas / weight_canvas.clamp_min(1e-8)
                    if criterion is not None:
                        loss, _ = criterion(
                            full_logits,
                            surface_gt=mask,
                            skeleton_gt=skeleton,
                            skeleton_dilate_gt=skeleton_dilate,
                            skeleton_logits=full_skeleton_logits,
                        )
                        total_loss += float(loss.item())
                    skeleton_pred = (torch.sigmoid(full_skeleton_logits) >= skeleton_threshold).float()
                    skeleton_bin = (skeleton > 0.5).float()
                    skeleton_tp += int((skeleton_pred * skeleton_bin).sum().item())
                    skeleton_fp += int((skeleton_pred * (1.0 - skeleton_bin)).sum().item())
                    skeleton_fn += int(((1.0 - skeleton_pred) * skeleton_bin).sum().item())
                elif criterion is not None:
                    loss, _ = criterion(
                        full_logits,
                        surface_gt=mask,
                        skeleton_gt=skeleton,
                        skeleton_dilate_gt=skeleton_dilate,
                    )
                    total_loss += float(loss.item())
                image_count += 1

    surface_precision = surface_tp / (surface_tp + surface_fp + 1e-8)
    surface_recall = surface_tp / (surface_tp + surface_fn + 1e-8)
    skeleton_precision = skeleton_tp / (skeleton_tp + skeleton_fp + 1e-8)
    skeleton_recall = skeleton_tp / (skeleton_tp + skeleton_fn + 1e-8)
    return {
        'loss': total_loss / max(image_count, 1) if criterion is not None else 0.0,
        'surface_iou': surface_tp / (surface_tp + surface_fp + surface_fn + 1e-8),
        'surface_f1': 2 * surface_precision * surface_recall / (surface_precision + surface_recall + 1e-8),
        'surface_precision': surface_precision,
        'surface_recall': surface_recall,
        'skeleton_iou': skeleton_tp / (skeleton_tp + skeleton_fp + skeleton_fn + 1e-8),
        'skeleton_f1': 2 * skeleton_precision * skeleton_recall / (skeleton_precision + skeleton_recall + 1e-8),
        'skeleton_precision': skeleton_precision,
        'skeleton_recall': skeleton_recall,
        'image_count': image_count,
    }


def component_stats(mask_bool, short_area_threshold):
    num, _, stats, _ = cv2.connectedComponentsWithStats(
        mask_bool.astype(np.uint8),
        connectivity=8,
    )
    areas = stats[1:, cv2.CC_STAT_AREA] if num > 1 else np.empty((0,), dtype=np.int32)
    total = float(areas.sum()) if areas.size else 0.0
    return {
        "components": float(num - 1),
        "short_components": float((areas < short_area_threshold).sum()) if areas.size else 0.0,
        "largest_ratio": float(areas.max() / total) if total > 0 else 0.0,
    }


def cldice_scores(surface_prob, surface_gt):
    pred_skel = soft_skeletonize(surface_prob.float().clamp(0.0, 1.0), iter_num=10)
    gt_skel = soft_skeletonize(surface_gt.float().clamp(0.0, 1.0), iter_num=10)
    tprec = (pred_skel * surface_gt).sum(dim=(1, 2, 3)) / (
        pred_skel.sum(dim=(1, 2, 3)) + 1e-8
    )
    tsens = (gt_skel * surface_prob).sum(dim=(1, 2, 3)) / (
        gt_skel.sum(dim=(1, 2, 3)) + 1e-8
    )
    return ((2.0 * tprec * tsens) / (tprec + tsens + 1e-8)).detach().cpu().numpy()


def evaluate_trend_topology_subset(
    model,
    loader,
    threshold=0.2,
    max_batches=0,
    short_area_threshold=20,
):
    was_training = model.training
    model.eval()
    tp = fp = fn = 0.0
    cldice_values = []
    pred_components = []
    gt_components = []
    frag_indices = []
    extra_components = []
    pred_short = []
    gt_short = []
    pred_largest = []
    gt_largest = []
    n_images = 0

    with torch.no_grad():
        for batch_idx, batch in enumerate(loader):
            if max_batches > 0 and batch_idx >= max_batches:
                break
            images = batch['image'].to(device)
            masks = batch['mask'].to(device).float()
            images_padded, orig_shape = pad_to_window_multiple(images, window_size=1)
            outputs = model(images_padded)
            surface_logits = outputs[0] if isinstance(outputs, tuple) else outputs
            surface_logits = crop_to_shape(surface_logits, orig_shape)
            if masks.shape[-2:] != surface_logits.shape[-2:]:
                masks = F.interpolate(
                    masks,
                    size=surface_logits.shape[-2:],
                    mode="nearest",
                )
            surface_prob = torch.sigmoid(surface_logits)
            pred = surface_prob >= threshold
            gt = masks > 0.5

            tp += float((pred & gt).sum().item())
            fp += float((pred & (~gt)).sum().item())
            fn += float(((~pred) & gt).sum().item())
            cldice_values.extend(cldice_scores(surface_prob, masks).tolist())

            pred_np = pred.detach().cpu().numpy()[:, 0]
            gt_np = gt.detach().cpu().numpy()[:, 0]
            for pred_mask, gt_mask in zip(pred_np, gt_np):
                ps = component_stats(pred_mask, short_area_threshold)
                gs = component_stats(gt_mask, short_area_threshold)
                gt_components_safe = max(gs["components"], 1.0)
                pred_components.append(ps["components"])
                gt_components.append(gs["components"])
                frag_indices.append(ps["components"] / gt_components_safe)
                extra_components.append(max(ps["components"] - gs["components"], 0.0))
                pred_short.append(ps["short_components"])
                gt_short.append(gs["short_components"])
                pred_largest.append(ps["largest_ratio"])
                gt_largest.append(gs["largest_ratio"])
                n_images += 1

    if was_training:
        model.train()

    precision = tp / (tp + fp + 1e-8)
    recall = tp / (tp + fn + 1e-8)
    iou = tp / (tp + fp + fn + 1e-8)
    return {
        "iou": iou,
        "precision": precision,
        "recall": recall,
        "cldice": float(np.mean(cldice_values)) if cldice_values else float("nan"),
        "pred_comp": float(np.mean(pred_components)) if pred_components else float("nan"),
        "gt_comp": float(np.mean(gt_components)) if gt_components else float("nan"),
        "frag_idx": float(np.mean(frag_indices)) if frag_indices else float("nan"),
        "extra_comp": float(np.mean(extra_components)) if extra_components else float("nan"),
        "pred_short": float(np.mean(pred_short)) if pred_short else float("nan"),
        "gt_short": float(np.mean(gt_short)) if gt_short else float("nan"),
        "pred_largest_ratio": float(np.mean(pred_largest)) if pred_largest else float("nan"),
        "gt_largest_ratio": float(np.mean(gt_largest)) if gt_largest else float("nan"),
        "n_images": n_images,
    }


if __name__ == "__main__":
    # 自动检测可用设备
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    use_bf16_amp = (
        device.type == 'cuda'
        and args.amp_dtype == 'bfloat16'
        and torch.cuda.is_bf16_supported()
    )
    print(f"[INFO] Using device: {device}")
    if args.amp_dtype == 'bfloat16' and not use_bf16_amp:
        print("[WARN] BF16 AMP is unsupported on this device; using FP32.", flush=True)
    
    if not args.deterministic:
        cudnn.benchmark = True
        cudnn.deterministic = False
    else:
        cudnn.benchmark = False
        cudnn.deterministic = True

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(args.seed)

    loader_generator = torch.Generator()
    loader_generator.manual_seed(args.seed)

    # 设置训练参数
    base_output_dir = args.output_dir
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_name = args.run_name.strip() if args.run_name.strip() else f"train_skeleton_{timestamp}"
    resume_output_dir = None
    if args.resume:
        resume_path = os.path.abspath(args.resume)
        resume_dir = os.path.dirname(resume_path)
        if os.path.basename(resume_dir).lower() == "checkpoints":
            resume_dir = os.path.dirname(resume_dir)
        if os.path.isfile(resume_path):
            resume_output_dir = resume_dir
    args.output_dir = resume_output_dir or make_unique_dir(base_output_dir, run_name)
    os.makedirs(args.output_dir, exist_ok=True)
    checkpoints_dir = os.path.join(args.output_dir, 'checkpoints')
    os.makedirs(checkpoints_dir, exist_ok=True)
    loss_log_path = os.path.join(args.output_dir, 'epoch_losses.csv')
    batch_loss_log_path = os.path.join(args.output_dir, 'batch_losses.csv')
    training_log_path = os.path.join(args.output_dir, 'training_log.txt')  # 统一日志文件
    
    inherit_resume_architecture_args(args)
    apply_structure_profile_defaults(args)
    if h_phase_reference_report is not None:
        from h0_phase_training import write_report
        h_phase_reference_report['resolved_args'] = dict(vars(args))
        write_report(os.path.join(args.output_dir, 'h0_reference_config.json'), h_phase_reference_report)
        print('[H0 CONFIG] Original H0 settings inherited; reference weights are not loaded.', flush=True)
        print('[H0 CONFIG] accumulation_steps={} seed={} max_epochs={} EMA={} AMP={}'.format(
            args.accumulation_steps, args.seed, args.max_epochs, args.use_ema, args.amp_dtype), flush=True)
        print('[SAMPLING] original Mass H0 shared epoch and crop sequence restored; persistent_workers=False', flush=True)

    # 加载配置
    config = get_config(args)
    if args.pretrain_ckpt:
        config.defrost()
        config.MODEL.PRETRAIN_CKPT = args.pretrain_ckpt
        config.freeze()
    
    # 对齐 img_size 到 window_size=8 的倍数（模型初始化时需要）
    # Swin blocks pad their own feature maps for window=7 attention.
    window_size = int(config.MODEL.SWIN.WINDOW_SIZE)
    aligned_img_size = args.img_size
    if aligned_img_size != args.img_size:
        print(f"[INFO] 对齐 img_size: {args.img_size} -> {aligned_img_size} (window_size={window_size})")
        config.defrost()
        config.DATA.IMG_SIZE = aligned_img_size
        config.freeze()
        args.img_size = aligned_img_size
    
    # 创建网络（启用 DilatedAsterisk 空间特征增强）
    args.num_classes = 1
    loss_weights = get_final_loss_weights(args)
    model = ViT_seg(config=config, img_size=args.img_size,
                    num_classes=args.num_classes,
                    return_skeleton=True, bottleneck_type=args.bottleneck_type,
                    final_topology_eta_init=args.final_topology_eta_init,
                    final_gap_rho_init=args.final_gap_rho_init,
                    structure_profile=args.structure_profile,
                    stage2_skeleton_gradient_ratio=args.stage2_skeleton_gradient_ratio,
                    stage3_skeleton_gradient_ratio=args.stage3_skeleton_gradient_ratio,
                    stage3_gate_topology_gradient_ratio=(
                        args.stage3_gate_topology_gradient_ratio
                    ),
                    final_skeleton_gradient_ratio=args.final_skeleton_gradient_ratio,
                    enable_highres_structure_stream=args.enable_highres_structure_stream,
                    highres_structure_channels=args.highres_structure_channels,
                    highres_structure_fuse_stages=args.highres_structure_fuse_stages,
                    highres_structure_fusion_mode=args.highres_structure_fusion_mode,
                    enable_post_refine_structure_interaction=(
                        args.enable_post_refine_structure_interaction
                    ),
                    enable_global_topology=args.enable_global_topology,
                    global_topology_max_nodes=args.global_topology_max_nodes,
                    global_topology_heads=args.global_topology_heads,
                    global_topology_alpha_max=args.global_topology_alpha_max,
                    stage_skeleton_mode=args.stage_skeleton_mode,
                    enable_h3_surface_fusion=args.enable_h3_surface_fusion,
                    stage_skeleton_bias_init=args.stage_skeleton_bias_init,
                    stage_skeleton_positive_prior=args.stage_skeleton_positive_prior,
                    remove_stage2_pre_topology_source=args.remove_stage2_pre_topology_source).to(device)

    loaded_pretrained_names = set()
    if not args.resume and not args.warm_start_ckpt and not args.no_pretrain:
        pretrain_path = config.MODEL.PRETRAIN_CKPT
        if not os.path.isfile(pretrain_path):
            raise FileNotFoundError(
                f"Swin pretrained checkpoint not found: {pretrain_path}. "
                "Set --pretrain_ckpt or use --no_pretrain."
            )
        loaded_pretrained_names = model.load_from(config)

    if args.encoder_h_postmerge_phase:
        from networks.encoder_h_postmerge_phase import install_encoder_h_postmerge_phase
        from h0_phase_training import tensor_digests, write_report
        before_phase = tensor_digests(model)
        install_encoder_h_postmerge_phase(model, args.h_phase_initial_strength,
            global_topology_stage2=args.global_topology_stage2,
            disable_stage3_gap_calibration=args.disable_stage3_gap_calibration)
        if args.global_topology_stage2:
            print('[GLOBAL TOPOLOGY] after decoder Stage2, using H1, shared surface prior P2 and C2', flush=True)
        after_phase = tensor_digests(model)
        retained = [key for key in before_phase if key in after_phase]
        changed = [key for key in retained if before_phase[key] != after_phase[key]]
        removed = sorted(set(before_phase)-set(after_phase))
        expected_removed = sorted(model.swin_unet.encoder_a1a2_removed_keys +
                                  model.swin_unet.stage3_gap_removed_keys)
        if changed or removed != expected_removed:
            raise RuntimeError('Shared H0 initialization differs outside the requested deletions')
        initial_report = dict(base='599a410', shared_tensors_checked=len(retained), mismatches=changed,
            removed_keys=removed, initial_tensors=after_phase, pretrain_sha256=h_phase_reference_report['pretrain_sha256'],
            initialization='SwinV2/ImageNet plus original H0 random initialization; no trained road weights')
        if not args.resume:
            if args.h_phase_smoke_manifest:
                with open(args.h_phase_smoke_manifest, encoding='utf-8') as stream:
                    smoke_initial = json.load(stream)
                if (smoke_initial['initial_tensors'] != initial_report['initial_tensors'] or
                        smoke_initial['pretrain_sha256'] != initial_report['pretrain_sha256']):
                    raise ValueError('Training initialization differs from the successful smoke run')
            write_report(os.path.join(args.output_dir, 'phase_initial_state.json'), initial_report)
        print('[PHASE INIT] retained={} changed={} removed={}'.format(len(retained), len(changed), len(removed)), flush=True)

    def build_layerwise_optimizer():
        loaded_params, new_params = [], []
        for name, parameter in model.named_parameters():
            if not parameter.requires_grad:
                continue
            (loaded_params if name in loaded_pretrained_names else new_params).append(parameter)
        groups = []
        if loaded_params:
            groups.append({'params': loaded_params, 'lr': args.pretrained_lr, 'initial_lr': args.pretrained_lr, 'group_name': 'imagenet_loaded'})
        if new_params:
            groups.append({'params': new_params, 'lr': args.new_lr, 'initial_lr': args.new_lr, 'group_name': 'random_or_custom'})
        print(f"[INFO] LR groups: ImageNet-loaded={len(loaded_params)} tensors at {args.pretrained_lr:g}; new/custom={len(new_params)} tensors at {args.new_lr:g}", flush=True)
        return torch.optim.AdamW(groups, weight_decay=0.0001)

    def restore_loaded_pretrained_names_from_checkpoint(checkpoint):
        restored_names = checkpoint.get('loaded_pretrained_names')
        if restored_names is not None:
            return set(restored_names)

        checkpoint_args = checkpoint.get('args', {})
        pretrain_path = checkpoint_args.get('pretrain_ckpt') or config.MODEL.PRETRAIN_CKPT
        if args.no_pretrain or not pretrain_path or not os.path.isfile(pretrain_path):
            print(
                "[WARN] Cannot restore ImageNet-loaded parameter group metadata; "
                "resume optimizer may not match the original training groups.",
                flush=True,
            )
            return set()

        pretrain_checkpoint = torch.load(
            pretrain_path,
            map_location="cpu",
            weights_only=False,
        )
        pretrained_dict = pretrain_checkpoint.get("model", pretrain_checkpoint)
        model_dict = model.swin_unet.state_dict()
        restored = set()
        for key, value in pretrained_dict.items():
            if key.startswith("head.") or "relative_position_index" in key or "attn_mask" in key:
                continue
            target_key = key
            if ".downsample.reduction.weight" in key:
                target_key = key.replace(".downsample.reduction.weight", ".downsample.linear_reduction.weight")
            if target_key in model_dict and model_dict[target_key].shape == value.shape:
                restored.add("swin_unet." + target_key)
        print(
            "[INFO] Restored ImageNet-loaded parameter group metadata from "
            f"{len(restored)} compatible pretrain tensors.",
            flush=True,
        )
        return restored

    def freeze_post_refine_interaction_only():
        trainable_names = []
        target = "guided_head.post_refine_structure_interaction."
        for name, parameter in model.named_parameters():
            keep_trainable = target in name
            parameter.requires_grad_(keep_trainable)
            if keep_trainable:
                trainable_names.append(name)
        if not trainable_names:
            raise RuntimeError(
                "No post-refine interaction parameters found. "
                "Use --enable_post_refine_structure_interaction."
            )
        print(
            "[INFO] Frozen full model; training only "
            f"{len(trainable_names)} post-refine interaction tensors.",
            flush=True,
        )
        return trainable_names

    # 加载数据
    def load_warm_start_checkpoint(path):
        if not path:
            return set()
        if not os.path.isfile(path):
            raise FileNotFoundError(f"Warm-start checkpoint not found: {path}")
        print(f"[INFO] Warm-start loading compatible tensors from: {path}", flush=True)
        checkpoint = torch.load(path, map_location='cpu')
        checkpoint_state = checkpoint.get('model_state_dict', checkpoint)
        model_state = model.state_dict()
        compatible = {}
        skipped_shape = []
        skipped_missing = []
        for key, value in checkpoint_state.items():
            if key not in model_state:
                skipped_missing.append(key)
                continue
            if model_state[key].shape != value.shape:
                if (
                    key.endswith("feature_residual.0.weight")
                    and model_state[key].ndim == value.ndim == 4
                    and model_state[key].shape[0] == value.shape[0]
                    and model_state[key].shape[1] == 2 * value.shape[1]
                    and model_state[key].shape[2:] == value.shape[2:]
                ):
                    expanded_weight = torch.zeros_like(model_state[key])
                    expanded_weight[:, :value.shape[1]].copy_(
                        value.to(
                            device=expanded_weight.device,
                            dtype=expanded_weight.dtype,
                        )
                    )
                    compatible[key] = expanded_weight
                    continue
                skipped_shape.append(key)
                continue
            compatible[key] = value
        result = model.load_state_dict(compatible, strict=False)
        print(
            "[INFO] Warm-start loaded {} tensors; skipped_missing={}, skipped_shape={}, runtime_missing={}".format(
                len(compatible),
                len(skipped_missing),
                len(skipped_shape),
                len(result.missing_keys),
            ),
            flush=True,
        )
        if skipped_shape:
            print(
                "[INFO] Warm-start skipped shape-mismatch tensors: "
                + ", ".join(skipped_shape[:12])
                + (" ..." if len(skipped_shape) > 12 else ""),
                flush=True,
            )
        return set(compatible)

    train_dataset = RoadSkeletonDataset(
        root_dir=args.root_path,
        split='train',
        image_size=args.img_size,
        source_patch_size=args.source_patch_size,
        tile_size=(
            args.img_size
            if args.random_crop_train
            else None
            if args.direct_resize_train
            else args.img_size
        ),
        tile_stride=args.overlap_stride,
        augment=args.augment,
        random_crop_train=args.random_crop_train,
        random_crops_per_image=args.random_crops_per_image,
        random_crop_seed=args.seed,
    )
    if args.tiny_overfit_samples > 0:
        tiny_count = min(int(args.tiny_overfit_samples), len(train_dataset))
        train_dataset = Subset(train_dataset, list(range(tiny_count)))
        print(
            f"[INFO] Tiny overfit mode: using first {tiny_count} training samples; "
            "train shuffle disabled.",
            flush=True,
        )
    loader_kwargs = {}
    if args.num_workers > 0:
        loader_kwargs["persistent_workers"] = not args.disable_persistent_workers
        loader_kwargs["prefetch_factor"] = max(1, args.loader_prefetch_factor)

    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch_size,
        shuffle=not (args.tiny_overfit_samples > 0),
        num_workers=args.num_workers,
        pin_memory=True,
        worker_init_fn=seed_worker,
        generator=loader_generator,
        **loader_kwargs,
    )

    val_dataset = RoadSkeletonDataset(
        root_dir=args.root_path,
        split='val',
        image_size=args.img_size if (args.direct_resize_train or args.val_crop_list) else None,
        source_patch_size=args.source_patch_size,
        return_full_image=not args.direct_resize_train and not args.val_crop_list,
        crop_list_path=args.val_crop_list,
    )
    val_loader = DataLoader(
        val_dataset,
        batch_size=1,
        shuffle=False,
        num_workers=args.num_workers,
        pin_memory=True,
        worker_init_fn=seed_worker,
        **loader_kwargs,
    )

    # 优化器 / 损失（graph-only 模式在加载 checkpoint 后再建 optimizer）
    criterion = build_criterion(args, loss_weights, device)
    if args.encoder_h_postmerge_phase and args.h_phase_smoke_only:
        from h0_phase_training import smoke
        smoke(model, criterion, train_loader, args, device)
        sys.exit(0)
    optimizer = None

    # 检查是否恢复训练
    start_epoch = 0
    if args.warm_start_ckpt and args.resume:
        raise ValueError("--warm_start_ckpt is for fresh runs; do not combine it with --resume")
    if args.warm_start_ckpt:
        loaded_pretrained_names = load_warm_start_checkpoint(args.warm_start_ckpt)
    if args.resume:
        if os.path.isfile(args.resume):
            print(f"加载checkpoint: {args.resume}")
            checkpoint = torch.load(args.resume, map_location=device)
            checkpoint_state = checkpoint["model_state_dict"]
            if args.encoder_h_postmerge_phase:
                if not checkpoint.get('args', {}).get('encoder_h_postmerge_phase'):
                    raise ValueError('Resume requires a checkpoint from this phase experiment')
                from h0_phase_training import SAMPLING_PROTOCOL
                if checkpoint.get('args', {}).get('sampling_protocol') != SAMPLING_PROTOCOL:
                    raise ValueError('Cannot resume the old sampling experiment; start a fresh 80-epoch run')
                if bool(checkpoint['args'].get('global_topology_stage2')) != args.global_topology_stage2:
                    raise ValueError('Resume checkpoint has a different global topology location')
                model.load_state_dict(checkpoint_state, strict=True)
            model_state = model.state_dict()
            filtered_checkpoint_state = {}
            skipped_gate_keys = []
            skipped_removed_keys = []
            skipped_shape_keys = []
            removed_direction_embedding_prefixes = (
                "swin_unet.decoder_structure_blocks.0.directional_embedding.",
                "swin_unet.decoder_structure_blocks.1.directional_embedding.",
                "swin_unet.decoder_structure_blocks.2.directional_embedding.",
                "swin_unet.decoder_structure_blocks.3.directional_embedding.",
                "swin_unet.stage2_topology_source.directional_embedding.",
            )
            removed_surface_uncertainty_prefixes = (
                "swin_unet.decoder_structure_blocks.0.surface_uncertainty_head.",
                "swin_unet.decoder_structure_blocks.1.surface_uncertainty_head.",
                "swin_unet.decoder_structure_blocks.2.surface_uncertainty_head.",
                "swin_unet.decoder_structure_blocks.3.surface_uncertainty_head.",
                "swin_unet.stage2_topology_source.surface_uncertainty_head.",
            )
            for key, value in checkpoint_state.items():
                if key not in model_state:
                    skipped_removed_keys.append(key)
                    continue
                if value.shape != model_state[key].shape:
                    if (
                        key.endswith("connectivity_head.prior_embed.0.weight")
                        and value.ndim == model_state[key].ndim == 4
                        and value.shape[0] == model_state[key].shape[0]
                        and value.shape[1] >= 2
                        and model_state[key].shape[1] == 2
                        and value.shape[2:] == model_state[key].shape[2:]
                    ):
                        adapted_weight = model_state[key].detach().clone()
                        adapted_weight.copy_(
                            value[:, :2].to(
                                device=adapted_weight.device,
                                dtype=adapted_weight.dtype,
                            )
                        )
                        filtered_checkpoint_state[key] = adapted_weight
                        skipped_shape_keys.append(
                            key + " (dropped direction prior channel)"
                        )
                        continue
                    skipped_shape_keys.append(key)
                    continue
                if (
                    key in model_state
                    and value.shape != model_state[key].shape
                    and key.endswith("structure_gate.0.weight")
                ):
                    skipped_gate_keys.append(key)
                    continue
                filtered_checkpoint_state[key] = value
            if skipped_gate_keys:
                print(
                    "[WARN] Reinitialized structure-gate input weights: "
                    + ", ".join(skipped_gate_keys),
                    flush=True,
                )
            if skipped_removed_keys:
                print(
                    "[WARN] Ignored removed checkpoint keys: "
                    + ", ".join(skipped_removed_keys[:12])
                    + (" ..." if len(skipped_removed_keys) > 12 else ""),
                    flush=True,
                )
            if skipped_shape_keys:
                print(
                    "[WARN] Reinitialized shape-incompatible checkpoint keys: "
                    + ", ".join(skipped_shape_keys[:12])
                    + (" ..." if len(skipped_shape_keys) > 12 else ""),
                    flush=True,
                )
            if skipped_gate_keys or skipped_removed_keys or skipped_shape_keys:
                checkpoint_state = filtered_checkpoint_state
            strict_load = args.bottleneck_type == 'global_local'
            try:
                model.load_state_dict(checkpoint_state, strict=strict_load)
            except RuntimeError as exc:
                allowed_missing_prefixes = (
                        "swin_unet.stage2_topology_source.",
                        "swin_unet.stage_topology_scales.",
                        "swin_unet.global_topology.",
                        "swin_unet.decoder_structure_blocks.3.stage_roadness_head.",
                        "swin_unet.highres_structure_encoder.",
                        "swin_unet.prepatch_structure_encoder.",
                        "swin_unet.highres_skeleton_adapter.",
                        "swin_unet.highres_structure_skeleton_head.",
                        "swin_unet.highres_structure_fusion.",
                        "swin_unet.decoder_structure_blocks.2.highres_skeleton_fusion.",
                        "swin_unet.decoder_structure_blocks.3.highres_skeleton_fusion.",
                        "swin_unet.decoder_structure_blocks.0.direction_head.",
                        "swin_unet.decoder_structure_blocks.1.direction_head.",
                        "swin_unet.decoder_structure_blocks.2.direction_head.",
                        "swin_unet.decoder_structure_blocks.3.direction_head.",
                        "swin_unet.decoder_structure_blocks.0.structure_gate.0.weight",
                        "swin_unet.decoder_structure_blocks.1.structure_gate.0.weight",
                        "swin_unet.decoder_structure_blocks.2.structure_gate.0.weight",
                        "swin_unet.decoder_structure_blocks.3.structure_gate.0.weight",
                        "swin_unet.decoder_structure_blocks.0.reliability_correction.",
                        "swin_unet.decoder_structure_blocks.1.reliability_correction.",
                        "swin_unet.decoder_structure_blocks.2.reliability_correction.",
                        "swin_unet.decoder_structure_blocks.3.reliability_correction.",
                        "swin_unet.decoder_structure_blocks.0.reliability_local.",
                        "swin_unet.decoder_structure_blocks.1.reliability_local.",
                        "swin_unet.decoder_structure_blocks.2.reliability_local.",
                        "swin_unet.decoder_structure_blocks.3.reliability_local.",
                        "swin_unet.decoder_structure_blocks.0.reliability_context.",
                        "swin_unet.decoder_structure_blocks.1.reliability_context.",
                        "swin_unet.decoder_structure_blocks.2.reliability_context.",
                        "swin_unet.decoder_structure_blocks.3.reliability_context.",
                        "swin_unet.decoder_structure_blocks.0.reliability_direction.",
                        "swin_unet.decoder_structure_blocks.1.reliability_direction.",
                        "swin_unet.decoder_structure_blocks.2.reliability_direction.",
                        "swin_unet.decoder_structure_blocks.3.reliability_direction.",
                        "swin_unet.decoder_structure_blocks.0.reliability_fuse.",
                        "swin_unet.decoder_structure_blocks.1.reliability_fuse.",
                        "swin_unet.decoder_structure_blocks.2.reliability_fuse.",
                        "swin_unet.decoder_structure_blocks.3.reliability_fuse.",
                        "swin_unet.decoder_structure_blocks.0.reliability_beta",
                        "swin_unet.decoder_structure_blocks.1.reliability_beta",
                        "swin_unet.decoder_structure_blocks.2.reliability_beta",
                        "swin_unet.decoder_structure_blocks.3.reliability_beta",
                        "swin_unet.decoder_structure_blocks.0.gate_branch.",
                        "swin_unet.decoder_structure_blocks.1.gate_branch.",
                        "swin_unet.decoder_structure_blocks.2.gate_branch.",
                        "swin_unet.decoder_structure_blocks.3.gate_branch.",
                        "swin_unet.stage2_topology_source.direction_head.",
                        "swin_unet.stage2_topology_source.structure_gate.0.weight",
                        "swin_unet.stage2_topology_source.reliability_correction.",
                        "swin_unet.stage2_topology_source.reliability_local.",
                        "swin_unet.stage2_topology_source.reliability_context.",
                        "swin_unet.stage2_topology_source.reliability_direction.",
                        "swin_unet.stage2_topology_source.reliability_fuse.",
                        "swin_unet.stage2_topology_source.reliability_beta",
                        "swin_unet.stage2_topology_source.gate_branch.",
                        "swin_unet.guided_head.detached_skeleton_refine.",
                        "swin_unet.guided_head.detached_skeleton_head.",
                        "swin_unet.guided_head.final_skeleton_aux_head.",
                        "swin_unet.guided_head.post_refine_structure_interaction.",
                )
                allowed_unexpected_prefixes = (
                        "swin_unet.coarse_road_mask_head.",
                        "swin_unet.bottleneck_coarse_road_mask_head.",
                        "swin_unet.decoder_structure_blocks.0.reliability_correction.",
                        "swin_unet.decoder_structure_blocks.1.reliability_correction.",
                        "swin_unet.decoder_structure_blocks.2.reliability_correction.",
                        "swin_unet.decoder_structure_blocks.3.reliability_correction.",
                        "swin_unet.stage2_topology_source.reliability_correction.",
                        "swin_unet.guided_head.skeleton_proj.",
                        "swin_unet.guided_head.structure_branch.",
                        "swin_unet.guided_head.skeleton_head.",
                        "swin_unet.guided_head.detached_skeleton_refine.",
                        "swin_unet.guided_head.detached_skeleton_head.",
                        "swin_unet.guided_head.connectivity_context.",
                        "swin_unet.guided_head.connectivity_head.",
                        "swin_unet.guided_head.structure_to_surface.",
                        "swin_unet.guided_head.structure_to_surface_gamma",
                        "swin_unet.guided_head.final_topology_attention.",
                        "swin_unet.guided_head.structure_fusion.",
                        "swin_unet.guided_head.structure_residual.",
                        "swin_unet.decoder_structure_blocks.0.directional_embedding.",
                        "swin_unet.decoder_structure_blocks.1.directional_embedding.",
                        "swin_unet.decoder_structure_blocks.2.directional_embedding.",
                        "swin_unet.decoder_structure_blocks.3.directional_embedding.",
                        "swin_unet.stage2_topology_source.directional_embedding.",
                        "swin_unet.decoder_structure_blocks.0.surface_uncertainty_head.",
                        "swin_unet.decoder_structure_blocks.1.surface_uncertainty_head.",
                        "swin_unet.decoder_structure_blocks.2.surface_uncertainty_head.",
                        "swin_unet.decoder_structure_blocks.3.surface_uncertainty_head.",
                        "swin_unet.stage2_topology_source.surface_uncertainty_head.",
                )
                result = model.load_state_dict(
                    checkpoint_state,
                    strict=False,
                )
                invalid_missing = [
                    key
                    for key in result.missing_keys
                    if not key.startswith(allowed_missing_prefixes)
                ]
                invalid_unexpected = [
                    key
                    for key in result.unexpected_keys
                    if not key.startswith(allowed_unexpected_prefixes)
                ]
                if invalid_missing or invalid_unexpected:
                    raise RuntimeError(
                        "Checkpoint mismatch on resume: "
                        f"missing={invalid_missing}, unexpected={invalid_unexpected}"
                    ) from exc
                print(
                    "[WARN] Loaded checkpoint with strict=False; "
                    "some modules use fresh initialization.",
                    flush=True,
                )
            start_epoch = checkpoint.get('epoch', 0)
            if not args.freeze_post_refine_interaction_only:
                try:
                    loaded_pretrained_names = restore_loaded_pretrained_names_from_checkpoint(checkpoint)
                    optimizer = build_layerwise_optimizer()
                    optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
                except (ValueError, RuntimeError) as exc:
                    print(
                        "[WARN] Optimizer state not restored; "
                        "continuing with a fresh optimizer for current parameters.",
                        flush=True,
                    )
                    print(f"[WARN] Optimizer resume detail: {exc}", flush=True)
            print(f"从epoch {start_epoch} 继续训练...")
        else:
            print(f"Warning: checkpoint未找到 {args.resume}")

    if args.freeze_post_refine_interaction_only:
        freeze_post_refine_interaction_only()
        optimizer = None

    if optimizer is None:
        optimizer = build_layerwise_optimizer()

    ema = ModelEMA(model, decay=args.ema_decay) if args.use_ema else None
    if ema is not None and args.resume and 'checkpoint' in locals():
        ema_state = checkpoint.get('ema_state_dict')
        if ema_state is not None:
            try:
                ema.ema.load_state_dict(ema_state)
            except RuntimeError as exc:
                result = ema.ema.load_state_dict(ema_state, strict=False)
                print(
                    "[WARN] Loaded EMA checkpoint with strict=False; "
                    f"missing={len(result.missing_keys)}, unexpected={len(result.unexpected_keys)}. "
                    f"Detail: {exc}",
                    flush=True,
                )

    end_epoch = args.max_epochs
    if args.finetune_epochs > 0:
        end_epoch = min(args.max_epochs, start_epoch + int(args.finetune_epochs))
        print(
            f"[INFO] Fine-tune window: epochs {start_epoch + 1}-{end_epoch} "
            f"(LR schedule still uses max_epochs={args.max_epochs})",
            flush=True,
        )

    # 训练循环
    print("\n开始训练...")
    print(f"配置:")
    print(f"  最大轮数: {args.max_epochs}")
    print(f"  批大小: {args.batch_size}")
    print(f"  学习率: {args.base_lr}")
    print(f"  最小学习率: {args.min_lr}")
    print(f"  Warmup轮数: {args.warmup_epochs}")
    accumulation_steps = max(1, int(args.accumulation_steps or 1))
    print(f"  Gradient accumulation steps: {accumulation_steps}")
    for line in format_training_config_lines(args, loss_weights):
        print(line)
    print(f"  输出目录: {args.output_dir}")
    print(f"  Checkpoints目录: {checkpoints_dir}")
    print(f"  验证阈值: {args.threshold}")
    if args.max_train_batches > 0:
        print(f"  每轮最多训练batch数: {args.max_train_batches}")
    if args.trend_val_every_steps > 0:
        print(
            f"  Trend validation: every {args.trend_val_every_steps} step(s), "
            f"max_val_batches={args.trend_val_max_batches or 'all'}, "
            f"short_area<{args.trend_val_short_area_threshold}",
            flush=True,
        )
    if args.resume:
        print(f"  从checkpoint恢复: {args.resume}")
        print(f"  起始epoch: {start_epoch}")

    print("Using topology attention constrained version", flush=True)
    print_topology_coefficients(model)

    best_path = os.path.join(args.output_dir, 'best.pth')
    best_val_f1 = -1.0
    if args.resume and os.path.isfile(best_path):
        try:
            best_checkpoint_for_score = torch.load(best_path, map_location='cpu')
            best_val_f1 = float(best_checkpoint_for_score.get('val_f1', -1.0))
            print(
                f"[INFO] Resuming with existing best.pth F1={best_val_f1:.6f}",
                flush=True,
            )
        except Exception as exc:
            print(f"[WARN] Could not read existing best.pth score: {exc}", flush=True)
    elif args.resume and 'checkpoint' in locals():
        best_val_f1 = float(checkpoint.get('val_f1', -1.0))

    append_existing_logs = bool(args.resume and start_epoch > 0)
    
    # 写入训练日志头
    with open(training_log_path, 'a' if append_existing_logs else 'w', encoding='utf-8') as log_f:
        if append_existing_logs:
            log_f.write("\n" + "="*100 + "\n")
            log_f.write(f"Resume training from epoch {start_epoch}\n")
            log_f.write(f"Resume checkpoint: {args.resume}\n")
            log_f.write(f"Existing best F1: {best_val_f1:.6f}\n")
            log_f.write("="*100 + "\n")
        log_f.write("="*100 + "\n")
        log_f.write("Swin-UNet 训练日志\n")
        log_f.write("="*100 + "\n")
        log_f.write(f"训练配置:\n")
        log_f.write(f"  最大轮数: {args.max_epochs}\n")
        log_f.write(f"  批大小: {args.batch_size}\n")
        log_f.write(f"  学习率: {args.base_lr}\n")
        log_f.write(f"  最小学习率: {args.min_lr}\n")
        log_f.write(f"  Warmup轮数: {args.warmup_epochs}\n")
        log_f.write(f"  Gradient accumulation steps: {accumulation_steps}\n")
        for line in format_training_config_lines(args, loss_weights):
            log_f.write(line + "\n")
        log_f.write(f"  验证阈值: {args.threshold}\n")
        log_f.write(f"  数据目录: {args.root_path}\n")
        if args.max_train_batches > 0:
            log_f.write(f"  每轮最多训练batch数: {args.max_train_batches}\n")
        log_f.write("="*100 + "\n\n")
    
    csv_log_mode = 'a' if append_existing_logs else 'w'
    write_csv_headers = not append_existing_logs
    try:
        loss_log_file = open(loss_log_path, csv_log_mode, newline='', encoding='utf-8')
        try:
            batch_loss_log_file = open(batch_loss_log_path, csv_log_mode, newline='', encoding='utf-8')
        except PermissionError:
            loss_log_file.close()
            raise
    except PermissionError as exc:
        fallback_stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        loss_log_path = os.path.join(args.output_dir, f'epoch_losses_resume_{fallback_stamp}.csv')
        batch_loss_log_path = os.path.join(args.output_dir, f'batch_losses_resume_{fallback_stamp}.csv')
        print(
            "[WARN] CSV log file is locked; writing this resumed segment to "
            f"{loss_log_path} and {batch_loss_log_path}. Detail: {exc}",
            flush=True,
        )
        loss_log_file = open(loss_log_path, 'w', newline='', encoding='utf-8')
        batch_loss_log_file = open(batch_loss_log_path, 'w', newline='', encoding='utf-8')
        write_csv_headers = True

    with loss_log_file, batch_loss_log_file:
        loss_writer = csv.writer(loss_log_file)
        batch_loss_writer = csv.writer(batch_loss_log_file)
        if write_csv_headers:
            loss_writer.writerow([
                'epoch', 'lr', 'train_avg_loss', 'val_loss',
                'surface_iou', 'surface_f1', 'surface_precision', 'surface_recall',
                'skeleton_iou', 'skeleton_f1', 'skeleton_precision', 'skeleton_recall',
                'highres_skeleton_loss', 'structure_delta_mean',
                'structure_delta_abs_mean', 'structure_delta_abs_max',
                'structure_delta_weak_skeleton_fn_mean',
                'structure_delta_skeleton_tp_mean',
                'structure_delta_background_mean',
            ])
            batch_loss_writer.writerow([
                'epoch', 'batch', 'loss',
                'highres_skeleton_loss',
                'structure_delta_mean', 'structure_delta_abs_mean',
                'structure_delta_abs_max', 'structure_delta_weak_skeleton_fn_mean',
                'structure_delta_skeleton_tp_mean',
                'structure_delta_background_mean',
                'ms_per_batch',
            ])
            loss_log_file.flush()
            batch_loss_log_file.flush()

        trend_val_csv = args.trend_val_csv or os.path.join(args.output_dir, "trend_val_metrics.csv")
        if args.trend_val_every_steps > 0:
            os.makedirs(os.path.dirname(trend_val_csv), exist_ok=True)
            if not os.path.exists(trend_val_csv) or os.path.getsize(trend_val_csv) == 0:
                with open(trend_val_csv, "w", newline="", encoding="utf-8") as trend_file:
                    csv.writer(trend_file).writerow([
                        "epoch",
                        "batch",
                        "global_step",
                        "lr",
                        "threshold",
                        "n_images",
                        "iou",
                        "recall",
                        "precision",
                        "cldice",
                        "pred_comp",
                        "gt_comp",
                        "frag_idx",
                        "extra_comp",
                        "pred_short",
                        "gt_short",
                        "pred_largest_ratio",
                        "gt_largest_ratio",
                    ])
            print(f"[INFO] Trend validation CSV: {trend_val_csv}", flush=True)

        global_train_step = 0
        for epoch in range(start_epoch, end_epoch):
            if hasattr(train_dataset, "set_epoch"):
                train_dataset.set_epoch(epoch)
            current_lr = get_cosine_warmup_lr(
                epoch, args.max_epochs, args.new_lr, args.new_min_lr, args.warmup_epochs
            )
            for param_group in optimizer.param_groups:
                if param_group.get('group_name') == 'imagenet_loaded':
                    param_group['lr'] = get_cosine_warmup_lr(
                        epoch, args.max_epochs, args.pretrained_lr,
                        args.pretrained_min_lr, args.warmup_epochs
                    )
                else:
                    param_group['lr'] = current_lr

            model.train()
            total_loss = 0
            train_batches = 0
            skipped_batches = 0
            optimizer.zero_grad(set_to_none=True)
            accumulation_count = 0
            highres_stat_sums = {
                "highres_structure_skeleton_raw": 0.0,
                "structure_delta_mean": 0.0,
                "structure_delta_abs_mean": 0.0,
                "structure_delta_abs_max": 0.0,
                "structure_delta_weak_skeleton_fn_mean": 0.0,
                "structure_delta_skeleton_tp_mean": 0.0,
                "structure_delta_background_mean": 0.0,
            }
            highres_stat_counts = {key: 0 for key in highres_stat_sums}
            stage_distill_scale = get_stage_distill_scale(epoch)

            for i, batch in enumerate(train_loader):
                if args.max_train_batches > 0 and train_batches >= args.max_train_batches:
                    break
                if args.encoder_h_postmerge_phase and i == 0:
                    sampling_record = dict(epoch=epoch+1, dataset_epoch=train_dataset.epoch,
                        persistent_workers=False, samples=[dict(image=name,
                            top=int(batch['tile_top'][j]), left=int(batch['tile_left'][j]))
                            for j, name in enumerate(batch['image_name'])])
                    with open(os.path.join(args.output_dir, 'sampling_epochs.jsonl'), 'a', encoding='utf-8') as handle:
                        handle.write(json.dumps(sampling_record)+'\n')
                    print('[EPOCH CROP]', json.dumps(sampling_record), flush=True)
                batch_start_time = time.perf_counter()

                images = batch['image'].to(device)
                masks = batch['mask'].to(device)
                skeletons = batch['skeleton'].to(device)
                skeletons_dilate = batch['skeleton_dilate'].to(device)

                images_padded, orig_shape = pad_to_window_multiple(images, window_size=1)
                masks_padded, _ = pad_to_window_multiple(masks, window_size=1)
                skeletons_padded, _ = pad_to_window_multiple(skeletons, window_size=1)
                skeletons_dilate_padded, _ = pad_to_window_multiple(skeletons_dilate, window_size=1)

                with torch.autocast(
                    device_type=device.type,
                    dtype=torch.bfloat16,
                    enabled=use_bf16_amp,
                ):
                    outputs = model(images_padded)

                if isinstance(outputs, tuple):
                    (
                        surface_logits,
                        boundary_logits,
                        skeleton_logits,
                        connectivity_logits,
                        stage_outputs,
                    ) = outputs[:5]
                else:
                    raise RuntimeError("Structure-guided training requires auxiliary model outputs.")
                surface_logits = surface_logits.float()
                boundary_logits = boundary_logits.float() if boundary_logits is not None else None
                skeleton_logits = skeleton_logits.float() if skeleton_logits is not None else None
                connectivity_logits = connectivity_logits.float() if connectivity_logits is not None else None
                stage_outputs = [
                    {
                        key: value.float()
                        if torch.is_tensor(value) and value.is_floating_point()
                        else value
                        for key, value in item.items()
                    }
                    if isinstance(item, dict)
                    else item
                    for item in stage_outputs
                ]
                surface_logits = crop_to_shape(surface_logits, orig_shape)
                boundary_logits = crop_to_shape(boundary_logits, orig_shape)
                skeleton_logits = crop_to_shape(skeleton_logits, orig_shape)
                connectivity_logits = crop_to_shape(connectivity_logits, orig_shape)
                
                masks_padded = crop_to_shape(masks_padded, orig_shape)
                skeletons_padded = crop_to_shape(skeletons_padded, orig_shape)
                skeletons_dilate_padded = crop_to_shape(skeletons_dilate_padded, orig_shape)
                
                loss, loss_dict = criterion(
                    surface_logits,
                    surface_gt=masks_padded,
                    skeleton_gt=skeletons_padded,
                    skeleton_dilate_gt=skeletons_dilate_padded,
                    stage_outputs=stage_outputs,
                    boundary_logits=boundary_logits,
                    skeleton_logits=skeleton_logits,
                    connectivity_logits=connectivity_logits,
                )

                if not torch.isfinite(loss):
                    skipped_batches += 1
                    print(
                        f"[WARN] Non-finite loss skipped at epoch {epoch+1}, batch {i+1}: {loss.item()}",
                        flush=True,
                    )
                    optimizer.zero_grad(set_to_none=True)
                    accumulation_count = 0
                    continue

                (loss / accumulation_steps).backward()
                if args.encoder_h_postmerge_phase and (i == 0 or (i+1) % max(args.h_phase_audit_interval, 1) == 0):
                    from h0_phase_training import phase_gradients, phase_stats
                    gradients = phase_gradients(model)
                    if not all(np.isfinite(value) and value > 0 for value in gradients.values()):
                        raise RuntimeError('Missing or invalid task gradients in encoder-H exchange: '+str(gradients))
                    audit = dict(epoch=epoch+1, batch=i+1, loss=float(loss.detach()),
                                 gradients=gradients, **phase_stats(model))
                    with open(os.path.join(args.output_dir, 'encoder_h_phase_training.jsonl'), 'a', encoding='utf-8') as stream:
                        stream.write(json.dumps(audit)+'\n')
                accumulation_count += 1
                should_step = (
                    accumulation_count >= accumulation_steps
                    or i + 1 == len(train_loader)
                    or (
                        args.max_train_batches > 0
                        and train_batches + 1 >= args.max_train_batches
                    )
                )
                if should_step:
                    grad_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
                    if not torch.isfinite(grad_norm):
                        skipped_batches += 1
                        print(
                            f"[WARN] Non-finite gradients skipped at epoch {epoch+1}, batch {i+1}: {grad_norm}",
                            flush=True,
                        )
                        optimizer.zero_grad(set_to_none=True)
                        accumulation_count = 0
                        continue

                    optimizer.step()
                    optimizer.zero_grad(set_to_none=True)
                    accumulation_count = 0
                    if ema is not None:
                        ema.update(model)

                total_loss += loss.item()
                train_batches += 1
                if torch.cuda.is_available():
                    torch.cuda.synchronize()
                ms_per_batch = (time.perf_counter() - batch_start_time) * 1000.0
                for key in highres_stat_sums:
                    value = float(loss_dict[key].item())
                    if np.isfinite(value):
                        highres_stat_sums[key] += value
                        highres_stat_counts[key] += 1
                batch_loss_writer.writerow([
                    epoch + 1,
                    i + 1,
                    f'{loss.item():.6f}',
                    f"{loss_dict['highres_structure_skeleton_raw'].item():.6f}",
                    f"{loss_dict['structure_delta_mean'].item():.6f}",
                    f"{loss_dict['structure_delta_abs_mean'].item():.6f}",
                    f"{loss_dict['structure_delta_abs_max'].item():.6f}",
                    f"{loss_dict['structure_delta_weak_skeleton_fn_mean'].item():.6f}",
                    f"{loss_dict['structure_delta_skeleton_tp_mean'].item():.6f}",
                    f"{loss_dict['structure_delta_background_mean'].item():.6f}",
                    f"{ms_per_batch:.3f}",
                ])
                batch_loss_log_file.flush()

                global_train_step += 1
                if (
                    args.trend_val_every_steps > 0
                    and global_train_step % args.trend_val_every_steps == 0
                ):
                    eval_model = ema.ema if ema is not None else model
                    trend_metrics = evaluate_trend_topology_subset(
                        eval_model,
                        val_loader,
                        threshold=args.threshold,
                        max_batches=args.trend_val_max_batches,
                        short_area_threshold=args.trend_val_short_area_threshold,
                    )
                    with open(trend_val_csv, "a", newline="", encoding="utf-8") as trend_file:
                        csv.writer(trend_file).writerow([
                            epoch + 1,
                            i + 1,
                            global_train_step,
                            f"{current_lr:.8f}",
                            f"{args.threshold:.6f}",
                            trend_metrics["n_images"],
                            f"{trend_metrics['iou']:.6f}",
                            f"{trend_metrics['recall']:.6f}",
                            f"{trend_metrics['precision']:.6f}",
                            f"{trend_metrics['cldice']:.6f}",
                            f"{trend_metrics['pred_comp']:.6f}",
                            f"{trend_metrics['gt_comp']:.6f}",
                            f"{trend_metrics['frag_idx']:.6f}",
                            f"{trend_metrics['extra_comp']:.6f}",
                            f"{trend_metrics['pred_short']:.6f}",
                            f"{trend_metrics['gt_short']:.6f}",
                            f"{trend_metrics['pred_largest_ratio']:.6f}",
                            f"{trend_metrics['gt_largest_ratio']:.6f}",
                        ])
                    print(
                        f"[TREND_VAL] epoch={epoch+1} batch={i+1} step={global_train_step} "
                        f"IoU={trend_metrics['iou']:.4f} R={trend_metrics['recall']:.4f} "
                        f"P={trend_metrics['precision']:.4f} clDice={trend_metrics['cldice']:.4f} "
                        f"frag={trend_metrics['frag_idx']:.3f} extra={trend_metrics['extra_comp']:.2f}",
                        flush=True,
                    )
                    model.train()

                if (i + 1) % args.print_freq == 0 or i == 0:
                    print(
                        f"Epoch [{epoch+1}/{args.max_epochs}], Batch [{i+1}/{len(train_loader)}], "
                        f"Loss: {loss.item():.4f}, Surface: {loss_dict['surface_loss'].item():.4f}, "
                        f"Skeleton: {loss_dict['skeleton_loss'].item():.4f}, "
                    f"Conn: {loss_dict['connectivity_loss'].item():.4f}, "
                    f"StageStruct: {loss_dict['stage_structure_loss'].item():.4f}, "
                    f"HighResSkel: {loss_dict['highres_structure_skeleton_raw'].item():.4f}, "
                        f"DeltaAbs: {loss_dict['structure_delta_abs_mean'].item():.4f}, "
                        f"RoadAttn: {loss_dict['road_attention_loss'].item():.4f}, "
                        f"ms/batch: {ms_per_batch:.1f}",
                        flush=True
                    )

            train_avg_loss = total_loss / max(train_batches, 1)
            highres_epoch_stats = {
                key: (
                    highres_stat_sums[key] / highres_stat_counts[key]
                    if highres_stat_counts[key] > 0
                    else float("nan")
                )
                for key in highres_stat_sums
            }
            should_validate = (
                args.val_interval <= 1
                or (epoch + 1) % args.val_interval == 0
                or (epoch + 1) == args.max_epochs
            )
            val_loss = float("nan")
            val_iou = float("nan")
            val_f1 = float("nan")
            val_precision = float("nan")
            val_recall = float("nan")
            skeleton_iou = float("nan")
            skeleton_f1 = float("nan")
            skeleton_precision = float("nan")
            skeleton_recall = float("nan")

            if should_validate:
                eval_model = ema.ema if ema is not None else model
                if args.direct_resize_train or args.val_crop_list:
                    val_metrics = evaluate_skeleton(
                        eval_model,
                        val_loader,
                        criterion,
                        threshold=args.threshold,
                        skeleton_threshold=args.skeleton_threshold,
                    )
                else:
                    val_metrics = evaluate_overlap_full_images(
                        eval_model,
                        val_loader,
                        criterion,
                        threshold=args.threshold,
                        skeleton_threshold=args.skeleton_threshold,
                        tile_size=args.img_size,
                        stride=args.overlap_stride,
                    )
                val_loss = val_metrics['loss']
                val_iou = val_metrics['surface_iou']
                val_f1 = val_metrics['surface_f1']
                val_precision = val_metrics['surface_precision']
                val_recall = val_metrics['surface_recall']
                skeleton_iou = val_metrics['skeleton_iou']
                skeleton_f1 = val_metrics['skeleton_f1']
                skeleton_precision = val_metrics['skeleton_precision']
                skeleton_recall = val_metrics['skeleton_recall']
            
            # 打印到控制台
            if should_validate:
                epoch_msg = (
                    f"Epoch {epoch+1}/{args.max_epochs}, LR: {current_lr:.6g}, Train Loss: {train_avg_loss:.4f}, Val Loss: {val_loss:.4f}, "
                    f"Surface IoU: {val_iou:.4f}, Surface F1: {val_f1:.4f}, "
                    f"Precision: {val_precision:.4f}, Recall: {val_recall:.4f}, "
                    f"Skeleton IoU: {skeleton_iou:.4f}, Skeleton F1: {skeleton_f1:.4f}"
                )
            else:
                epoch_msg = (
                    f"Epoch {epoch+1}/{args.max_epochs}, LR: {current_lr:.6g}, "
                    f"Train Loss: {train_avg_loss:.4f}, Val: skipped "
                    f"(interval={args.val_interval})"
                )
            print(epoch_msg, flush=True)
            highres_skeleton_msg = (
                "[HighRes Skeleton] "
                f"highres_skeleton_loss={highres_epoch_stats['highres_structure_skeleton_raw']:.4f}"
            )
            print(highres_skeleton_msg, flush=True)
            structure_delta_msg = (
                "[Structure Surface Delta] "
                f"mean={highres_epoch_stats['structure_delta_mean']:.4f}, "
                f"abs_mean={highres_epoch_stats['structure_delta_abs_mean']:.4f}, "
                f"abs_max={highres_epoch_stats['structure_delta_abs_max']:.4f}, "
                f"weak_skel_fn={highres_epoch_stats['structure_delta_weak_skeleton_fn_mean']:.4f}, "
                f"skel_tp={highres_epoch_stats['structure_delta_skeleton_tp_mean']:.4f}, "
                f"background={highres_epoch_stats['structure_delta_background_mean']:.4f}"
            )
            print(structure_delta_msg, flush=True)
            topology_msg = print_topology_coefficients(
                model,
                prefix=f"[TOPOLOGY][Epoch {epoch + 1}]",
            )
            if skipped_batches > 0:
                print(f"[WARN] Skipped non-finite batches this epoch: {skipped_batches}", flush=True)
            
            # 写入 CSV
            loss_writer.writerow([
                epoch + 1, f'{current_lr:.8f}', f'{train_avg_loss:.6f}', f'{val_loss:.6f}',
                f'{val_iou:.6f}', f'{val_f1:.6f}', f'{val_precision:.6f}', f'{val_recall:.6f}',
                f'{skeleton_iou:.6f}', f'{skeleton_f1:.6f}', f'{skeleton_precision:.6f}', f'{skeleton_recall:.6f}',
                f"{highres_epoch_stats['highres_structure_skeleton_raw']:.6f}",
                f"{highres_epoch_stats['structure_delta_mean']:.6f}",
                f"{highres_epoch_stats['structure_delta_abs_mean']:.6f}",
                f"{highres_epoch_stats['structure_delta_abs_max']:.6f}",
                f"{highres_epoch_stats['structure_delta_weak_skeleton_fn_mean']:.6f}",
                f"{highres_epoch_stats['structure_delta_skeleton_tp_mean']:.6f}",
                f"{highres_epoch_stats['structure_delta_background_mean']:.6f}",
            ])
            loss_log_file.flush()
            
            # 写入 txt 日志
            with open(training_log_path, 'a', encoding='utf-8') as log_f:
                log_f.write(epoch_msg + "\n")
                log_f.write(f"  Train Avg Loss: {train_avg_loss:.6f}\n")
                log_f.write(f"  Val Loss: {val_loss:.6f}\n")
                log_f.write(f"  Val IoU: {val_iou:.6f}\n")
                log_f.write(f"  Val F1: {val_f1:.6f}\n")
                log_f.write(f"  Val Precision: {val_precision:.6f}\n")
                log_f.write(f"  Val Recall: {val_recall:.6f}\n")
                log_f.write(f"  Skeleton IoU: {skeleton_iou:.6f}\n")
                log_f.write(f"  Skeleton F1: {skeleton_f1:.6f}\n")
                log_f.write(f"  Skeleton Precision: {skeleton_precision:.6f}\n")
                log_f.write(f"  Skeleton Recall: {skeleton_recall:.6f}\n")
                log_f.write(highres_skeleton_msg + "\n")
                log_f.write(structure_delta_msg + "\n")
                log_f.write(f"  Skipped non-finite batches: {skipped_batches}\n")
                log_f.write(topology_msg + "\n")
                log_f.write("-"*100 + "\n")

            if (
                not np.isfinite(train_avg_loss)
                or (should_validate and not np.isfinite(val_loss))
                or not model_state_is_finite(model)
            ):
                print(
                    f"[WARN] Non-finite epoch state at epoch {epoch+1}; checkpoint not saved.",
                    flush=True,
                )
                continue

            checkpoint_model = ema.ema if ema is not None else model
            checkpoint = {
                'epoch': epoch + 1,
                'model_state_dict': checkpoint_model.state_dict(),
                'training_model_state_dict': model.state_dict(),
                'ema_state_dict': ema.ema.state_dict() if ema is not None else None,
                'optimizer_state_dict': optimizer.state_dict(),
                'train_avg_loss': train_avg_loss,
                'val_loss': val_loss,
                'val_iou': val_iou,
                'val_f1': val_f1,
                'val_precision': val_precision,
                'val_recall': val_recall,
                'skeleton_iou': skeleton_iou,
                'skeleton_f1': skeleton_f1,
                'skeleton_precision': skeleton_precision,
                'skeleton_recall': skeleton_recall,
                'topology_attention_version': TOPOLOGY_ATTENTION_VERSION,
                'structure_profile': args.structure_profile,
                'topology_coefficients': get_topology_coefficients(model),
                'loaded_pretrained_names': sorted(loaded_pretrained_names),
                'args': vars(args),
            }
            # 保存 last.pth（总是覆盖）
            save_checkpoint_safely(checkpoint, os.path.join(args.output_dir, 'last.pth'))

            if should_validate and val_f1 > best_val_f1:
                best_val_f1 = val_f1
                save_checkpoint_safely(checkpoint, best_path)
                print(f"[BEST] 当前最优模型已保存: best.pth (F1={val_f1:.4f})", flush=True)

    # 训练完成，写总结日志
    with open(training_log_path, 'a', encoding='utf-8') as log_f:
        log_f.write("\n" + "="*100 + "\n")
        log_f.write("训练完成总结\n")
        log_f.write("="*100 + "\n")
        log_f.write(f"总 Epochs: {args.max_epochs}\n")
        log_f.write(f"最佳 F1 分数: {best_val_f1:.6f}\n")
        log_f.write(f"最佳模型: best.pth\n")
        log_f.write(f"最后模型: last.pth\n")
        log_f.write("="*100 + "\n")

    best_path = os.path.join(args.output_dir, 'best.pth')
    if os.path.isfile(best_path):
        best_checkpoint = torch.load(best_path, map_location='cuda')
        model.load_state_dict(best_checkpoint['model_state_dict'], strict=(args.bottleneck_type == 'global_local'))
        if args.direct_resize_train or args.val_crop_list:
            best_val_metrics = evaluate_skeleton(
                model,
                val_loader,
                criterion,
                threshold=args.threshold,
                skeleton_threshold=args.skeleton_threshold,
            )
        else:
            best_val_metrics = evaluate_overlap_full_images(
                model,
                val_loader,
                criterion,
                threshold=args.threshold,
                skeleton_threshold=args.skeleton_threshold,
                tile_size=args.img_size,
                stride=args.overlap_stride,
            )

        best_eval_msg = (
            f"Best Checkpoint Eval, Val Loss: {best_val_metrics['loss']:.4f}, "
            f"Surface IoU: {best_val_metrics['surface_iou']:.4f}, Surface F1: {best_val_metrics['surface_f1']:.4f}"
        )
        print("\n" + best_eval_msg, flush=True)
        with open(training_log_path, 'a', encoding='utf-8') as log_f:
            log_f.write("\n" + best_eval_msg + "\n")
    
    print("\n训练完成!")
    print(f"   best.pth: {best_path}")
    print(f"   last.pth: {os.path.join(args.output_dir, 'last.pth')}")
    print(f"Training log: {training_log_path}")
