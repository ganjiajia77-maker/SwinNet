import torch
import torch.utils.data as data

import cv2
import numpy as np
import os


def randomHueSaturationValue(image, hue_shift_limit=(-180, 180),
                             sat_shift_limit=(-255, 255),
                             val_shift_limit=(-255, 255), u=0.5):
    if np.random.random() < u:
        image = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
        h, s, v = cv2.split(image)
        hue_shift = np.random.randint(hue_shift_limit[0], hue_shift_limit[1] + 1)
        hue_scale = np.random.rand()
        sat_scale = np.random.rand()
        val_scale = np.random.rand()
        # hue_shift = np.uint8(hue_shift)
        # h += hue_shift
        h = np.uint8(h*hue_scale)
        s = np.uint8(s*sat_scale)
        v = np.uint8(v*val_scale)
        # sat_shift = np.random.uniform(sat_shift_limit[0], sat_shift_limit[1])
        # s = cv2.add(s, sat_shift)
        # val_shift = np.random.uniform(val_shift_limit[0], val_shift_limit[1])
        # v = cv2.add(v, val_shift)
        image = cv2.merge((h, s, v))
        # image = cv2.merge((s, v))
        image = cv2.cvtColor(image, cv2.COLOR_HSV2BGR)

    return image


def randomShiftScaleRotate(image, mask,
                           shift_limit=(-0.0, 0.0),
                           scale_limit=(-0.0, 0.0),
                           rotate_limit=(-0.0, 0.0),
                           aspect_limit=(-0.0, 0.0),
                           borderMode=cv2.BORDER_CONSTANT, u=0.5):
    if np.random.random() < u:
        height, width, channel = image.shape

        angle = np.random.uniform(rotate_limit[0], rotate_limit[1])
        scale = np.random.uniform(1 + scale_limit[0], 1 + scale_limit[1])
        aspect = np.random.uniform(1 + aspect_limit[0], 1 + aspect_limit[1])
        sx = scale * aspect / (aspect ** 0.5)
        sy = scale / (aspect ** 0.5)
        dx = round(np.random.uniform(shift_limit[0], shift_limit[1]) * width)
        dy = round(np.random.uniform(shift_limit[0], shift_limit[1]) * height)

        cc = np.cos(angle / 180 * np.pi) * sx
        ss = np.sin(angle / 180 * np.pi) * sy
        rotate_matrix = np.array([[cc, -ss], [ss, cc]])

        box0 = np.array([[0, 0], [width, 0], [width, height], [0, height], ])
        box1 = box0 - np.array([width / 2, height / 2])
        box1 = np.dot(box1, rotate_matrix.T) + np.array([width / 2 + dx, height / 2 + dy])

        box0 = box0.astype(np.float32)
        box1 = box1.astype(np.float32)
        mat = cv2.getPerspectiveTransform(box0, box1)
        image = cv2.warpPerspective(image, mat, (width, height), flags=cv2.INTER_LINEAR, borderMode=borderMode,
                                    borderValue=(
                                        0, 0,
                                        0,))
        mask = cv2.warpPerspective(mask, mat, (width, height), flags=cv2.INTER_LINEAR, borderMode=borderMode,
                                   borderValue=(
                                       0, 0,
                                       0,))

    return image, mask


def randomHorizontalFlip(image, mask, u=0.5):
    if np.random.random() < u:
        image = cv2.flip(image, 1)
        mask = cv2.flip(mask, 1)

    return image, mask


def randomVerticleFlip(image, mask, u=0.5):
    if np.random.random() < u:
        image = cv2.flip(image, 0)
        mask = cv2.flip(mask, 0)

    return image, mask


def randomRotate90(image, mask, u=0.5):
    if np.random.random() < u:
        image = np.rot90(image)
        mask = np.rot90(mask)

    return image, mask


def default_loader(img_fn, mask_fn, root, is_train = True, img_size = 1024):
    img = cv2.imread(os.path.join(root, img_fn))
    mask = cv2.imread(os.path.join(root, mask_fn), cv2.IMREAD_GRAYSCALE)
    img = cv2.resize(img, (img_size, img_size), interpolation = cv2.INTER_LINEAR)
    mask = cv2.resize(mask, (img_size, img_size), interpolation = cv2.INTER_LINEAR)

    if is_train:
        img = randomHueSaturationValue(img,
                                       hue_shift_limit=(-30, 30),
                                       sat_shift_limit=(-5, 5),
                                       val_shift_limit=(-15, 15))
    
        img, mask = randomShiftScaleRotate(img, mask,
                                           shift_limit=(-0.1, 0.1),
                                           scale_limit=(-0.1, 0.1),
                                           aspect_limit=(-0.1, 0.1),
                                           rotate_limit=(-0, 0))
        img, mask = randomHorizontalFlip(img, mask)
        img, mask = randomVerticleFlip(img, mask)
        img, mask = randomRotate90(img, mask)

    mask = np.expand_dims(mask, axis=2)
    img = np.array(img, np.float32).transpose(2, 0, 1) / 255.0 * 3.2 - 1.6
    mask = np.array(mask, np.float32).transpose(2, 0, 1) / 255.0
    mask[mask >= 0.5] = 1
    mask[mask <= 0.5] = 0
    # mask = abs(mask-1)
    return img, mask


class DeepGlobeDataset(data.Dataset):

    def __init__(self, trainlist, root, is_train = True, img_size = 1024):
        self.ids = trainlist
        self.loader = default_loader
        self.root = root
        self.is_train = is_train
        self.img_size = img_size

    def __getitem__(self, index):
        id = self.ids[index]
        img_fn = f'{id}_sat.jpg'
        mask_fn = f'{id}_mask.png'
        img, mask = self.loader(img_fn, mask_fn, self.root, self.is_train, self.img_size)
        img = torch.Tensor(img)
        mask = torch.Tensor(mask)
        return img, mask, id

    def __len__(self):
        # return len(self.ids)
        return len(list(self.ids))


class RoadDataset(data.Dataset):

    def __init__(self, trainlist, root, is_train = True, img_size = 1024):
        self.ids = trainlist
        self.loader = default_loader
        self.root = root
        self.is_train = is_train
        self.img_size = img_size

    def __getitem__(self, index):
        id = self.ids[index]
        img_fn = f'{id}.bmp'
        mask_fn = f'{id}_mask.bmp'
        img, mask = self.loader(img_fn, mask_fn, self.root, self.is_train, self.img_size)
        img = torch.Tensor(img)
        mask = torch.Tensor(mask)
        return img, mask, id

    def __len__(self):
        # return len(self.ids)
        return len(list(self.ids))
