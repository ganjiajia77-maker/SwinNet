"""Create and update an auditable manifest for the shared road evaluator."""
import argparse
import json
from pathlib import Path

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root_path', required=True)
    parser.add_argument('--checkpoint', required=True)
    parser.add_argument('--report', required=True)
    parser.add_argument('--test_masks')
    parser.add_argument('--threshold', type=float)
    args = parser.parse_args()
    report = Path(args.report).resolve()
    report.mkdir(parents=True, exist_ok=True)
    path = report / 'comparison.json'
    if args.test_masks:
        data = json.loads(path.read_text(encoding='utf-8'))
        selection = json.loads((report / 'val' / 'val_selection.json').read_text(encoding='utf-8'))
        threshold = float(selection['models']['crnet_data1']['threshold'])
        if args.threshold is None or abs(args.threshold - threshold) > 1e-8:
            raise ValueError('Test threshold must match validation selection')
        data['models'][0]['predictions']['test'] = [{'threshold': threshold, 'path': str(Path(args.test_masks).resolve())}]
    else:
        candidates = []
        for directory in sorted((report / 'val_inference' / 'val_masks').glob('thr_*')):
            threshold = float(directory.name[4:].replace('p', '.'))
            candidates.append({'threshold': threshold, 'path': str(directory.resolve())})
        if not candidates:
            raise ValueError('No validation masks found')
        data = {'data_root': str(Path(args.root_path).resolve()), 'protocol': {
            'image_size': 1024, 'short_area_threshold': 20, 'apls_max_control_nodes': 150,
            'apls_snap_radius': 5.0, 'topo_seed_density_deg': 0.002, 'topo_step_deg': 0.0002},
            'models': [{'name': 'crnet_data1', 'provenance': {
                'checkpoint': str(Path(args.checkpoint).resolve()),
                'validation_masks': 'CRNet data1 sliding-window evaluation'},
                'predictions': {'val': candidates, 'test': []}}]}
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print('Manifest:', path, flush=True)

if __name__ == '__main__':
    main()
